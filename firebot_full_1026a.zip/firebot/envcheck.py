"""
가상환경 자동 전환

`source venv/bin/activate` 를 깜빡하고 실행하면 시스템 파이썬이 쓰여서
ultralytics(YOLO)를 못 찾고 색상 검출기로 조용히 대체되는 문제가 있었다.
각 실행 파일 맨 위에서 ensure_venv()를 부르면, 가상환경 밖에서 실행됐을 때
~/firebot/venv 의 파이썬으로 자기 자신을 다시 실행한다.
"""
import os
import sys
from pathlib import Path

_BASE = Path(__file__).resolve().parent
_VENV_PY = _BASE / "venv" / "bin" / "python3"


def ensure_venv():
    _reexec_in_venv()          # 필요하면 여기서 venv 파이썬으로 다시 실행 (돌아오지 않음)
    check_files()


def _reexec_in_venv():
    in_venv = sys.prefix != getattr(sys, "base_prefix", sys.prefix)
    if in_venv or os.environ.get("FIREBOT_REEXEC") == "1":
        return
    if not _VENV_PY.exists():
        print("[env] 가상환경(venv)이 없어서 시스템 파이썬으로 실행합니다. install.sh 를 먼저 실행하세요")
        return
    os.environ["FIREBOT_REEXEC"] = "1"
    print("[env] 가상환경으로 전환해서 다시 실행합니다")
    os.execv(str(_VENV_PY), [str(_VENV_PY)] + sys.argv)


def _config_names(path):
    import ast

    names = set()
    for node in ast.parse(path.read_text(encoding="utf-8")).body:
        targets = node.targets if isinstance(node, ast.Assign) else \
            [node.target] if isinstance(node, ast.AnnAssign) else []
        for t in targets:
            for n in (t.elts if isinstance(t, ast.Tuple) else [t]):
                if isinstance(n, ast.Name):
                    names.add(n.id)
    return names


def check_files():
    """
    서로 다른 묶음의 파일이 섞였는지 MANIFEST.txt 와 비교해서 알려준다.
    config.py 는 값을 직접 고치는 파일이라 내용 대신 '설정 이름이 다 있는지'만 본다.
    """
    import hashlib

    man = _BASE / "MANIFEST.txt"
    if not man.exists():
        print("[env] MANIFEST.txt 가 없어서 파일 버전 확인을 건너뜀")
        return
    version, keys, files = "?", [], {}
    for line in man.read_text(encoding="utf-8").splitlines():
        if line.startswith("version:"):
            version = line.split(":", 1)[1].strip()
        elif line.startswith("config-keys:"):
            keys = line.split(":", 1)[1].split()
        elif line.strip() and not line.startswith("#"):
            digest, rel = line.split(None, 1)
            files[rel.strip()] = digest

    missing, changed = [], []
    for rel, digest in files.items():
        f = _BASE / rel
        if not f.exists():
            missing.append(rel)
        elif digest == "exists":        # 큰 모델 파일은 있는지만 본다
            continue
        elif hashlib.sha256(f.read_bytes()).hexdigest()[:16] != digest:
            changed.append(rel)
    try:
        have = _config_names(_BASE / "config.py")
        no_key = [k for k in keys if k not in have]
    except Exception as e:
        no_key = [f"(config.py 를 읽지 못함: {e})"]

    if not (missing or changed or no_key):
        print(f"[env] 코드 버전 {version}, 파일 확인 OK")
        return
    line = "!" * 64
    print(f"\n{line}\n  코드 버전 {version} 과 다른 파일이 섞여 있음")
    if missing:
        print(f"  없는 파일: {', '.join(missing)}")
    if changed:
        print(f"  다른 버전 파일: {', '.join(changed)}")
    if no_key:
        print(f"  config.py 에 없는 설정: {', '.join(no_key[:6])}"
              f"{' 외 %d개' % (len(no_key) - 6) if len(no_key) > 6 else ''}  (예전 config.py 로 보임)")
    print(f"  같은 날 받은 zip 을 다시 풀면 해결됨. 직접 고친 파일이면 무시해도 됨\n{line}\n")
