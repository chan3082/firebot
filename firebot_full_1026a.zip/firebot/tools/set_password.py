#!/usr/bin/env python3
"""
웹 앱 로그인 비밀번호 바꾸기

  python3 tools/set_password.py

바꾸면 이미 로그인한 기기는 모두 로그아웃된다.
실행 중인 main.py 가 있으면 다시 켜야 새 비밀번호가 적용된다.
"""
import getpass
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from web.auth import set_password   # noqa: E402


def main():
    while True:
        a = getpass.getpass("새 비밀번호 (6자 이상, 입력해도 화면에 안 보임): ")
        if len(a) < 6:
            print("6자 이상으로 정하세요.")
            continue
        if getpass.getpass("한 번 더: ") != a:
            print("두 번 입력한 값이 달라요. 다시 입력하세요.")
            continue
        break
    set_password(a)
    print("바꿨어요. 실행 중인 프로그램이 있으면 껐다 켜세요.")


if __name__ == "__main__":
    main()
