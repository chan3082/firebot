#!/usr/bin/env python3
"""
카메라와 화재 감지 확인 (모터, 라이다 없이)

  python3 tools/test_camera.py

실행하면 웹 사이트도 같이 열린다. PC 브라우저로 http://<로봇IP>:8000 에 들어가면
실시간 영상에 검출 박스가 그려지고, '사진 찍기' 버튼으로 촬영도 된다.

화면에 화재 영상을 띄워놓고 돌려서, 검출과 일렁임 값이 어떻게 나오는지 본다.
빨간 옷이나 빨간 물건도 대보면서 오탐이 없는지 같이 확인할 것.
"""
import os
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import envcheck                                  # noqa: E402
envcheck.ensure_venv()

import config                                    # noqa: E402
import tuning                                    # noqa: E402
from hw import sysmon                            # noqa: E402
from hw.camera import Camera                     # noqa: E402
from notify.alerts import AlertManager           # noqa: E402
from vision.watcher import FireWatcher           # noqa: E402
from web.server import WebServer                 # noqa: E402


class StatusLog:
    """
    1초마다 전압, 메모리, 온도, 진행 단계를 logs/status.log 에 남긴다.
    연결이 끊기거나 RPi 가 꺼져도 직전 기록이 남도록 매번 디스크에 바로 쓴다.
    """

    def __init__(self):
        path = config.BASE_DIR / "logs" / "status.log"
        path.parent.mkdir(exist_ok=True)
        self.path = path
        self.stage = "시작"
        self.last = {}
        self._f = open(path, "a", buffering=1)
        self._write(f"\n=== {time.strftime('%Y-%m-%d %H:%M:%S')} test_camera 시작 ===")
        threading.Thread(target=self._loop, daemon=True).start()

    def _write(self, text):
        try:
            self._f.write(text + "\n")
            self._f.flush()
            os.fsync(self._f.fileno())
        except Exception:
            pass

    def _loop(self):
        while True:
            self.last = sysmon.read()
            self._write(f"{time.strftime('%H:%M:%S')} {sysmon.line(self.last)} | {self.stage}")
            time.sleep(1.0)


def main():
    log = StatusLog()
    print(f"상태 기록: {log.path}  (연결이 끊기면 다시 접속해서  tail -30 {log.path.relative_to(config.BASE_DIR)})")
    first = sysmon.read()
    if first.get("volt") is not None:
        print(f"지금 {sysmon.short(first)}")
    tuning.load()
    push = None
    try:
        from notify.push import PushService
        push = PushService()
    except Exception as e:
        print(f"푸시 알림을 쓸 수 없음 ({e})")
    log.stage = "카메라 켜는 중"
    cam = Camera()
    log.stage = "화재 감지 모델 준비 중"
    watcher = FireWatcher(cam)
    log.stage = "추론 준비 중"
    alerts = AlertManager(cam, watcher, push)
    web = WebServer(cam, watcher, alerts, push=push,
                    status_fn=lambda: {"mode": "카메라 시험", "state": "TEST"})
    print(f"\n검출기: {watcher.detector_name}")
    if watcher.fallback:
        print("!! YOLO가 아니라 색상 검출기로 돌고 있음. 위의 오류 메시지를 확인할 것")
    print(f"일렁임 기준: 변화 >= {config.FLICKER_MOTION_MIN}, 흔들림 >= {config.FLICKER_STD_MIN}")
    print("Ctrl+C 종료\n")
    try:
        while True:
            time.sleep(0.5)
            det, hits = watcher.best()
            fl = watcher.flicker_info()
            flk = (f"일렁임 {'O' if fl['ok'] else 'X'} (변화 {fl['motion']:4.1f}, 흔들림 {fl['std']:4.1f}, "
                   f"표본 {fl['n']:2d})")
            perf = (f"추론 {watcher.infer_ms:4.0f}ms" if watcher.infer_count else "추론 준비 중") + \
                f", 카메라 {cam.fps:4.1f}fps"
            log.stage = perf
            sysinfo = sysmon.short(log.last)
            if sysinfo:
                perf += f" | {sysinfo}"
            if det:
                print(f"검출 {det.label:6s} {det.conf:.2f} 연속 {hits:2d} | {flk} | {perf}")
            else:
                print(f"검출 없음                  | {flk} | {perf}")
    except KeyboardInterrupt:
        pass
    finally:
        watcher.close()
        cam.close()
        web.close()


if __name__ == "__main__":
    main()
