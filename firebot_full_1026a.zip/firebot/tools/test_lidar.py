#!/usr/bin/env python3
"""
라이다 단독 확인 (모터 안 움직임)

  python3 tools/test_lidar.py setup    라이다 방향 맞추기 (처음 한 번, 라이다를 다시 달았을 때)
  python3 tools/test_lidar.py          앞/좌/우/뒤 거리 계속 보기

setup: 로봇 정면과 왼쪽에 차례로 손(또는 상자)을 대면 라이다가 어느 쪽을 보고 있는지 찾아서
config.LIDAR_MOUNT_YAW, LIDAR_INVERTED 값을 알려 주고, 원하면 config.py 에 바로 써 준다.
방향이 틀리면 장애물을 엉뚱한 쪽으로 피하고, 방향을 바로잡는 회전이 거꾸로 걸려서 빙빙 돈다.
"""
import math
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import envcheck                 # noqa: E402
envcheck.ensure_venv()

import numpy as np                              # noqa: E402
import config                                   # noqa: E402
from hw.lidar import Lidar                      # noqa: E402
from nav.avoidance import compute_clearance     # noqa: E402

BIN = 2.0                 # 도
NB = int(360 / BIN)


def fmt(v):
    return " inf " if v == float("inf") else f"{v:5.2f}"


def _raw_profile(lidar, n=8, timeout=6.0):
    """라이다 원래 각도(설정 적용 전)로 BIN 도마다 거리 중앙값. 점이 없는 칸은 inf"""
    got, last, t0 = [], None, time.time()
    while len(got) < n and time.time() - t0 < timeout:
        r = lidar.latest()
        if r is not None and r[2] < 0.5 and (last is None or r[0] is not last):
            got.append((r[0], r[1]))
            last = r[0]
        time.sleep(0.05)
    if not got:
        return None
    ang = np.concatenate([a for a, _ in got]) % 360.0
    dist = np.concatenate([d for _, d in got])
    idx = (ang / BIN).astype(int) % NB
    prof = np.full(NB, np.inf)
    for b in range(NB):
        sel = dist[idx == b]
        if sel.size >= 2:
            prof[b] = float(np.median(sel))
    return prof


def _find_hand(base, now, max_dist=0.7):
    """기준보다 0.15m 이상 가까워진 칸 중 가장 가까운 덩어리의 각도(라이다 원래 각도). 못 찾으면 None"""
    closer = (now < base - 0.15) & (now < max_dist)
    if not closer.any():
        return None
    b0 = int(np.argmin(np.where(closer, now, np.inf)))
    # 가장 가까운 칸에서 양옆으로 이어진 칸들
    members = [b0]
    for step in (1, -1):
        b = b0
        for _ in range(NB // 4):
            b = (b + step) % NB
            if not closer[b] or abs(now[b] - now[b0]) > 0.25:
                break
            members.append(b)
    angs = np.radians((np.array(members) + 0.5) * BIN)
    w = 1.0 / np.maximum(now[members], 0.05)
    return math.degrees(math.atan2((np.sin(angs) * w).sum(), (np.cos(angs) * w).sum())) % 360.0


def _wrap(a):
    return (a + 180.0) % 360.0 - 180.0


def _ask_hand(lidar, base, where):
    while True:
        input(f"\n로봇 {where} 20~40cm 에 손(또는 상자)을 대고 가만히 있는 채로 Enter ")
        prof = _raw_profile(lidar)
        if prof is None:
            print("라이다 데이터가 없어요. 연결을 확인하세요")
            continue
        a = _find_hand(base, prof)
        if a is None:
            print("새로 생긴 가까운 물체를 못 찾았어요. 손을 조금 더 가까이(20~30cm), 라이다 높이에 대고 다시 해 주세요")
            continue
        print(f"  라이다 원래 각도 {a:.0f}° 쪽에서 찾음")
        return a


def _write_config(yaw, inverted):
    path = Path(config.__file__)
    text = path.read_text(encoding="utf-8")
    text, n1 = re.subn(r"^LIDAR_MOUNT_YAW\s*=\s*[-+0-9.]+", f"LIDAR_MOUNT_YAW = {yaw:.1f}", text, count=1, flags=re.M)
    text, n2 = re.subn(r"^LIDAR_INVERTED\s*=\s*(True|False)", f"LIDAR_INVERTED = {inverted}", text, count=1, flags=re.M)
    if n1 != 1 or n2 != 1:
        return False
    path.write_text(text, encoding="utf-8")
    return True


def setup():
    lidar = Lidar()
    print(f"{config.LIDAR_PORT} 열림. 지금 설정: LIDAR_MOUNT_YAW = {config.LIDAR_MOUNT_YAW}, "
          f"LIDAR_INVERTED = {config.LIDAR_INVERTED}")
    try:
        print("\n1) 로봇 주변 50cm 안을 비워 주세요 (사람도 조금 떨어져서). 기준을 잽니다")
        input("   준비되면 Enter ")
        base = _raw_profile(lidar, n=12)
        if base is None:
            print("라이다 데이터가 없어요. 포트와 전원을 확인하세요")
            return
        a_front = _ask_hand(lidar, base, "정면 (로봇이 앞으로 가는 쪽)")
        a_left = _ask_hand(lidar, base, "왼쪽 (로봇이 앞을 볼 때 왼손 쪽)")
        d = _wrap(a_left - a_front)
        # 로봇 기준 각도 = (원래 각도 또는 -원래 각도) + YAW. 정면 → 0°, 왼쪽 → +90° 이 되게
        if abs(d + 90) <= 35:
            inverted, yaw = False, a_front
        elif abs(d - 90) <= 35:
            inverted, yaw = True, -a_front
        else:
            print(f"\n정면과 왼쪽이 {abs(d):.0f}° 떨어져 나왔어요 (90° 근처여야 함). 손 위치를 확인하고 다시 실행해 주세요")
            return
        yaw = _wrap(yaw)
        snap = round(yaw / 90.0) * 90.0
        if abs(yaw - snap) <= 12:
            yaw = _wrap(snap)            # 대개 0/90/180/-90 으로 단다. 손 위치 오차는 버림
        if yaw <= -179.5:
            yaw = 180.0
        print("\n결과")
        print(f"  LIDAR_MOUNT_YAW = {yaw:.1f}   (지금 {config.LIDAR_MOUNT_YAW})")
        print(f"  LIDAR_INVERTED = {inverted}   (지금 {config.LIDAR_INVERTED})")
        same = abs(_wrap(yaw - config.LIDAR_MOUNT_YAW)) < 1 and inverted == config.LIDAR_INVERTED
        if same:
            print("\n지금 설정이 맞아요. 고칠 것 없음")
        else:
            if inverted != config.LIDAR_INVERTED:
                print("  → 좌우가 뒤집혀 보이고 있었어요. 이대로 달리면 방향을 바로잡는 회전이 거꾸로 걸려 빙빙 돌아요")
            ans = input("\nconfig.py 에 바로 쓸까요? (y/n) ").strip().lower()
            if ans.startswith("y"):
                if _write_config(yaw, inverted):
                    print("config.py 를 고쳤어요")
                else:
                    print("config.py 에서 해당 줄을 못 찾았어요. 위 값으로 직접 고쳐 주세요")
            else:
                print("위 값으로 config.py 를 직접 고쳐 주세요")
        config.LIDAR_MOUNT_YAW, config.LIDAR_INVERTED = yaw, inverted
        print("\n확인: 손을 앞/좌/우/뒤로 옮겨 보면서 그쪽 값만 줄어드는지 보세요. Ctrl+C 로 끝")
        watch(lidar)
    except KeyboardInterrupt:
        pass
    finally:
        lidar.close()


def watch(lidar):
    while True:
        time.sleep(0.5)
        p = lidar.parser
        head = f"scan {lidar.scan_hz:4.1f}Hz | pkt {p.packets:6d} bad {p.bad_checksum:4d}"
        pts = lidar.points()
        if pts is None:
            print(f"{head} | 데이터 없음")
            continue
        c = compute_clearance(*pts)
        inside = int(((np.abs(pts[0]) < config.HALF_LENGTH) & (np.abs(pts[1]) < config.HALF_WIDTH)).sum())
        warn = f" | 차체 안쪽 점 {inside}개" if inside else ""
        print(f"{head} | pts {pts[0].size:4d} | 앞 {fmt(c.front)} 좌 {fmt(c.left)} "
              f"우 {fmt(c.right)} 뒤 {fmt(c.rear)} 회전 {fmt(c.radial)}{warn}")


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "setup":
        setup()
        return
    lidar = Lidar()
    print(f"{config.LIDAR_PORT} 열림. Ctrl+C 종료\n")
    try:
        watch(lidar)
    except KeyboardInterrupt:
        pass
    finally:
        lidar.close()


if __name__ == "__main__":
    main()
