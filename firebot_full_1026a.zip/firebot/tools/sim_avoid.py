#!/usr/bin/env python3
"""
주행 로직 시뮬레이터 (하드웨어 없이 실행)

가상 공간에 벽과 장애물을 두고, 라이다를 흉내 내서 실제 주행 코드를 그대로 돌린다.
배터리나 모터 상태와 상관없이 회피 규칙이 의도대로 동작하는지 확인하는 용도.

  python3 tools/sim_avoid.py               전체 시나리오 (config.NAV_STYLE 방식)
  python3 tools/sim_avoid.py rcourse       하나만 (아래 SCENARIOS 이름)
  python3 tools/sim_avoid.py -v            상태가 바뀔 때마다 위치 출력
  python3 tools/sim_avoid.py --legacy      예전 방식(정면 고정 + 옆걸음)으로
  python3 tools/sim_avoid.py --turn-scale=1.6   실제 회전이 설정(TURN_RATE_DEG_S)보다 1.6배 빠른 경우
  python3 tools/sim_avoid.py --no-yaw           스캔 비교 회전각 없이 시간으로만 돌기 (벽 방향 붙잡기는 그대로)
  python3 tools/sim_avoid.py --noise            라이다 거리에 실제 정도의 잡음 (1cm + 거리의 1%)
  python3 tools/sim_avoid.py --weak-wheel=0.7   앞왼쪽 바퀴가 30% 느린 경우 (직진하면 왼쪽으로 휨)

라이다는 실제처럼 초당 7번 스캔하고, 회전각은 nav/yaw.py 가 스캔끼리 비교해서 잰다.
좌표: x 전방+, y 좌측+ (m). 로봇은 처음에 +x 방향을 본다.
"""
import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import config                                          # noqa: E402
from nav.avoidance import Avoider, compute_clearance   # noqa: E402
from nav.navigator import Navigator                    # noqa: E402
from nav.yaw import YawTracker                         # noqa: E402

DT = 1.0 / config.CTRL_HZ
N_RAYS = 720
LIN_MS = config.STM32_MAX_LINEAR        # 정규화 1.0 = 0.5 m/s 로 가정
ANG_DEG_S = config.TURN_RATE_DEG_S / max(1e-6, config.TURN_SPEED)   # 보정이 맞다고 가정
LIDAR_EVERY = 3                         # 20Hz 제어 중 3번에 1번 새 스캔 (약 7Hz)
TURN_SCALE = 1.0                        # 실제 회전 속도 / 설정값 (보정이 틀린 상황 흉내)
WEAK_WHEEL = 1.0                        # 앞왼쪽 바퀴 속도 배율. --weak-wheel=0.7 이면 30% 느림
NOISE = 0.0                             # 라이다 거리 잡음 (m, 표준편차). --noise 면 실제 X4PRO 정도 (1cm + 거리의 1%)
_RNG = np.random.default_rng(0)
USE_YAW = True
LEGACY = config.NAV_STYLE == "legacy"


def box(x0, x1, y0, y1):
    return [((x0, y0), (x1, y0)), ((x1, y0), (x1, y1)),
            ((x1, y1), (x0, y1)), ((x0, y1), (x0, y0))]


def wall(x0, y0, x1, y1):
    return [((x0, y0), (x1, y1))]


def poly(pts):
    segs = []
    for a, b in zip(pts, pts[1:]):
        segs += wall(a[0], a[1], b[0], b[1])
    return segs


def corridor(center, half):
    """중심선을 따라 폭 2*half 복도 (꺾이는 곳은 직각). 시작 쪽은 막음"""
    left, right = [], []
    n = len(center)
    for i in range(n):
        (x, y) = center[i]
        d_in = d_out = None
        if i > 0:
            px, py = center[i - 1]
            d_in = ((x - px) / math.hypot(x - px, y - py), (y - py) / math.hypot(x - px, y - py))
        if i < n - 1:
            nx, ny = center[i + 1]
            d_out = ((nx - x) / math.hypot(nx - x, ny - y), (ny - y) / math.hypot(nx - x, ny - y))
        d1 = d_in or d_out
        d2 = d_out or d_in
        # 직각 모서리: 왼쪽 법선 두 개를 더함
        l1, l2 = (-d1[1], d1[0]), (-d2[1], d2[0])
        lx, ly = (l1[0] + l2[0]) if d1 != d2 else l1[0], (l1[1] + l2[1]) if d1 != d2 else l1[1]
        left.append((x + half * lx, y + half * ly))
        right.append((x - half * lx, y - half * ly))
    return poly(left) + poly(right) + wall(*left[0], *right[0])


# 좁은 막다른 길의 반폭: 로봇은 들어가지만 제자리에서 돌 수는 없는 폭 (로봇 크기에 맞춤. 40x40cm 로봇이면 0.3)
_ALCOVE = min(0.3, (config.HALF_WIDTH + math.hypot(config.HALF_LENGTH, config.HALF_WIDTH) + config.TURN_MARGIN) / 2 + 0.02)

SCENARIOS = {
    # 정면에 상자 하나. 비켜서 지나가야 함
    "box": dict(segs=box(1.2, 1.5, -0.35, 0.35), goal=lambda x, y: x > 2.5,
                expect=["DODGE"], legacy_expect=["STRAFE_R"]),
    # 정면 상자 + 우측 벽. 우측이 좁으니 좌측으로 비켜야 함
    "wall_right": dict(segs=box(1.2, 1.5, -0.4, 0.4) + wall(-1, -0.65, 3, -0.65),
                       goal=lambda x, y: x > 2.5, expect=["DODGE"], legacy_expect=["STRAFE_L"]),
    # 앞에 ㄷ자 웅덩이. 안으로 들어가지 말고 옆으로 돌아서 지나가야 함
    "pocket": dict(segs=box(1.4, 1.45, -0.48, 0.48) + box(0.7, 1.45, -0.48, -0.45)
                   + box(0.7, 1.45, 0.45, 0.48),          # 벽 두께 3cm (두께 0인 벽 끝은 정면에서 라이다에 안 보임)
                   goal=lambda x, y: x > 2.5, expect=[], legacy_expect=["BACKUP"]),
    # 막다른 복도 (폭 1m). 돌아서 나가야 함
    "deadend": dict(segs=wall(-3, 0.5, 1.4, 0.5) + wall(-3, -0.5, 1.4, -0.5)
                    + wall(1.4, -0.5, 1.4, 0.5),
                    goal=lambda x, y: x < -2.0, expect=["TURN_BACK"], legacy_expect=["TURN_AROUND"]),
    # 넓은 벽. 비켜 지나가기엔 너무 넓으니 트인 오른쪽으로 돌아서 가야 함
    "long_wall": dict(segs=wall(1.2, -1.0, 1.2, 3.0), goal=lambda x, y: y < -1.6,
                      expect=["CORNER"], legacy_expect=["STRAFE_R"]),
    # 시연 복도: 폭 2m 복도에 의자 (가는 다리 4개, 3cm, 다리 사이 38cm). 왼쪽 다리가 로봇 진행선 위에 있어서
    # 비켜 지나간 뒤 복도 가운데로 돌아와야 함 (로봇이 작아도 다리 사이로 빠지지 않게 의자를 옆으로 놓음)
    "corridor_chair": dict(segs=wall(-1, 1.0, 6, 1.0) + wall(-1, -1.0, 6, -1.0)
                           + box(2.0, 2.03, -0.40, -0.37) + box(2.0, 2.03, 0.01, 0.04)
                           + box(2.4, 2.43, -0.40, -0.37) + box(2.4, 2.43, 0.01, 0.04),
                           goal=lambda x, y: x > 4.5 and abs(y) < 0.15,
                           expect=["DODGE"], legacy_expect=["STRAFE_R"]),
    # 시연 복도: 사람이 앞을 막았다가 비켜줌. 부딪히지 않고 지나가야 함
    "person_moves": dict(segs=lambda t: wall(-1, 1.0, 6, 1.0) + wall(-1, -1.0, 6, -1.0)
                         + (box(1.2, 1.45, -0.2, 0.2) if t < 5.6 else box(1.2, 1.45, 0.6, 0.95)),
                         goal=lambda x, y: x > 3.0, expect=[], legacy_expect=["WAIT"]),
    # 폭 1m 복도에서 사람이 앞을 막고 서 있다가, 로봇이 멈춰 기다린 지 0.9초 뒤 비켜줌. 기다렸다가 그대로 가야 함
    "person_narrow": dict(segs=lambda t, info: wall(-1, 0.5, 6, 0.5) + wall(-1, -0.5, 6, -0.5)
                          + (box(1.2, 1.45, -0.2, 0.2)
                             if info["wait_t"] is None or t < info["wait_t"] + 0.9 else []),
                          goal=lambda x, y: x > 3.0, expect=["WAIT"], legacy_expect=["WAIT"],
                          forbid=["TURN_BACK", "TURN_AROUND"]),
    # 돌 공간도 없는 좁은 막다른 길 (폭 0.6m). 후진해서 빠져나와야 함
    "alcove_narrow": dict(segs=box(-4.0, 3.0, -3.0, 3.0) + wall(-1.5, _ALCOVE, 1.4, _ALCOVE)
                          + wall(-1.5, -_ALCOVE, 1.4, -_ALCOVE) + wall(1.4, -_ALCOVE, 1.4, _ALCOVE),
                          goal=lambda x, y: x < -1.9, expect=["BACKOUT"], legacy_expect=["BACKUP"]),
    # 넓은 ㄷ자 (폭 1.2m, 깊이 2m) 안쪽에서 출발. 돌아서 나가야 함
    "ushape_wide": dict(segs=box(-4.0, 3.0, -3.0, 3.0) + wall(-0.6, 0.6, 1.4, 0.6)
                        + wall(-0.6, -0.6, 1.4, -0.6) + wall(1.4, -0.6, 1.4, 0.6),
                        goal=lambda x, y: x < -1.0, expect=[], legacy_expect=["TURN_AROUND"]),
    # 꺾인 복도 (폭 1m): 앞 → 오른쪽 3m → 앞
    "stair": dict(segs=corridor([(-1, 0), (2, 0), (2, -3), (7, -3)], 0.5),
                  goal=lambda x, y: x > 6.0, expect=["CORNER"], legacy_expect=[], max_t=150.0),
    # ㄹ자 복도 (폭 1m): 앞 → 아래 → 뒤 → 아래 → 앞
    "rcourse": dict(segs=corridor([(-1, 0), (3, 0), (3, -2), (0, -2), (0, -4), (4.5, -4)], 0.5),
                    goal=lambda x, y: x > 3.8 and y < -3.5, expect=["CORNER"], legacy_expect=[], max_t=180.0),
    # 넓은 ㄹ자 복도 (폭 1.5m) + 첫 구간에 사람 + 가면서 둘러보기
    "rcourse_wide": dict(segs=corridor([(-1, 0), (4, 0), (4, -3), (0, -3), (0, -6), (5.5, -6)], 0.75)
                         + box(1.6, 1.9, -0.05, 0.3),
                         goal=lambda x, y: x > 5.0 and y < -5.5, expect=["DODGE", "SWEEP", "CORNER"],
                         legacy_expect=[], max_t=200.0, sweep_at=[12.0]),
    # 곧은 복도에서 가면서 360° 둘러보기. 멈추지 않고 앞으로 가야 하고, 끝나면 다시 똑바로
    "sweep_corridor": dict(segs=wall(-1, 0.8, 8, 0.8) + wall(-1, -0.8, 8, -0.8),
                           goal=lambda x, y: x > 5.0, expect=["SWEEP"], legacy_expect=[],
                           sweep_at=[2.0], max_heading_err=12.0),
    # 앞왼쪽 바퀴가 40% 느린 로봇으로 넓은 방(8x6m)에서 직진. 휘지 않고 원래 줄에서 15cm 안, 방향 3° 안으로 가야 함
    "weak_wheel": dict(segs=box(-1.0, 7.0, -3.0, 3.0), weak=0.6, goal=lambda x, y: x > 5.0,
                       goal_check=lambda x, y, th: None if abs(y) < 0.15 and abs(math.degrees(th)) < 3
                       else f"옆 {y:+.2f}m, 방향 {math.degrees(th):+.1f}°",
                       expect=[], legacy_expect=[], max_t=60.0),
    # 방 안에 ㄷ자 가구. 2분 동안 부딪히지 않고, 같은 곳에서 맴돌지 않아야 함
    "ushape_room": dict(segs=box(-2.5, 2.5, -2.0, 2.0) + wall(0.4, 0.55, 1.5, 0.55)
                        + wall(0.4, -0.55, 1.5, -0.55) + wall(1.5, -0.55, 1.5, 0.55),
                        start=(-0.2, 0.0), goal=None, expect=[], legacy_expect=[], max_t=120.0),
    # 장애물 여러 개 있는 방에서 2분간 돌아다니기
    "room": dict(segs=box(-2.0, 2.0, -2.0, 2.0) + box(0.6, 0.9, -0.3, 0.2)
                 + box(-0.9, -0.5, 0.8, 1.2) + box(0.8, 1.2, 1.0, 1.3)
                 + box(-1.2, -0.8, -1.3, -0.9) + wall(1.3, -2.0, 1.3, -0.6),
                 start=(-1.2, 0.0), goal=None, expect=[], legacy_expect=[], max_t=120.0),
}


def cast(pose, segs):
    """로봇 중심에서 360° 광선을 쏴서 로봇 좌표계 점 반환"""
    px, py, th = pose
    ang = np.linspace(0, 2 * np.pi, N_RAYS, endpoint=False)
    dx, dy = np.cos(ang + th), np.sin(ang + th)
    dist = np.full(N_RAYS, np.inf)
    for (x1, y1), (x2, y2) in segs:
        ex, ey = x2 - x1, y2 - y1
        den = dx * ey - dy * ex
        with np.errstate(divide="ignore", invalid="ignore"):
            t = ((x1 - px) * ey - (y1 - py) * ex) / den
            u = ((x1 - px) * dy - (y1 - py) * dx) / den
        ok = (np.abs(den) > 1e-9) & (t > 0) & (u >= 0) & (u <= 1)
        dist = np.where(ok & (t < dist), t, dist)
    keep = np.isfinite(dist) & (dist <= 10.0)
    d, a = dist[keep], ang[keep]
    return d * np.cos(a), d * np.sin(a)


def collided(x, y):
    return bool(np.any((np.abs(x) < config.HALF_LENGTH - 0.005)
                       & (np.abs(y) < config.HALF_WIDTH - 0.005)))


def body_gap(x, y):
    """차체 직사각형에서 가장 가까운 점까지 거리 (m)"""
    gx = np.maximum(np.abs(x) - config.HALF_LENGTH, 0.0)
    gy = np.maximum(np.abs(y) - config.HALF_WIDTH, 0.0)
    return float(np.min(np.hypot(gx, gy))) if x.size else math.inf


def wheel_effect(vx, vy, wz):
    """
    메카넘 4바퀴 (앞왼, 앞오, 뒤왼, 뒤오). WEAK_WHEEL 배로 앞왼쪽 바퀴만 느릴 때 실제 몸 움직임.
    앞왼쪽이 느리면 직진할 때 반시계로 돌면서 왼쪽으로 밀린다 (실제 로봇에서 본 것과 같은 방향)
    """
    if WEAK_WHEEL >= 1.0:
        return vx, vy, wz
    fl, fr = vx - vy - wz, vx + vy + wz
    rl, rr = vx + vy - wz, vx - vy + wz
    fl *= WEAK_WHEEL
    return (fl + fr + rl + rr) / 4, (-fl + fr + rl - rr) / 4, (-fl + fr - rl + rr) / 4


class _NoTurnTracker(YawTracker):
    """--no-yaw: 스캔끼리 비교한 회전각은 못 쓰는 상황 (회전은 시간으로 계산). 벽 방향은 그대로 씀"""
    def healthy(self, now=None):
        return False


def make_nav(yaw):
    return Avoider(yaw=yaw) if LEGACY else Navigator(yaw=yaw)


def run(name, sc, verbose=False, max_t=60.0, record=None):
    global WEAK_WHEEL
    if "weak" in sc and WEAK_WHEEL >= 1.0:
        WEAK_WHEEL = sc["weak"]
        try:
            return run(name, sc, verbose, max_t, record)
        finally:
            WEAK_WHEEL = 1.0
    max_t = sc.get("max_t", max_t)
    tracker = YawTracker() if USE_YAW else _NoTurnTracker()
    nav = make_nav(tracker)
    nav.reset(0.0)
    px, py = sc.get("start", (0.0, 0.0))
    th = 0.0
    t = 0.0
    step = 0
    visited, prev = [], None
    turnbacks = []
    sweeps = list(sc.get("sweep_at", []))
    cells = set()
    hist = []
    info = {"wait_t": None}                   # 움직이는 장애물용: 로봇이 처음 기다리기 시작한 시각
    min_gap, gap_at = math.inf, None
    while t < max_t:
        if callable(sc["segs"]):
            segs = sc["segs"](t, info) if sc["segs"].__code__.co_argcount == 2 else sc["segs"](t)
        else:
            segs = sc["segs"]
        x, y = cast((px, py, th), segs)
        if collided(x, y):
            return False, f"충돌 (t={t:.1f}s, 위치 {px:.2f},{py:.2f})", visited
        g = body_gap(x, y)                     # 실제 거리 (잡음 넣기 전)
        if g < min_gap:
            min_gap, gap_at = g, (px, py, t, nav.state)
        if NOISE > 0:
            r = np.hypot(x, y)
            k = 1.0 + _RNG.normal(0.0, NOISE + 0.01 * r) / np.maximum(r, 1e-6)
            x, y = x * k, y * k
        if tracker is not None and step % LIDAR_EVERY == 0:
            tracker.update(x, y, t)
        c = compute_clearance(x, y)
        if sweeps and t >= sweeps[0] and not LEGACY and nav.state == "FORWARD":
            sweeps.pop(0)
            nav.start_sweep(t)
        vx, vy, wz = nav.drive((x, y), c, t)
        if record is not None:
            record.append((px, py, th, nav.state, t))

        if nav.state != prev:
            if prev == "SWEEP" and sc.get("max_heading_err") is not None:
                err = (math.degrees(th) + 180) % 360 - 180
                if abs(err) > sc["max_heading_err"]:
                    return False, f"둘러보기 후 방향이 {err:+.0f}° 틀어짐", visited
            visited.append(nav.state)
            if nav.state == "WAIT" and info["wait_t"] is None:
                info["wait_t"] = t
            if nav.state in ("TURN_BACK", "TURN_AROUND"):
                turnbacks.append(t)
            if verbose:
                print(f"    t={t:5.1f}s  ({px:+.2f},{py:+.2f}, {math.degrees(th):+4.0f}°)  "
                      f"{nav.state:11s} {nav.last_event}")
            prev = nav.state

        # 같은 곳을 맴도는지: 60초 안에 돌아 나가기가 4번 넘으면 실패
        recent = [b for b in turnbacks if t - b < 60.0]
        if len(recent) > 4:
            return False, f"맴돌기: 60초 안에 돌아 나가기 {len(recent)}번 (t={t:.1f}s)", visited
        cells.add((round(px / 0.5), round(py / 0.5)))
        # 제자리 맴돌기: 40초 동안 0.5m 도 못 벗어나면 실패
        hist.append((t, px, py))
        while hist and t - hist[0][0] > 40.0:
            hist.pop(0)
        if t > 40.0 and hist and step % 20 == 0:
            far = max(math.hypot(hx - hist[0][1], hy - hist[0][2]) for _, hx, hy in hist)
            if far < 0.5:
                return False, f"40초 동안 0.5m 도 못 벗어남 (t={t:.1f}s, 위치 {px:.2f},{py:.2f}, {nav.state})", visited

        # 로봇 좌표 속도를 월드로 적분 (바퀴 하나가 느린 상황이면 메카넘 바퀴 식으로 실제 움직임을 계산)
        vx, vy, wz = wheel_effect(vx, vy, wz)
        spd_x, spd_y = vx * LIN_MS, vy * LIN_MS
        px += (spd_x * math.cos(th) - spd_y * math.sin(th)) * DT
        py += (spd_x * math.sin(th) + spd_y * math.cos(th)) * DT
        th += math.radians(wz * ANG_DEG_S * TURN_SCALE) * DT
        t += DT
        step += 1

        goal = sc.get("goal")
        if goal is not None and goal(px, py):
            exp = sc["legacy_expect"] if LEGACY else sc["expect"]
            missing = [s for s in exp if s not in visited]
            if missing:
                return False, f"목표 도달했지만 기대한 동작 없음: {missing}", visited
            bad = [s for s in sc.get("forbid", []) if s in visited]
            if bad:
                return False, f"목표 도달했지만 하면 안 되는 동작이 있음: {bad}", visited
            if sc.get("goal_check") and sc["goal_check"](px, py, th):
                return False, f"목표 도달했지만 줄을 벗어남: {sc['goal_check'](px, py, th)}", visited
            return True, f"{t:.1f}초 만에 통과 (벽까지 최소 {min_gap * 100:.0f}cm, {gap_at[3]} 중)", visited
    if sc.get("goal") is None:
        if len(cells) < 6:
            return False, f"{max_t:.0f}초 동안 거의 못 움직임 (지나간 칸 {len(cells)}개)", visited
        return True, (f"{max_t:.0f}초 동안 충돌 없음 (지나간 칸 {len(cells)}개, 상태 전환 {len(visited)}회, "
                      f"벽까지 최소 {min_gap * 100:.0f}cm, {gap_at[3]} 중)"), visited
    return False, f"{max_t:.0f}초 안에 통과 못함 (마지막 상태 {nav.state}, 위치 {px:.2f},{py:.2f})", visited


def main():
    global TURN_SCALE, USE_YAW, LEGACY, NOISE, WEAK_WHEEL
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    verbose = "-v" in sys.argv
    for a in sys.argv[1:]:
        if a.startswith("--turn-scale="):
            TURN_SCALE = float(a.split("=", 1)[1])
        if a == "--no-yaw":
            USE_YAW = False
        if a == "--legacy":
            LEGACY = True
        if a == "--noise":
            NOISE = 0.01
        if a.startswith("--weak-wheel="):
            WEAK_WHEEL = float(a.split("=", 1)[1])
    names = args or list(SCENARIOS)
    print(f"주행 방식: {'예전 방식 (정면 고정 + 옆걸음)' if LEGACY else '메카넘 방식'}")
    ok_all = True
    for name in names:
        ok, msg, visited = run(name, SCENARIOS[name], verbose)
        ok_all &= ok
        flow = " → ".join(dict.fromkeys(visited))
        print(f"[{'통과' if ok else '실패'}] {name:14s} {msg}")
        print(f"         흐름: {flow}")
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()
