#!/usr/bin/env python3
"""
터미널에서 푸시 알림 보내 보기 (앱에서 알림을 켠 기기로)

  python3 tools/push_test.py            테스트 알림
  python3 tools/push_test.py fire       가짜 화재 알림 (누르면 기록 탭이 열림)
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import envcheck                 # noqa: E402
envcheck.ensure_venv()

from notify.push import PushService   # noqa: E402


def main():
    push = PushService()
    if not push.subs:
        print("알림을 켠 기기가 없어요. 폰의 앱에서 설정 > 알림 켜기를 먼저 누르세요.")
        return
    fire = len(sys.argv) > 1 and sys.argv[1] == "fire"
    data = ({"title": "화재 감지", "body": "시험용 화재 알림이에요", "tag": "test-fire", "url": "/#records"}
            if fire else
            {"title": "테스트 알림", "body": "이 알림이 보이면 화재 알림도 이 폰으로 와요", "tag": "test", "url": "/"})
    for r in push.send_all(data, wait=True):
        ok = 200 <= r["code"] < 300
        dev = r["device"][:60] or "기기"
        print(f"{'보냄' if ok else '실패'}  {r['code']}  {dev}  {'' if ok else r['msg']}")


if __name__ == "__main__":
    main()
