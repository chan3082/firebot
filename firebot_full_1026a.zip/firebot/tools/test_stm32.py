#!/usr/bin/env python3
"""
STM32 동작 확인 및 회전 속도 보정 (반드시 바퀴 띄우고 시작)

  python3 tools/test_stm32.py              전진→후진→좌→우→회전 3초씩
  python3 tools/test_stm32.py rotate 5     회전만 5초
  python3 tools/test_stm32.py fwd 3        전진만 3초
  python3 tools/test_stm32.py calib        회전 속도 측정용 (바닥에 내려놓고 실행)

calib 는 config.TURN_SPEED 로 5초간 회전시킨다.
바닥에 표시를 해두고 몇 도 돌았는지 재서 config.TURN_RATE_DEG_S 에 넣으면
SCAN 의 45° 회전이 정확해진다. (자이로를 달면 필요 없어진다)
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import envcheck                 # noqa: E402
envcheck.ensure_venv()

import config                   # noqa: E402
from hw.stm32 import STM32      # noqa: E402

MOVES = {
    "fwd":    ("전진", (1.0, 0.0, 0.0)),
    "back":   ("후진", (-1.0, 0.0, 0.0)),
    "left":   ("좌이동", (0.0, 1.0, 0.0)),
    "right":  ("우이동", (0.0, -1.0, 0.0)),
    "rotate": ("반시계 회전", (0.0, 0.0, 1.0)),
}
ORDER = ["fwd", "back", "left", "right", "rotate"]


def hold(stm, v, seconds):
    end = time.time() + seconds
    while time.time() < end:
        stm.velocity(*v)
        time.sleep(1.0 / config.CTRL_HZ)


def main():
    args = sys.argv[1:]
    stm = STM32()
    time.sleep(1.0)
    print(f"펌웨어 상태: {stm.status or '(응답 없음)'}")
    stm.arm(True)
    time.sleep(0.3)

    try:
        if args and args[0] == "calib":
            print(f"\nTURN_SPEED={config.TURN_SPEED} 로 5초 회전. 돌아간 각도를 재세요")
            for i in (3, 2, 1):
                print(i); time.sleep(1)
            hold(stm, (0.0, 0.0, config.TURN_SPEED), 5.0)
            hold(stm, (0, 0, 0), 0.5)
            print("\n측정한 각도 / 5 = TURN_RATE_DEG_S 값")
            return

        if args and args[0] in MOVES:
            steps, dur = [args[0]], float(args[1]) if len(args) > 1 else 3.0
        else:
            steps, dur = ORDER, 3.0

        for key in steps:
            label, v = MOVES[key]
            print(f"[{label}] {dur:.0f}초")
            hold(stm, v, dur)
            hold(stm, (0, 0, 0), 0.7)
        print("완료")
    except KeyboardInterrupt:
        print("\n중단")
    finally:
        stm.close()


if __name__ == "__main__":
    main()
