#!/bin/bash
# 외부 https 주소 만들기 (Tailscale Funnel)
#   bash tools/setup_remote.sh
#
# 끝나면 https://<기기이름>.<tailnet이름>.ts.net 주소가 생긴다.
# 폰은 아무것도 설치하지 않고 이 주소로 들어가면 된다 (어느 망에서든).
# 설정은 재부팅해도 유지된다. 끄려면:  sudo tailscale funnel 8000 off
set -e

install_static() {
    # apt 저장소 목록을 못 받아 설치가 실패할 때가 있다 (2026-10 trixie 에서 겪음).
    # 그럴 땐 Tailscale 공식 실행 파일을 직접 받아 설치한다
    local tgz dir
    tgz=$(curl -fsSL "https://pkgs.tailscale.com/stable/?mode=json" |
          python3 -c "import json,sys; print(json.load(sys.stdin)['Tarballs']['arm64'])")
    dir=$(mktemp -d)
    curl -fsSL "https://pkgs.tailscale.com/stable/$tgz" | tar xz -C "$dir" --strip-components=1
    sudo install -m 755 "$dir/tailscale" /usr/bin/tailscale
    sudo install -m 755 "$dir/tailscaled" /usr/sbin/tailscaled
    sudo cp "$dir/systemd/tailscaled.service" /etc/systemd/system/
    [ -f /etc/default/tailscaled ] || sudo cp "$dir/systemd/tailscaled.defaults" /etc/default/tailscaled
    sudo systemctl daemon-reload
    sudo systemctl enable --now tailscaled
    rm -rf "$dir"
}

if ! command -v tailscale >/dev/null 2>&1; then
    echo "== 1/3 Tailscale 설치 =="
    curl -fsSL https://tailscale.com/install.sh | sh || true
    if ! command -v tailscale >/dev/null 2>&1; then
        echo "apt 로 설치가 안 돼서 실행 파일을 직접 받아 설치합니다"
        install_static
    fi
    tailscale version | head -1
else
    echo "== 1/3 Tailscale 이미 설치됨 =="
fi

echo
echo "== 2/3 로그인 =="
echo "아래에 https://login.tailscale.com/... 링크가 나오면 PC 브라우저로 열어서 로그인하세요."
echo "(구글 계정으로 가입해도 돼요. 무료)"
sudo tailscale up

echo
echo "== 3/3 외부 주소 열기 (웹 앱 8000번 포트) =="
echo "Funnel 이 아직 허용 안 된 계정이면 허용 링크가 나와요. 그 링크를 열어 허용한 뒤 이 스크립트를 다시 실행하세요."
sudo tailscale funnel --bg 8000

echo
sudo tailscale funnel status
echo
echo "위의 https://... 주소를 아이폰 Safari 로 여세요."
echo "처음 만든 주소는 몇 분 동안 접속이 안 될 수 있어요 (인증서 발급과 주소 등록 시간)."
