#!/usr/bin/env python3
"""
경로 기억하고 따라가기 (teach & repeat) 시뮬레이터

1) 기억: 사람이 앱 버튼으로 운전하는 것처럼 (제자리 회전 + 전진) 한 바퀴 몰고, 그동안 라이다 오도메트리로 길과 키 스캔을 모은다
2) 따라가기: 기억한 길을 여러 바퀴 돈다. 중간에 사람이 길을 막기도 하고, 25초마다 가면서 둘러보기도 한다
3) 실제 위치로 채점: 기억할 때 실제로 지나간 길에서 얼마나 벗어났나, 바퀴마다 출발점에 얼마나 정확히 돌아왔나

  python3 tools/sim_route.py                 전체 (앞왼쪽 바퀴 30% 느림 + 라이다 잡음)
  python3 tools/sim_route.py square_corridor 하나만
  python3 tools/sim_route.py --ideal         바퀴, 라이다 모두 이상적인 경우
  python3 tools/sim_route.py --plot          경로 그림 저장 (sim_route_<이름>.png)
"""
import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import config                                          # noqa: E402
import sim_avoid as S                                  # noqa: E402
from sim_avoid import box, wall, cast, collided, body_gap   # noqa: E402
from nav.avoidance import compute_clearance            # noqa: E402
from nav.navigator import Navigator                    # noqa: E402
from nav.odom import LidarOdom, wrap                   # noqa: E402
from nav.route import RouteLocalizer, RouteRecorder, RouteRunner   # noqa: E402
from nav.yaw import YawTracker                         # noqa: E402


def person_at(cx, cy):
    return box(cx - 0.12, cx + 0.12, cy - 0.2, cy + 0.2)


SCENES = {
    # ㅁ자 복도 (폭 1.2m, 가운데 막힌 건물 둘레). 반시계로 한 바퀴. 2바퀴째 위쪽 복도에 사람이 벽 쪽에 서 있음
    "square_corridor": dict(
        segs=box(0, 8, 0, 6) + box(1.2, 6.8, 1.2, 4.8),
        start=(2.0, 0.6, 0.0),
        teach=[(7.4, 0.6), (7.4, 5.4), (0.6, 5.4), (0.6, 0.6), (2.0, 0.6)],
        people=[(1, 0.3, 4.0, 5.5, 90.0)],     # (몇 바퀴째, 그 바퀴 진행률, x, y, 서 있는 시간 s)
        laps=3, max_t=600.0),
    # 가구가 있는 방 (7x5m) 에서 네모로 한 바퀴. 2바퀴째 길 한가운데 사람
    "room_loop": dict(
        segs=box(0, 7, 0, 5) + box(3.0, 4.2, 2.0, 3.0) + box(1.0, 3.0, 4.6, 5.0) + box(4.6, 5.0, 1.5, 1.9),
        start=(1.0, 1.0, 0.0),
        teach=[(6.0, 1.0), (6.0, 3.8), (1.0, 3.8), (1.0, 1.0)],
        people=[(1, 0.02, 3.5, 1.0, 25.0)],
        laps=3, max_t=480.0),
    # ㄱ자 복도 끝까지 갔다가 돌아오기 (열린 길). 2번 왕복
    "corridor_out_back": dict(
        segs=wall(-1, 0.6, 6.6, 0.6) + wall(6.6, 0.6, 6.6, -4) + wall(-1, -0.6, 5.4, -0.6)
        + wall(5.4, -0.6, 5.4, -4) + wall(-1, -0.6, -1, 0.6) + wall(5.4, -4, 6.6, -4),
        start=(0.0, 0.0, 0.0),
        teach=[(6.0, 0.0), (6.0, -3.0)],
        people=[],
        laps=4, max_t=360.0),
}


class World:
    """실제 로봇 위치와 라이다, 오도메트리. 명령을 받아 한 주기 움직인다"""

    def __init__(self, sc, noise):
        self.sc = sc
        self.px, self.py, self.th = sc["start"]
        self.t = 0.0
        self.step_n = 0
        self.tracker = YawTracker()
        self.odom = LidarOdom()
        self.noise = noise
        self.rng = np.random.default_rng(7)
        self.extra = []                 # 지금 서 있는 사람
        self.scan = None                # 이번 주기 라이다 점 (로봇 좌표계, 잡음 포함)
        self.new_scan = False
        self.min_gap = math.inf

    def sense(self):
        segs = self.sc["segs"] + self.extra
        x, y = cast((self.px, self.py, self.th), segs)
        if collided(x, y):
            raise RuntimeError(f"충돌 (t={self.t:.1f}s, 위치 {self.px:.2f},{self.py:.2f})")
        self.min_gap = min(self.min_gap, body_gap(x, y))
        if self.noise:
            r = np.hypot(x, y)
            k = 1.0 + self.rng.normal(0.0, 0.01 + 0.01 * r) / np.maximum(r, 1e-6)
            x, y = x * k, y * k
        self.scan = (x, y)
        self.new_scan = self.step_n % S.LIDAR_EVERY == 0
        if self.new_scan:
            y0 = self.tracker.yaw
            self.tracker.update(x, y, self.t)
            dyaw = math.radians(self.tracker.yaw - y0) if self.tracker.healthy(self.t) else None
            self.odom.update(x, y, self.tracker.orient_now(self.t), dyaw)
        return x, y

    def act(self, vx, vy, wz):
        self.odom.add_motion(vx, vy, wz, S.DT)
        ax, ay, aw = S.wheel_effect(vx, vy, wz)
        sx, sy = ax * S.LIN_MS, ay * S.LIN_MS
        self.px += (sx * math.cos(self.th) - sy * math.sin(self.th)) * S.DT
        self.py += (sx * math.sin(self.th) + sy * math.cos(self.th)) * S.DT
        self.th += math.radians(aw * S.ANG_DEG_S * S.TURN_SCALE) * S.DT
        self.t += S.DT
        self.step_n += 1


def teach(world, waypoints):
    """사람이 앱으로 운전: 목표 쪽으로 제자리에서 돌고, 앞으로 간다 (실제 위치를 보면서 바로잡음)"""
    rec = RouteRecorder()
    world.odom.reset()
    for wx, wy in waypoints:
        while True:
            x, y = world.sense()
            if world.new_scan:
                rec.add(world.odom.pose, x, y)
                rec.true_path.append((world.px, world.py))
            dx, dy = wx - world.px, wy - world.py
            d = math.hypot(dx, dy)
            if d < 0.08:
                break
            err = math.degrees(wrap(math.atan2(dy, dx) - world.th))
            if abs(err) > 8 and d > 0.25:
                world.act(0.0, 0.0, math.copysign(config.TURN_SPEED, err))
            else:
                world.act(min(config.CRUISE_SPEED, 0.15 + d), 0.0, max(-0.15, min(0.15, 0.03 * err)))
            if world.t > 600:
                raise RuntimeError("기억 운전이 끝나지 않음")
    x, y = world.sense()
    route, msg = rec.finish(x, y, world.odom.pose)
    rec.true_path.append((world.px, world.py))
    return route, msg, np.array(rec.true_path)


def _dist_to_poly(p, poly):
    a, b = poly[:-1], poly[1:]
    ab = b - a
    t = np.clip(((p - a) * ab).sum(1) / np.maximum((ab * ab).sum(1), 1e-9), 0, 1)
    q = a + ab * t[:, None]
    return float(np.min(np.hypot(*(p - q).T)))


def repeat(world, route, true_path, sc, sweep_every=25.0):
    loc = RouteLocalizer(route)
    x, y = world.sense()
    # 기억을 끝낸 그 자리에서 바로 시작하면 오도메트리 자세를 그대로 이어서 쓴다 (프로그램을 새로 켰을 때만 찾기)
    runner = RouteRunner(route, world.odom)
    nav = Navigator(world.tracker)
    nav.set_route(runner, world.t)
    t_start = world.t
    last_sweep = world.t
    errs, homes, states, dodge_errs = [], [], [], []
    recent_person = -1.0
    trail = []
    lap_seen = 0
    people = list(sc.get("people", []))
    person_until = None
    scans = 0
    events = []
    while world.t - t_start < sc["max_t"] and runner.laps < sc["laps"]:
        # 사람: 지정한 바퀴에 들어서면 길 위에 서 있다가 비켜줌
        if people and runner.laps == people[0][0] and runner.progress() > people[0][1] and person_until is None:
            _, _, cx, cy, dur = people.pop(0)
            world.extra = person_at(cx, cy)
            person_until = world.t + dur
        if person_until is not None and world.t > person_until:
            world.extra, person_until = [], None
        x, y = world.sense()
        if world.new_scan:
            scans += 1
            if scans % 2 == 0:
                fixed, li = loc.localize(x, y, world.odom.pose)
                if fixed is not None:
                    p = world.odom.pose
                    blend = p + 0.5 * np.array([fixed[0] - p[0], fixed[1] - p[1], wrap(fixed[2] - p[2])])
                    blend[2] = wrap(blend[2])
                    world.odom.nudge(None, full=blend)
        if world.t - last_sweep > sweep_every and nav.state == "ROUTE":
            nav.start_sweep(world.t)
            last_sweep = world.t
        c = compute_clearance(x, y)
        vx, vy, wz = nav.drive((x, y), c, world.t)
        if nav.state == "SWEEP":
            last_sweep = world.t
        world.act(vx, vy, wz)
        if nav.last_event and (not events or events[-1][1] != nav.last_event):
            events.append((world.t, nav.last_event))
        e = _dist_to_poly(np.array([world.px, world.py]), true_path)
        near_person = bool(world.extra) and any(
            math.hypot(world.px - (a[0] + b[0]) / 2, world.py - (a[1] + b[1]) / 2) < 2.5 for a, b in world.extra[:1])
        # 사람을 비켜 갔다가 길로 다시 붙을 때까지(길에서 15cm 안)는 비키기 구간으로 친다
        if near_person or recent_person > world.t or (recent_person > 0 and e > 0.15):
            recent_person = max(recent_person, world.t + 4.0) if near_person else recent_person
            if not near_person and recent_person <= world.t:
                recent_person = 1e-3 if e > 0.15 else -1.0
            dodge_errs.append(e)
        else:
            errs.append(e)
        states.append(nav.state)
        trail.append((world.px, world.py, world.th, nav.state))
        if runner.laps > lap_seen:
            lap_seen = runner.laps
            # 출발점(열린 길이면 그 끝점) 근처를 지나는 동안 가장 가까웠던 거리
            if route.closed:
                home = true_path[0]
            else:
                home = true_path[-1] if runner.laps % 2 else true_path[0]
            near = [math.hypot(px - home[0], py - home[1]) for px, py, _, _ in trail[-80:]]
            homes.append(min(near))
    return dict(errs=np.array(errs), dodge_errs=np.array(dodge_errs or [0.0]), homes=homes, laps=runner.laps, time=world.t - t_start,
                states=states, trail=np.array([t[:3] for t in trail]), events=events)


def run(name, noise=True, weak=0.7, plot=False):
    sc = SCENES[name]
    S.WEAK_WHEEL = weak
    world = World(sc, noise)
    route, msg, true_path = teach(world, sc["teach"])
    if route is None:
        return False, "기억 실패: " + msg
    res = repeat(world, route, true_path, sc)
    e = res["errs"]
    ok = res["laps"] >= sc["laps"] and e.max() < 0.35
    homes = ", ".join(f"{h * 100:.0f}" for h in res["homes"])
    used = sorted(set(res["states"]), key=res["states"].index)
    text = (f"기억: {route.length:.1f}m, 키 스캔 {len(route.kf_pts)}개, {msg}\n"
            f"         따라가기: {res['laps']}/{sc['laps']}{'바퀴' if route.closed else '번 끝까지'} {res['time']:.0f}초, "
            f"길에서 벗어난 거리 평균 {e.mean() * 100:.0f}cm 최대 {e.max() * 100:.0f}cm "
            f"(사람 비킬 때 최대 {res['dodge_errs'].max() * 100:.0f}cm), "
            f"출발점(끝점)을 지날 때 거리 [{homes}]cm, 벽까지 최소 {world.min_gap * 100:.0f}cm\n"
            f"         상태: {' → '.join(used)}\n"
            f"         일: {' / '.join(f'{t:.0f}s {e}' for t, e in res['events'] if '바퀴' not in e and '둘러보기' not in e)[:400]}")
    if plot:
        _plot(name, sc, true_path, res, route)
    return ok, text


def _plot(name, sc, true_path, res, route):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(8, 6), dpi=130)
    for (x1, y1), (x2, y2) in sc["segs"]:
        ax.plot([x1, x2], [y1, y2], color="#444", lw=2.5)
    ax.plot(true_path[:, 0], true_path[:, 1], color="#999", lw=6, alpha=0.5, label="taught")
    tr = res["trail"]
    ax.plot(tr[:, 0], tr[:, 1], color="#2a78d6", lw=1, label="repeat")
    ax.set_aspect("equal")
    ax.legend()
    out = f"sim_route_{name}.png"
    plt.savefig(out)
    print("   그림:", out)


def main():
    names = [a for a in sys.argv[1:] if not a.startswith("-")] or list(SCENES)
    ideal = "--ideal" in sys.argv
    plot = "--plot" in sys.argv
    print("조건:", "이상적" if ideal else "앞왼쪽 바퀴 30% 느림 + 라이다 잡음")
    ok_all = True
    for n in names:
        try:
            ok, text = run(n, noise=not ideal, weak=1.0 if ideal else 0.7, plot=plot)
        except RuntimeError as e:
            ok, text = False, str(e)
        ok_all &= ok
        print(f"[{'통과' if ok else '실패'}] {n:18s} {text}")
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()
