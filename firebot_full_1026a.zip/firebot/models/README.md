# YOLO 가중치

## 들어 있는 모델

| 파일 | 구조 | 클래스 | 출처 |
|---|---|---|---|
| `fire_ncnn_model/` (실제로 쓰는 것) | fire.pt 를 NCNN(fp16)으로 변환 | fire, smoke | 아래 fire.pt 와 같음 |
| `fire.pt` | YOLOv8s, 22MB | fire, smoke | https://github.com/yeabsra2000/fire_ml |
| `fire_light.pt` | YOLOv8n, 6MB | fire, other, smoke | https://github.com/Nocluee100/Fire-and-Smoke-Detection-yolov8-v1 |

`config.py` 의 `YOLO_MODEL` 로 고른다. 보고서와 저장소에는 위 출처를 밝혀 둘 것.

## 고른 이유 (2026-09-29 비교 시험)

실제 차량 화재 영상 10장면, 헷갈리는 이미지 7장(빨간 소화기 2, 빨간 화면, 빨강-주황 그라데이션,
따뜻한 조명, 노을, 빨간 로고가 있는 그림)으로 공개 모델 8개를 비교했다.

| 모델 | 화재 검출 (10장면) | 오탐 (7장) | 비고 |
|---|---|---|---|
| 이전 모델 (FireAIoTSystem) | **0** | 1 | 모형 환경 전용으로 보임. 실제 화재 못 잡음 |
| fire.pt (yeabsra) | 9 | 0 | 작게 찍힌 화면 속 불에 가장 강함 |
| fire_light.pt (nocluee) | 10 | 0 | 가볍고 빠름, 작은 불엔 약함 |
| 그 외 5개 | 0~10 | 0~1 | 빨간 화면을 불로 오탐하거나, 멀면 못 잡음 |

복도 배경에 폰/태블릿 화면 크기로 불 영상을 작게 붙여 시험한 결과 (imgsz 640, 10장 중 검출 수)

| 화면이 차지하는 가로 비율 | fire.pt | fire_light.pt |
|---|---|---|
| 8% (1.5m 거리 폰) | 9 | 0 |
| 12% | 8 | 6 |
| 18% (1.5m 거리 태블릿) | 9 | 9 |
| 30% | 10 | 9 |

시연할 때는 폰보다 **태블릿이나 노트북 화면**에, **1m 안팎 거리**로 두는 게 안전하다.

## 속도와 CPU

`fire_ncnn_model/` 이 있으면 자동으로 그걸 쓴다 (`config.YOLO_PREFER_NCNN`).
NCNN 은 RPi 에서 PyTorch 보다 몇 배 빠르고 CPU 를 덜 쓴다. 변환 전후 정확도는 같았다
(화재 10장면 10/10, 평균 신뢰도 0.83, 빨간 화면 오탐 0).

추론은 CPU 코어 4개 중 2개만 쓰고(`config.YOLO_THREADS`), 우선순위를 낮춰서 돈다.
코어를 다 쓰면 VS Code 원격 접속과 웹 앱이 CPU 를 못 받아 연결이 끊기기 때문이다.

`python3 tools/test_camera.py` 출력의 `추론 ...ms` 를 보고

| 상황 | 조치 |
|---|---|
| 500ms 이하 | 그대로 |
| 느림 | `config.YOLO_IMGSZ = 416` (작은 불은 덜 잡힘) 또는 `YOLO_MODEL` 을 `fire_light.pt` 로 |
| 원격 접속이 그래도 끊김 | `YOLO_THREADS = 1` |

모델을 다시 변환하려면

```bash
yolo export model=models/fire.pt format=ncnn imgsz=640 half=True
```
