"""
주행 기록 (블랙박스)

main.py 가 달리는 동안 라이다 스캔, 오도메트리 위치, 보낸 명령, 상태를 최근 RECORD_SEC 초만큼 들고 있다가
logs/run_날짜_시각.npz 로 저장한다 (2분마다, 그리고 끌 때). 이상하게 움직였으면 이 파일을 보내 주면
로봇이 그때 본 것을 그대로 다시 볼 수 있다. 파일은 최근 RECORD_KEEP 개만 남긴다.
"""
import json
import threading
import time
from collections import deque

import numpy as np

import config


class BlackBox:
    def __init__(self, info=None):
        self.dir = config.BASE_DIR / "logs"
        self.dir.mkdir(exist_ok=True)
        self.path = self.dir / time.strftime("run_%Y%m%d_%H%M%S.npz")
        self.keep_sec = float(getattr(config, "RECORD_SEC", 900))
        self.scans = deque()          # (t, scan_id, pts float16 (n,2), pose (3,), dyaw)
        self.rows = deque()           # (t, scan_id, cmd(3), state, avoid, event, h_err, clearance(4), mode)
        self.info = dict(info or {})
        self.info.update({
            "HALF_LENGTH": config.HALF_LENGTH, "HALF_WIDTH": config.HALF_WIDTH,
            "LIDAR_MOUNT_YAW": config.LIDAR_MOUNT_YAW, "LIDAR_INVERTED": config.LIDAR_INVERTED,
            "LIDAR_OFFSET": list(config.LIDAR_OFFSET), "NAV_STYLE": getattr(config, "NAV_STYLE", ""),
            "TURN_RATE_DEG_S": config.TURN_RATE_DEG_S, "started": time.strftime("%Y-%m-%d %H:%M:%S"),
        })
        self._lock = threading.Lock()
        self._saving = False
        self._last_save = time.time()
        self._prune_files()

    def add_scan(self, t, scan_id, x, y, pose, dyaw):
        pts = np.stack([x, y], 1).astype(np.float16)
        with self._lock:
            self.scans.append((t, scan_id, pts, np.asarray(pose, np.float32), np.nan if dyaw is None else dyaw))
            while self.scans and t - self.scans[0][0] > self.keep_sec:
                self.scans.popleft()

    def add_row(self, t, scan_id, cmd, state, avoid, event, h_err, c, mode):
        cl = (np.nan,) * 4 if c is None else (c.front, c.left, c.right, c.rear)
        with self._lock:
            self.rows.append((t, scan_id, tuple(cmd), state or "", avoid or "", event or "",
                              np.nan if h_err is None else h_err, cl, mode))
            while self.rows and t - self.rows[0][0] > self.keep_sec:
                self.rows.popleft()
        if t - self._last_save > 120 and not self._saving:
            self._last_save = t
            self.save(background=True)

    def note(self, **kw):
        self.info.update(kw)

    def save(self, background=False):
        with self._lock:
            scans, rows, info = list(self.scans), list(self.rows), dict(self.info)
        if not scans and not rows:
            return
        if background:
            self._saving = True
            threading.Thread(target=self._write, args=(scans, rows, info), daemon=True).start()
        else:
            self._write(scans, rows, info)

    def _write(self, scans, rows, info):
        try:
            n = np.array([len(s[2]) for s in scans], np.int32)
            data = {
                "scan_t": np.array([s[0] for s in scans]),
                "scan_id": np.array([s[1] for s in scans], np.int64),
                "scan_n": n,
                "scan_pts": np.concatenate([s[2] for s in scans]) if scans else np.zeros((0, 2), np.float16),
                "scan_pose": np.array([s[3] for s in scans], np.float32).reshape(-1, 3),
                "scan_dyaw": np.array([s[4] for s in scans], np.float32),
                "t": np.array([r[0] for r in rows]),
                "row_scan": np.array([r[1] for r in rows], np.int64),
                "cmd": np.array([r[2] for r in rows], np.float32).reshape(-1, 3),
                "state": np.array([r[3] for r in rows], dtype=str),
                "avoid": np.array([r[4] for r in rows], dtype=str),
                "event": np.array([r[5] for r in rows], dtype=str),
                "h_err": np.array([r[6] for r in rows], np.float32),
                "clear": np.array([r[7] for r in rows], np.float32).reshape(-1, 4),
                "mode": np.array([r[8] for r in rows], dtype=str),
                "info": np.array(json.dumps(info, ensure_ascii=False)),
            }
            tmp = self.path.with_suffix(".tmp.npz")
            np.savez_compressed(tmp, **data)
            tmp.replace(self.path)
        except Exception as e:
            print(f"[기록] 저장 실패 ({e})")
        finally:
            self._saving = False

    def _prune_files(self):
        keep = int(getattr(config, "RECORD_KEEP", 5))
        files = sorted(self.dir.glob("run_*.npz"))
        for f in files[:max(0, len(files) - (keep - 1))]:
            try:
                f.unlink()
            except OSError:
                pass
