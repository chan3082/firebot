"""
경로 기억과 따라가기 (teach & repeat). SLAM 처럼 지도를 만들지는 않는다

  RouteRecorder   앱으로 한 번 직접 운전하는 동안 지나간 길(자세)과 '키 스캔'(40cm 또는 20°마다 라이다 스캔)을 모은다
                  끝낼 때 출발점 근처면 마지막 스캔을 첫 키 스캔과 맞춰서 한 바퀴 동안 쌓인 오차를 길 전체에 나눠서 지운다
  Route           기억한 길. data/route.npz 에 저장
  RouteLocalizer  따라갈 때 지금 스캔을 가장 가까운 키 스캔과 맞춰서 위치를 다시 잡는다 (오차가 쌓이지 않음)
                  처음 시작할 때는 모든 키 스캔과 맞춰 보고 어디쯤인지 찾는다
  RouteRunner     따라가는 중 진행 상황 (몇 % 왔나, 몇 바퀴째, 다음에 갈 곳). Navigator 가 매 주기 guide() 를 부른다

닫힌 길(끝이 출발점 근처)은 계속 돌고, 열린 길(끝이 멀리)은 끝에서 돌아서 왔던 길로 돌아오기를 반복한다.
좌표는 기억을 시작할 때 로봇 위치가 (0, 0), 앞 +x, 왼쪽 +y (nav/odom.py 와 같음)
"""
import math
import time

import numpy as np

import config
from nav.odom import ScanMatcher, _prep, compose, relative, wrap

PATH_STEP = 0.05                 # 길 점 간격 (m)
PATH_ROT = math.radians(3)
KF_STEP = 0.40                   # 키 스캔 간격 (m)
KF_ROT = math.radians(20)
CLOSE_DIST = 1.5                 # 기억을 끝낼 때 출발점에서 이 안이면 닫힌 길 (한 바퀴)
# 다시 켰을 때 출발점 키 스캔과 이만큼 맞으면 출발점으로 믿음 (맞은 점 비율, 오차 m).
# 라이다 잡음 때문에 출발점에 정확히 놓아도 0.7~0.8 정도 나온다. 복도처럼 비슷하게 생긴 곳이 많으면
# 다른 곳에 놓아도 출발점으로 믿을 수 있으니 꼭 출발점에 놓고 시작
START_INLIER = 0.6
START_RMS = 0.04


def _arc(path):
    d = np.hypot(np.diff(path[:, 0]), np.diff(path[:, 1]))
    return np.r_[0.0, np.cumsum(d)]


class Route:
    def __init__(self, path, kf_poses, kf_pts, closed, created=None):
        self.path = np.asarray(path, float).reshape(-1, 3)
        self.kf_poses = np.asarray(kf_poses, float).reshape(-1, 3)
        self.kf_pts = [np.asarray(p, np.float32).reshape(-1, 2) for p in kf_pts]
        self.closed = bool(closed)
        self.created = created or time.time()
        self.s = _arc(self.path)
        self.length = float(self.s[-1])
        if self.closed:
            self.length += float(np.hypot(*(self.path[0, :2] - self.path[-1, :2])))

    # ---------------- 저장 ----------------
    def save(self, file):
        idx = np.cumsum([0] + [len(p) for p in self.kf_pts])
        pts = np.concatenate(self.kf_pts) if self.kf_pts else np.zeros((0, 2), np.float32)
        np.savez_compressed(file, path=self.path, kf_poses=self.kf_poses, kf_pts=pts, kf_idx=idx,
                            closed=self.closed, created=self.created)

    @classmethod
    def load(cls, file):
        d = np.load(file)
        idx = d["kf_idx"]
        pts = [d["kf_pts"][idx[i]:idx[i + 1]] for i in range(len(idx) - 1)]
        return cls(d["path"], d["kf_poses"], pts, bool(d["closed"]), float(d["created"]))

    def summary(self, max_pts=400):
        """웹 앱 지도용"""
        step = max(1, len(self.path) // max_pts)
        p = self.path[::step]
        return {"closed": self.closed, "length": round(self.length, 1), "keyframes": len(self.kf_pts),
                "created": self.created,
                "path": [[round(float(a), 2), round(float(b), 2)] for a, b, _ in p]}


class RouteRecorder:
    def __init__(self):
        self.path = []
        self.kf_poses = []
        self.kf_pts = []
        self.true_path = []             # 시뮬레이터 평가용 (실제 로봇에서는 안 씀)

    @property
    def length(self):
        if len(self.path) < 2:
            return 0.0
        return float(_arc(np.array(self.path))[-1])

    def add(self, pose, x, y):
        """기억하는 동안 새 스캔마다. pose: 오도메트리 자세, x, y: 그 스캔 (로봇 좌표계)"""
        pose = np.array(pose, float)
        if not self.path:
            self.path.append(pose)
        else:
            r = relative(self.path[-1], pose)
            if math.hypot(r[0], r[1]) >= PATH_STEP or abs(r[2]) >= PATH_ROT:
                self.path.append(pose)
        if not self.kf_poses:
            self._kf(pose, x, y)
        else:
            r = relative(self.kf_poses[-1], pose)
            if math.hypot(r[0], r[1]) >= KF_STEP or abs(r[2]) >= KF_ROT:
                self._kf(pose, x, y)

    def _kf(self, pose, x, y):
        px, py = _prep(x, y, 0.03)
        if px.size < 40:
            return
        self.kf_poses.append(pose.copy())
        self.kf_pts.append(np.c_[px, py].astype(np.float32))

    def finish(self, x, y, pose):
        """
        기억 끝. 출발점 근처면 닫힌 길로 만들고 쌓인 오차를 나눠서 지운다.
        반환: (Route 또는 None, 설명)
        """
        pose = np.array(pose, float)
        self.add(pose, x, y)
        if self.length < 1.0 or len(self.kf_pts) < 2:
            return None, "너무 짧음 (1m 이상 움직여야 함)"
        path = np.array(self.path)
        kfp = np.array(self.kf_poses)
        start = kfp[0]
        closed = False
        msg = "열린 길 (끝에서 돌아서 왔던 길로 돌아옴)"
        if math.hypot(*(pose[:2] - start[:2])) < CLOSE_DIST:
            m = ScanMatcher(self.kf_pts[0][:, 0], self.kf_pts[0][:, 1])
            guess = relative(start, pose)
            p, info = m.match(x, y, guess, (0.5, 0.5, math.radians(30)))
            if p is not None and info["inlier"] > 0.5 and info["rms"] < 0.045:
                true_end = compose(start, p)
                err = np.array([true_end[0] - pose[0], true_end[1] - pose[1], wrap(true_end[2] - pose[2])])
                path = _spread(path, err)
                kfp = _spread(kfp, err, ref=path, ref_raw=np.array(self.path))
                closed = True
                msg = f"닫힌 길 (한 바퀴 오차 {math.hypot(err[0], err[1]) * 100:.0f}cm, {math.degrees(err[2]):+.1f}° 를 길 전체에 나눠 지움)"
            else:
                closed = True
                msg = "닫힌 길 (출발점 스캔과 맞추기는 실패, 오차 보정 없이 저장)"
        return Route(path, kfp, self.kf_pts, closed), msg


def _spread(poses, err, ref=None, ref_raw=None):
    """한 바퀴 동안 쌓인 오차 err 를 이동 거리 비율대로 나눠서 더한다 (시작 0 → 끝 err)"""
    poses = np.array(poses, float)
    if ref is None:
        s = _arc(poses)
        f = s / max(s[-1], 1e-6)
    else:
        # 키 스캔은 길 위의 가장 가까운 점의 비율을 쓴다
        s_raw = _arc(ref_raw)
        frac = s_raw / max(s_raw[-1], 1e-6)
        f = np.array([frac[int(np.argmin(np.hypot(ref_raw[:, 0] - p[0], ref_raw[:, 1] - p[1])))]
                      for p in poses])
    out = poses.copy()
    out[:, 0] += f * err[0]
    out[:, 1] += f * err[1]
    out[:, 2] = [wrap(a + fi * err[2]) for a, fi in zip(out[:, 2], f)]
    return out


class RouteLocalizer:
    def __init__(self, route):
        self.route = route
        self._cache = {}

    def _matcher(self, k):
        m = self._cache.get(k)
        if m is None:
            pts = self.route.kf_pts[k]
            m = ScanMatcher(pts[:, 0], pts[:, 1])
            self._cache[k] = m
            if len(self._cache) > 60:
                self._cache.pop(next(iter(self._cache)))
        return m

    def localize(self, x, y, pose, max_dist=1.5):
        """지금 스캔을 가까운 키 스캔과 맞춤. 반환: (바로잡은 자세 또는 None, 정보)"""
        kp = self.route.kf_poses
        d = np.hypot(kp[:, 0] - pose[0], kp[:, 1] - pose[1])
        ok = d < max_dist                        # 라이다는 360° 라 방향이 반대여도 맞출 수 있다 (돌아오는 길)
        if not ok.any():
            return None, {"why": "가까운 키 스캔 없음"}
        best = None
        for k in np.argsort(np.where(ok, d, np.inf))[:2]:
            if not ok[k]:
                continue
            m = self._matcher(int(k))
            guess = relative(kp[k], pose)
            p, info = m.match(x, y, guess, (0.3, 0.3, math.radians(15)))
            if p is None or info["inlier"] < 0.5 or info["rms"] > 0.04:
                continue
            score = info["inlier"] - 3 * info["rms"]
            if best is None or score > best[0]:
                best = (score, compose(kp[k], p), info, int(k))
        if best is None:
            return None, {"why": "맞추기 실패"}
        best[2]["kf"] = best[3]
        return best[1], best[2]

    def global_localize(self, x, y, prefer_start=True):
        """
        처음 시작할 때 (프로그램을 새로 켰을 때): 키 스캔에 맞춰 보고 어디인지 찾는다. 반환: (자세 또는 None, 정보)
        복도는 여러 곳이 비슷하게 생겨서 헷갈릴 수 있으므로, 출발점(첫 키 스캔)에 기억할 때와 같은 방향으로
        놓여 있으면 그걸 먼저 믿는다. 아니면 전부 맞춰 보고, 1등과 2등이 서로 먼 곳인데 점수가 비슷하면 모른다고 한다
        """
        if prefer_start:
            m = self._matcher(0)
            p, info = m.match(x, y, (0.0, 0.0, 0.0), (0.5, 0.5, math.radians(30)))
            if p is not None and info["inlier"] > START_INLIER and info["rms"] < START_RMS:
                info["kf"] = 0
                return compose(self.route.kf_poses[0], p), info
        found = []
        for k in range(len(self.route.kf_pts)):
            m = self._matcher(k)
            for dth in (0.0, math.pi / 2, -math.pi / 2, math.pi):
                p, info = m.match(x, y, (0.0, 0.0, dth), (0.6, 0.6, math.radians(40)))
                if p is None or info["inlier"] < 0.6 or info["rms"] > 0.04:
                    continue
                found.append((info["inlier"] - 3 * info["rms"], compose(self.route.kf_poses[k], p), info, k))
        if not found:
            return None, {"why": "기억한 길의 어느 곳과도 맞지 않음. 출발점에 기억할 때와 같은 방향으로 놓고 다시 시작"}
        found.sort(key=lambda f: -f[0])
        best = found[0]
        for other in found[1:]:
            far = math.hypot(*(other[1][:2] - best[1][:2])) > 1.0 or abs(wrap(other[1][2] - best[1][2])) > 0.5
            if far and other[0] > best[0] - 0.05:
                return None, {"why": "비슷하게 생긴 곳이 여러 군데라 헷갈림. 출발점에 기억할 때와 같은 방향으로 놓고 다시 시작"}
        best[2]["kf"] = best[3]
        return best[1], best[2]


def _find_corners(p, s, min_turn=math.radians(30), span=0.3):
    """
    길에서 크게 꺾이는 곳 (제자리에서 돌았거나 span m 안에서 30° 이상 돈 곳). [(시작 번호, 끝 번호), ...]
    """
    n = len(p)
    if n < 3:
        return []
    jj = np.minimum(np.searchsorted(s, s + span, side="right") - 1, n - 1)
    big = np.array([abs(wrap(p[j, 2] - p[i, 2])) >= min_turn for i, j in enumerate(jj)])
    corners = []
    i = 0
    while i < n:
        if not big[i]:
            i += 1
            continue
        a = i
        while i < n and big[i]:
            i += 1
        last = i - 1
        # 실제로 돌기 시작한 점과 다 돈 점으로 좁힘
        th0, th1 = p[a, 2], p[jj[last], 2]
        total = wrap(th1 - th0)
        seg = range(a, jj[last] + 1)
        ca = next(k for k in seg if abs(wrap(p[k, 2] - th0)) > 0.1 * abs(total))
        cb = next(k for k in seg if abs(wrap(p[k, 2] - th0)) >= 0.9 * abs(total))
        corners.append((max(a, ca - 1), cb))
    return corners


class RouteRunner:
    """기억한 길을 따라가는 진행 상황"""

    def __init__(self, route, odom):
        self.route = route
        self.odom = odom
        self.laps = 0                   # 닫힌 길: 다 돈 바퀴 수 / 열린 길: 끝까지 간 횟수
        self.forward = True             # 열린 길에서 지금 가는 방향
        self.ret_j = None               # 길로 돌아오는 중이면 목표 길 점 (곧은 대각선으로 가려고 고정)
        self.allow_return = True        # Navigator 가 길 따라가기(ROUTE) 상태일 때만 True
        self._set_path(route.path)
        self.i = self._nearest_all(odom.pose)
        if route.closed and math.hypot(*(odom.pose[:2] - route.path[0, :2])) < 0.6:
            self.i = 0                  # 닫힌 길의 출발점 = 끝점: 처음부터 시작 (끝으로 보고 바퀴를 하나 더 세지 않게)
        self.last = {}

    def _set_path(self, path):
        self.path = np.asarray(path, float)
        self.s = _arc(self.path)
        self.n = len(self.path)
        if self.route.closed:
            # 한 바퀴 뒤를 이어 붙여서 끝 → 처음이 자연스럽게 이어지게
            gap = float(np.hypot(*(self.path[0, :2] - self.path[-1, :2])))
            self.p2 = np.vstack([self.path, self.path])
            self.s2 = np.r_[self.s, self.s + self.s[-1] + gap]
        else:
            self.p2, self.s2 = self.path, self.s
        self.corners = _find_corners(self.p2, self.s2)

    def _nearest_all(self, pose):
        d = np.hypot(self.path[:, 0] - pose[0], self.path[:, 1] - pose[1])
        dth = np.abs([wrap(a - pose[2]) for a in self.path[:, 2]])
        return int(np.argmin(d + 0.3 * dth))

    def peek(self, ahead):
        """지금 위치에서 길을 따라 ahead m 앞 점: (몸 기준 방향 rad, 그곳에서 몸이 봐야 할 방향 오차 rad)"""
        pose = self.odom.pose
        si = self.s2[self.i]
        j = min(int(np.searchsorted(self.s2, si + ahead)), len(self.p2) - 1)
        k = min(int(np.searchsorted(self.s2, si + ahead, side="right")) - 1, len(self.p2) - 1)
        phi_w = math.atan2(self.p2[j, 1] - pose[1], self.p2[j, 0] - pose[0])
        return wrap(phi_w - pose[2]), wrap(self.p2[max(k, j), 2] - pose[2])

    def progress(self):
        return float(self.s[min(self.i, self.n - 1)] / max(self.s[-1], 1e-6))

    def guide(self):
        """
        반환 dict (몸 기준 각도, rad):
          phi        가야 할 방향 (앞을 볼 점 쪽)
          phi_path   길이 뻗은 방향 (길과 나란히)
          th_err     몸을 돌려야 할 각도 (기억할 때 몸이 보던 방향 기준, 반시계 +)
          cross      길에서 옆으로 벗어난 거리 (m, 왼쪽 +)
          look       앞을 볼 점까지 거리 (m)
          event      바퀴를 다 돌았거나 끝에서 돌아설 때 설명
        """
        pose = self.odom.pose
        ev = ""
        # 지금 길 위 어디쯤인지 (앞뒤 일정 구간 안에서만 찾아서 엉뚱한 곳으로 건너뛰지 않게)
        s_now = self.s2[self.i]
        lo = int(np.searchsorted(self.s2, s_now - 0.3))
        hi = int(np.searchsorted(self.s2, s_now + 2.0)) + 1
        seg = self.p2[lo:hi]
        if len(seg) == 0:
            return None
        d = np.hypot(seg[:, 0] - pose[0], seg[:, 1] - pose[1])
        self.i = lo + int(np.argmin(d))
        if self.route.closed and self.i >= self.n:
            self.i -= self.n
            if self.ret_j is not None:
                self.ret_j -= self.n
            self.laps += 1
            ev = f"한 바퀴 완료 ({self.laps}바퀴째 끝, 출발점 지남)"
        if not self.route.closed and self.s[-1] - self.s2[self.i] < 0.15:
            # 열린 길의 끝: 돌아서 왔던 길로
            self.forward = not self.forward
            self.laps += 1
            rev = self.path[::-1].copy()
            rev[:, 2] = [wrap(a + math.pi) for a in rev[:, 2]]
            self._set_path(rev)
            self.i = 0
            self.ret_j = None
            ev = "길 끝 도착 → 돌아서 왔던 길로"
        i = self.i
        si = self.s2[i]
        # 기억할 때 몸이 보던 방향 (조금 앞의 점 기준. 제자리에서 돈 곳이면 돈 뒤의 방향)
        k = min(int(np.searchsorted(self.s2, si + 0.25, side="right")) - 1, len(self.p2) - 1)
        k = max(k, i)
        th_d = self.p2[k, 2]
        # 길 방향과 옆으로 벗어난 거리
        a = max(0, i - 2)
        b = min(len(self.p2) - 1, i + 2)
        if self.s2[b] - self.s2[a] < 1e-3:
            tang = th_d
        else:
            tang = math.atan2(self.p2[b, 1] - self.p2[a, 1], self.p2[b, 0] - self.p2[a, 0])
        ex, ey = pose[0] - self.p2[i, 0], pose[1] - self.p2[i, 1]
        cross = -math.sin(tang) * ex + math.cos(tang) * ey

        # 어디를 보고 갈지
        look = config.RETURN_DIST
        corner = None
        for a, b in self.corners:
            if b > i and self.s2[a] - si < look:
                corner = (a, b)
                break
        if corner is not None:
            # 곧 크게 꺾임: 꺾이는 곳까지는 그 점을 보고 가다가, 12cm 안으로 들어오면 꺾인 뒤 길 40cm 앞을 본다
            # (모퉁이를 가로지르지 않고 꺾이는 곳까지 가서, 미끄러지며 돈다)
            self.ret_j = None
            a, b = corner
            if i < a and self.s2[a] - si > 0.12 and math.hypot(self.p2[a, 0] - pose[0], self.p2[a, 1] - pose[1]) > 0.12:
                j = a
            else:
                j = min(int(np.searchsorted(self.s2, self.s2[b] + 0.4)), len(self.p2) - 1)
                th_d = self.p2[b, 2]
        else:
            # 길에서 벗어나 있으면: 돌아오기 시작할 때 1m(RETURN_DIST) 앞 길 점을 정해 두고 그 점까지 곧게 (그림 ①)
            if not self.allow_return:
                self.ret_j = None                        # 비키는 중에는 정하지 않음 (다 비킨 뒤에 그 자리에서 정함)
            elif self.ret_j is None and abs(cross) > 0.08:
                self.ret_j = min(int(np.searchsorted(self.s2, si + config.RETURN_DIST)), len(self.p2) - 1)
            if self.ret_j is not None:
                rx, ry = self.p2[self.ret_j, 0] - pose[0], self.p2[self.ret_j, 1] - pose[1]
                behind = abs(wrap(math.atan2(ry, rx) - tang)) > math.radians(60)
                if abs(cross) < 0.03 or self.s2[self.ret_j] - si < 0.1 or behind:
                    self.ret_j = None
            j = self.ret_j if self.ret_j is not None else min(int(np.searchsorted(self.s2, si + look)),
                                                               len(self.p2) - 1)
        tx, ty = self.p2[j, 0], self.p2[j, 1]
        phi_w = math.atan2(ty - pose[1], tx - pose[0])
        dist = math.hypot(tx - pose[0], ty - pose[1])
        g = {
            "phi": wrap(phi_w - pose[2]) if dist > 0.05 else wrap(tang - pose[2]),
            "phi_path": wrap(tang - pose[2]),
            "th_err": wrap(th_d - pose[2]),
            "cross": cross,
            "look": dist,
            "event": ev,
        }
        self.last = g
        return g
