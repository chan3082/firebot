"""
달리는 중에 라이다 방향 설정(config.LIDAR_MOUNT_YAW, LIDAR_INVERTED)이 실제와 맞는지 확인

- 좌우: 제자리에서 돌라고 한 방향과 라이다로 잰 회전 방향이 반대면 좌우가 뒤집혀 보이는 것
- 앞뒤: 앞으로 가라고 했는데 라이다 스캔으로는 뒤(또는 옆)로 간 것으로 보이면 앞쪽 각도가 틀린 것

틀리면 방향을 바로잡는 회전이 거꾸로 걸려서 빙빙 돌고, 장애물을 엉뚱한 쪽으로 피한다.
그래서 확실히 틀렸다고 나오면 로봇을 세우고 알려 준다 (tools/test_lidar.py setup 으로 고치면 됨).
"""
import math

import numpy as np

from nav.odom import ScanMatcher

ROT_NEED_DEG = 60.0       # 이만큼 돌아본 뒤 판단
ROT_MIN_STEP = 1.5        # 스캔 사이 회전이 이보다 작으면 셈에 안 넣음 (잡음)
MOVE_GAP = 0.5            # 이만큼(초) 떨어진 두 스캔을 맞춰서 움직인 방향을 잼
MOVE_MIN = 0.04           # 이보다 덜 움직였으면 셈에 안 넣음 (바퀴가 헛돌거나 막힘)
MOVE_NEED = 6             # 이만큼 모은 뒤 판단


class MountCheck:
    def __init__(self):
        self.rot_sum = 0.0            # 회전 명령 방향 x 잰 회전 (같은 방향이면 +)
        self.rot_abs = 0.0
        self.rot_ok = False
        self.moves = []               # 명령한 방향과 잰 방향 사이 각도 (rad)
        self.move_ok = False
        self._ref = None              # (스캔 x, y, 시각, 명령 방향)
        self.problem = None           # 틀렸으면 사람이 읽을 말
        self.kind = None              # "mirror" | "front"

    @property
    def done(self):
        return self.problem is not None or (self.rot_ok and self.move_ok)

    def update(self, cmd, dyaw_deg, x, y, now):
        """새 스캔마다. cmd: 이번 스캔 동안 보낸 명령 (vx, vy, wz). 틀린 것이 확실해지면 문제 설명을 돌려준다"""
        if self.done:
            return None
        vx, vy, wz = cmd
        v = math.hypot(vx, vy)
        if not self.rot_ok and dyaw_deg is not None and abs(wz) >= 0.15 and v <= 0.12 \
                and abs(dyaw_deg) >= ROT_MIN_STEP:
            self.rot_abs += abs(dyaw_deg)
            self.rot_sum += math.copysign(1.0, wz) * dyaw_deg
            if self.rot_abs >= ROT_NEED_DEG:
                r = self.rot_sum / self.rot_abs
                if r < -0.5:
                    self.kind = "mirror"
                    self.problem = ("라이다 좌우가 뒤집혀 보여요 (왼쪽으로 돌라고 했는데 라이다로는 오른쪽으로 돈 것으로 보임). "
                                    "그대로 달리면 빙빙 돌아요. tools/test_lidar.py setup 으로 방향을 맞춰 주세요")
                    return self.problem
                if r > 0.5:
                    self.rot_ok = True
                else:
                    self.rot_sum = self.rot_abs = 0.0      # 애매하면 처음부터 다시
        if not self.move_ok:
            steady = v >= 0.15 and abs(wz) <= 0.1
            if not steady:
                self._ref = None
            elif self._ref is None:
                self._ref = (x, y, now, math.atan2(vy, vx))
            elif now - self._ref[2] >= MOVE_GAP:
                rx, ry, _, dir0 = self._ref
                self._ref = (x, y, now, math.atan2(vy, vx))
                p, info = ScanMatcher(rx, ry).match(x, y, (0.0, 0.0, 0.0), (0.5, 0.5, math.radians(20)))
                if p is not None and not info.get("degenerate") and info["inlier"] > 0.6 \
                        and math.hypot(p[0], p[1]) >= MOVE_MIN:
                    d = math.atan2(p[1], p[0]) - dir0
                    self.moves.append(math.atan2(math.sin(d), math.cos(d)))
                    if len(self.moves) >= MOVE_NEED:
                        a = np.array(self.moves[-MOVE_NEED:])
                        mean = math.degrees(math.atan2(np.sin(a).mean(), np.cos(a).mean()))
                        spread = float(np.hypot(np.sin(a).mean(), np.cos(a).mean()))
                        if spread > 0.7 and abs(mean) <= 40:
                            self.move_ok = True
                        elif spread > 0.7 and abs(mean) >= 60:
                            self.kind = "front"
                            side = "뒤" if abs(mean) > 135 else ("왼쪽" if mean > 0 else "오른쪽")
                            self.problem = (f"라이다 앞쪽 각도가 틀려요 (앞으로 가라고 했는데 라이다로는 {side}으로 간 것으로 보임). "
                                            "tools/test_lidar.py setup 으로 방향을 맞춰 주세요")
                            return self.problem
        return None
