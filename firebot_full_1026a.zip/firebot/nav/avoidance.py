"""
반응형 장애물 회피 (지도 없음, 항상 정면을 본 채로 이동)

라이다 점들을 '차체 폭만큼의 통로'로 잘라 전/후/좌/우 여유거리를 구하고,
아래 규칙으로 (vx, vy, wz)를 정한다. 메카넘이라 몸을 돌리지 않고 옆으로 비킨다.

  FORWARD      전진. 정면이 가까울수록 감속
      │ 정면 막힘
      ▼
  WAIT         잠깐 멈춰서 기다림 (사람이면 대개 비켜줌). 트이면 다시 전진
      │ 계속 막힘
      ▼
  STRAFE_R     정면을 본 채 우측 횡이동 ──── 정면 트임 ──▶ FORWARD
      │ 우측도 막힘
      ▼
  STRAFE_L     정면을 본 채 좌측 횡이동 ──── 정면 트임 ──▶ FORWARD
      │ 좌측도 막힘
      ▼
  BACKUP       후진. 옆이 열리면 그쪽으로 탈출 횡이동
               돌 공간도 없는 좁은 막다른 길이면 옆이 열릴 때까지 계속 후진
  SEEK_REAR    후진하려는데 뒤가 막혔으면, 뒤가 트인 자리까지 옆으로 이동 후 후진
      │ 계속 후진해도 옆이 안 열림 (막다른 길)
      ▼
  CENTER       돌기 전에 좌우 가운데로 이동 (벽에 치우치면 모서리가 닿음)
  TURN_AROUND  180° 돌아서 나감. 회전각은 라이다로 잰다 (nav/yaw.py, 안 되면 시간으로)
  STUCK        사방이 막힘. 정지 후 주기적으로 재시도
  HOLD         외부 요청(화재 확인 등) 또는 라이다 끊김

같은 막다른 곳을 계속 드나드는 걸 막는 장치 (ㄷ자 공간 무한 루프 대책)
  - 막다른 길로 판단한 순간의 정면 거리를 기억한다. 그 뒤에는 정면이 그보다 확실히 멀어져야
    (장애물이 치워졌거나, 돌아서 다른 쪽을 보게 됐거나) 다시 전진한다.
    예전에는 후진해서 생긴 거리만 보고 같은 곳으로 다시 들어갔다
  - 일정 시간(LOOP_WINDOW) 안에 후진이 MAX_ESCAPE_TRIES 번을 넘으면 막다른 곳으로 보고 돌아 나간다

펌웨어 부호: vx 전진(+), vy 좌측(+) / 우측(-), wz 반시계(+)
"""
import math
import time
from collections import deque
from dataclasses import dataclass

import numpy as np

import config
from nav.yaw import Turn


@dataclass
class Clearance:
    front: float
    rear: float
    left: float
    right: float
    radial: float     # 제자리 회전 시 여유 (외접원 기준)


def _kth_min(v, k):
    if v.size == 0:
        return math.inf
    k = min(k, v.size) - 1
    return float(np.partition(v, k)[k])


def compute_clearance(x, y) -> Clearance:
    """로봇 좌표계 점(x 전방+, y 좌측+)으로 각 방향 여유거리 계산"""
    hl, hw, m = config.HALF_LENGTH, config.HALF_WIDTH, config.CORRIDOR_MARGIN
    k = config.KTH

    # 차체 안에 찍힌 점(카메라 지지대, 배선 등 자기 몸체) 제거
    inside = (np.abs(x) <= hl) & (np.abs(y) <= hw)
    x, y = x[~inside], y[~inside]

    front = _kth_min(x[(x > 0) & (np.abs(y) < hw + m)], k) - hl
    rear = _kth_min(-x[(x < 0) & (np.abs(y) < hw + m)], k) - hl
    left = _kth_min(y[(y > 0) & (np.abs(x) < hl + m)], k) - hw
    right = _kth_min(-y[(y < 0) & (np.abs(x) < hl + m)], k) - hw
    radial = _kth_min(np.hypot(x, y), k) - math.hypot(hl, hw)
    return Clearance(front, rear, left, right, radial)


STOP = (0.0, 0.0, 0.0)


class Avoider:
    def __init__(self, yaw=None):
        """yaw: nav/yaw.py 의 YawTracker. 없으면 회전을 시간으로 계산"""
        self.yaw = yaw
        self.hold_reason = None
        # 같은 곳을 맴도는지 보는 기록은 reset() 으로 지우지 않는다 (둘러보기 등으로 reset 돼도 유지)
        self.backups = deque()       # 최근 후진 시작 시각
        self.dead_front = None       # 막다른 길로 판단했을 때 정면 거리
        self.dead_at = -1e9
        self.reset()

    # ---------------- 외부 제어 ----------------
    def reset(self, now=None):
        """처음 상태(전진)로 되돌림. 화재 확인이나 둘러보기가 끝난 뒤 호출"""
        self.state = "FORWARD"
        self.t_enter = time.time() if now is None else now
        self.clear_count = 0
        self.clear_since = None
        self.escape = False          # 후진 후 탈출 중인지
        self.escape_front = 0.0      # 후진을 끝냈을 때 정면 거리 (물러난 벽)
        self.backup_left0 = 0.0      # 후진 시작 때 좌우 여유 (이보다 넓어져야 틈으로 인정)
        self.backup_right0 = 0.0
        self.long_backup = False     # 돌 공간이 없어서 끝까지 후진 중인지
        self.seek_dir = -1           # SEEK_REAR 이동 방향 (+1 좌, -1 우)
        self.seek_tries = 0
        self.turn = None             # 진행 중인 회전 (nav.yaw.Turn)
        self.turn_left = 180.0       # 가운데 맞추느라 끊긴 회전의 남은 각도
        self.turn_ext = 0            # 돌고 나서도 막혀서 더 돈 횟수
        self.center_tries = 0
        self.last_event = ""

    def hold(self, reason="external"):
        self.hold_reason = reason

    def release(self):
        self.hold_reason = None

    # ---------------- 내부 ----------------
    def _go(self, state, now, why=""):
        if state != self.state:
            self.state = state
            self.t_enter = now
            self.clear_count = 0
            self.clear_since = None
            if why:
                self.last_event = why

    def _side_free(self, v):
        """옆으로 가볼 만한지: 막힘 기준보다 조금이라도 넓으면 일단 시도"""
        return v > config.SIDE_BLOCK + 0.05

    def _dead_recent(self, now):
        return now - self.dead_at < config.DEADEND_MEMORY

    def _front_need(self, now):
        """전진을 다시 시작하려면 정면이 이만큼은 트여야 한다"""
        need = config.AVOID_DIST + config.HYSTERESIS
        if self.escape:
            need = max(need, self.escape_front + config.ESCAPE_MARGIN)
        if self._dead_recent(now) and self.dead_front is not None:
            # 막다른 길로 판단했던 그 벽이 아직 앞에 있으면 다시 들어가지 않는다
            need = max(need, self.dead_front + config.ESCAPE_MARGIN)
        return need

    def _start_avoid(self, c, now):
        """정면이 막혔을 때: 우측 → 좌측 → 후진 순서로 고른다"""
        if self._side_free(c.right):
            self._go("STRAFE_R", now, "정면 막힘 → 우측")
        elif self._side_free(c.left):
            self._go("STRAFE_L", now, "정면·우측 막힘 → 좌측")
        else:
            self._start_backup(c, now, "정면·좌우 막힘 → 후진")

    def _start_backup(self, c, now, why):
        self.backups.append(now)
        while self.backups and now - self.backups[0] > config.LOOP_WINDOW:
            self.backups.popleft()
        if len(self.backups) > config.MAX_ESCAPE_TRIES:
            self._deadend(c, now, f"{config.LOOP_WINDOW:.0f}초 안에 {len(self.backups)}번째 후진 → 같은 곳을 맴돎")
        elif c.rear < config.REAR_STOP + config.HYSTERESIS:
            self._start_seek(c, now)
        else:
            self._begin_backup(c, now, why)

    def _begin_backup(self, c, now, why, long=False):
        self.escape = False
        self.long_backup = long
        self.backup_left0, self.backup_right0 = c.left, c.right
        self._go("BACKUP", now, why)

    def _start_seek(self, c, now):
        """뒤가 막힘: 넓은 쪽(같으면 우측)으로 옆걸음하며 뒤가 트인 자리를 찾는다"""
        self.seek_tries += 1
        if self.seek_tries > 2:
            self._deadend(c, now)
            return
        self.seek_dir = +1 if c.left > c.right + 0.05 else -1
        self._go("SEEK_REAR", now, "후방 막힘 → 뒤가 트인 자리 찾기")

    @staticmethod
    def _radial_if_centered(c):
        """좌우 가운데로 옮겼을 때 제자리 회전 여유 추정"""
        circ = math.hypot(config.HALF_LENGTH, config.HALF_WIDTH)
        half_w = (c.left + c.right) / 2 + config.HALF_WIDTH
        nearest = min(half_w, c.front + config.HALF_LENGTH, c.rear + config.HALF_LENGTH)
        return nearest - circ

    def _can_turn(self, c):
        return c.radial > config.TURN_MARGIN or self._radial_if_centered(c) > config.TURN_MARGIN

    def _start_turn(self, now, deg, why):
        self.turn = Turn(deg, self.yaw, config.TURN_RATE_DEG_S, now)
        self.turn_left = deg
        self._go("TURN_AROUND", now, why)

    def _stuck(self, c, now, why):
        self.dead_front, self.dead_at = c.front, now
        self._go("STUCK", now, why)

    def _deadend(self, c, now, why="막다른 길"):
        self.escape = False
        self.dead_front, self.dead_at = c.front, now
        self.turn_ext = 0
        self.center_tries = 0
        if not config.DEADEND_TURN:
            self._stuck(c, now, f"{why} → 정지 대기")
        elif c.radial > config.TURN_MARGIN:
            self._start_turn(now, 180.0, f"{why} → 180° 회전")
        elif self._radial_if_centered(c) > config.TURN_MARGIN:
            self.turn_left = 180.0
            self._go("CENTER", now, f"{why} → 가운데로 이동 후 회전")
        elif c.rear > config.REAR_STOP + config.HYSTERESIS and not self.long_backup:
            self._begin_backup(c, now, f"{why}, 돌 공간 없음 → 빠져나올 때까지 후진", long=True)
        else:
            self._stuck(c, now, f"{why}, 돌 공간 없음 → 정지 대기")

    def _front_ok(self, c, now):
        """정면이 트였는지 (연속 N회 확인)"""
        if c.front > self._front_need(now):
            self.clear_count += 1
        else:
            self.clear_count = 0
        return self.clear_count >= config.CLEAR_CYCLES

    def _to_forward(self, now, why):
        self.escape = False
        self._go("FORWARD", now, why)

    # ---------------- 메인 ----------------
    def drive(self, pts, c, now=None):
        """nav/navigator.py 와 같은 모양으로 부르기 위한 것 (예전 방식은 점 대신 Clearance 만 씀)"""
        return self.step(c, now)

    def step(self, c, now=None):
        """Clearance를 받아 (vx, vy, wz) 반환. c=None이면 정지"""
        now = time.time() if now is None else now
        dt = now - self.t_enter

        if self.hold_reason or c is None:
            if self.state != "HOLD":
                self._go("HOLD", now, f"정지 ({self.hold_reason or 'lidar 없음'})")
            return STOP
        if self.state == "HOLD":
            self._to_forward(now, "재개")

        # ---------------- FORWARD ----------------
        if self.state == "FORWARD":
            if dt > 2.0:
                self.seek_tries = 0
            if dt > 4.0:
                self.dead_front = None            # 한참 달려서 다른 곳에 왔으면 막다른 길 기억은 지운다
            if c.front < config.AVOID_DIST:
                if config.OBSTACLE_WAIT > 0:
                    self._go("WAIT", now, "정면 막힘 → 잠깐 대기")
                else:
                    self._start_avoid(c, now)
                return STOP
            k = (c.front - config.AVOID_DIST) / (config.SLOW_DIST - config.AVOID_DIST)
            k = max(0.0, min(1.0, k))
            v = config.CRUISE_MIN + (config.CRUISE_SPEED - config.CRUISE_MIN) * k
            return v, 0.0, 0.0

        # ---------------- WAIT ----------------
        if self.state == "WAIT":
            if self._front_ok(c, now):
                self._to_forward(now, "장애물이 비킴 → 전진")
            elif dt >= config.OBSTACLE_WAIT:
                self._start_avoid(c, now)
            return STOP

        # ---------------- STRAFE_R / STRAFE_L ----------------
        if self.state in ("STRAFE_R", "STRAFE_L"):
            right = self.state == "STRAFE_R"
            side_clear = c.right if right else c.left
            vy = -config.STRAFE_SPEED if right else config.STRAFE_SPEED

            # 1) 정면이 트였으면 조금 더 비킨 뒤 전진
            if self._front_ok(c, now):
                if self.clear_since is None:
                    self.clear_since = now
                if (now - self.clear_since >= config.STRAFE_EXTRA
                        or side_clear < config.SIDE_BLOCK):
                    self._to_forward(now, "정면 트임 → 전진")
                    return STOP
                return 0.0, vy, 0.0
            self.clear_since = None

            # 2) 가던 쪽이 막혔으면 다음 단계로
            if side_clear < config.SIDE_BLOCK or dt > config.STRAFE_TIMEOUT:
                if right and self._side_free(c.left):
                    self._go("STRAFE_L", now, "우측도 막힘 → 좌측")
                else:
                    self._start_backup(c, now, "좌측도 막힘 → 후진")
                return STOP

            return 0.0, vy, 0.0

        # ---------------- SEEK_REAR ----------------
        if self.state == "SEEK_REAR":
            if c.rear > config.REAR_STOP + config.HYSTERESIS:
                self.clear_count += 1
                if self.clear_count >= config.CLEAR_CYCLES:
                    self._begin_backup(c, now, "뒤가 트인 자리 → 후진")
                    return STOP
            else:
                self.clear_count = 0
            side_clear = c.left if self.seek_dir > 0 else c.right
            if side_clear < config.SIDE_BLOCK or dt > config.STRAFE_TIMEOUT:
                other = c.right if self.seek_dir > 0 else c.left
                if self._side_free(other) and self.seek_tries <= 2:
                    self.seek_tries += 1
                    self.seek_dir = -self.seek_dir
                    self.t_enter = now
                else:
                    self._deadend(c, now)
                return STOP
            return 0.0, self.seek_dir * config.STRAFE_SPEED, 0.0

        # ---------------- BACKUP ----------------
        if self.state == "BACKUP":
            if c.rear < config.REAR_STOP:
                if dt < 0.3 and not self.long_backup:
                    self._start_seek(c, now)      # 시작하자마자 막힘 → 옆으로 자리 찾기
                else:
                    self._deadend(c, now, "더 물러날 곳 없음")
                return STOP
            if dt >= config.BACKUP_MIN:
                # 옆을 막던 벽을 지나쳐서 옆이 확실히 넓어지면 그쪽으로 빠져나간다 (우측 우선)
                # 후진 시작 때보다 넓어져야 한다. 방금 떠나온 쪽을 틈으로 착각하지 않기 위함
                if c.right > max(config.SIDE_OPEN, self.backup_right0 + config.ESCAPE_MARGIN):
                    self.escape, self.escape_front = True, c.front
                    self.long_backup = False
                    self._go("STRAFE_R", now, "후진 후 우측으로 탈출")
                    return STOP
                if c.left > max(config.SIDE_OPEN, self.backup_left0 + config.ESCAPE_MARGIN):
                    self.escape, self.escape_front = True, c.front
                    self.long_backup = False
                    self._go("STRAFE_L", now, "후진 후 좌측으로 탈출")
                    return STOP
            if self.long_backup:
                if dt > config.BACKUP_LONG_MAX:
                    self.long_backup = False
                    self._stuck(c, now, "한참 후진해도 옆이 안 열림 → 정지 대기")
                    return STOP
            elif dt > config.BACKUP_MAX:
                if self._can_turn(c):
                    self._deadend(c, now)
                else:
                    # 좁아서 돌 수도 없는 막다른 길: 옆이 열릴 때까지 계속 물러난다
                    self.long_backup = True
                    self.last_event = "좁은 막다른 길 → 빠져나올 때까지 후진"
            return -config.BACKUP_SPEED, 0.0, 0.0

        # ---------------- CENTER ----------------
        if self.state == "CENTER":
            diff = c.left - c.right
            if c.radial > config.TURN_MARGIN or abs(diff) < 0.04:
                if c.radial > config.TURN_MARGIN:
                    self._start_turn(now, self.turn_left, "가운데 도착 → 회전")
                else:
                    self._stuck(c, now, "가운데서도 돌 공간 없음 → 정지 대기")
                return STOP
            if dt > config.STRAFE_TIMEOUT:
                self._stuck(c, now, "가운데 이동 실패 → 정지 대기")
                return STOP
            # 넓은 쪽으로 천천히
            return 0.0, (0.5 if diff > 0 else -0.5) * config.STRAFE_SPEED, 0.0

        # ---------------- TURN_AROUND ----------------
        if self.state == "TURN_AROUND":
            if c.radial < config.TURN_MARGIN:
                left = max(10.0, self.turn.target - self.turn.turned(now))
                if self._radial_if_centered(c) > config.TURN_MARGIN and self.center_tries < 2:
                    self.center_tries += 1
                    self.turn_left = left
                    self._go("CENTER", now, "돌다가 벽에 가까워짐 → 가운데로 이동")
                else:
                    self._stuck(c, now, "회전 공간 없음 → 정지 대기")
                return STOP
            if self.turn.done(now):
                # 돌고 난 뒤에도 정면이 바로 막혀 있으면 (덜 돌았거나 그쪽도 막힘) 조금 더 돈다
                if c.front < config.AVOID_DIST + config.HYSTERESIS + 0.2 and self.turn_ext < 2:
                    self.turn_ext += 1
                    self._start_turn(now, 90.0, "돌았는데도 앞이 막힘 → 90° 더 회전")
                    self.state = "TURN_AROUND"
                    return STOP
                self.backups.clear()              # 새 방향이니 맴돌기 기록 초기화
                self.seek_tries = 0
                self.dead_front, self.dead_at = None, -1e9
                how = "라이다로 잼" if self.turn.used_lidar else "시간으로 계산"
                self._to_forward(now, f"회전 완료 ({how}) → 전진")
                return STOP
            return 0.0, 0.0, config.TURN_SPEED

        # ---------------- STUCK ----------------
        if self.state == "STUCK":
            if dt > config.STUCK_RETRY:
                self.t_enter = now
                self.seek_tries = 0
                self.long_backup = False
                if c.front > self._front_need(now):
                    self._to_forward(now, "앞이 트임 → 전진")
                elif config.DEADEND_TURN and self._can_turn(c):
                    self._deadend(c, now, "재시도")
                elif c.rear > config.REAR_STOP + config.HYSTERESIS:
                    self._begin_backup(c, now, "재시도 → 빠져나올 때까지 후진", long=True)
                elif self._side_free(c.right) or self._side_free(c.left):
                    self._start_avoid(c, now)
            return STOP

        return STOP
