"""
메카넘 순찰 주행 (지도 없음, 라이다 360°와 라이다 회전각만 사용)

평소에는 몸(카메라)이 가는 쪽을 보고 전진한다. 메카넘이라서 할 수 있는 동작 세 가지를 섞는다.

  A  작은 장애물(사람, 의자): 몸 방향은 그대로 두고 비켜 지나간 뒤 원래 길로 돌아온다
       비키는 각도   θ = atan( 비킬 거리 / (장애물까지 거리 − 안전거리) )   코앞이면 90°(옆걸음)
       돌아오는 각도 θ = atan( 벗어난 거리 / RETURN_DIST )
       복도에서는 '원래 길' = 복도 가운데 (양쪽 벽 거리로 잼). 넓은 곳에서는 비킨 거리를 기억해서 돌아옴
  B  둘러보기: 가던 방향으로 계속 가면서 몸만 360° 돌린다 (mission/patrol.py 가 시작시킴)
  C  모퉁이, 꺾인 복도: 트인 쪽으로 미끄러지면서 동시에 몸을 돌린다. 덜 꺾이는 쪽, 같으면 오른쪽 우선
  막다른 길(뒤만 트임)은 제자리에서 돌아 나간다. 돌 공간이 없으면 돌 수 있는 곳까지 후진

  FORWARD    전진 (RETURN: 전진하면서 원래 길로 돌아가는 중)
  WAIT       정면이 막힘. 잠깐 기다림 (사람이면 대개 비켜줌). 벽이면 기다리지 않음
  DODGE      A. 비켜 지나가는 중
  CORNER     C. 미끄러지며 도는 중
  SWEEP      B. 가면서 둘러보는 중
  TURN_BACK  막다른 길에서 돌아 나가는 중
  ESCAPE     돌 공간이 없음. 옆이나 대각선으로 미끄러져서 돌 수 있는 자리로 (메카넘)
  BACKOUT    가까운 곳에 돌 자리가 없음 (좁고 긴 막다른 길). 돌 수 있는 곳까지 후진
  STUCK      사방이 막힘. 정지 후 주기적으로 재시도
  HOLD       외부 요청(화재 확인 등) 또는 라이다 끊김
  ROUTE      기억한 길 따라가기 (nav/route.py). 막히면 A(비켜 지나가기)만 하고, 안 되면 길이 트일 때까지 기다린다

회전 각도는 nav/yaw.py 가 라이다 스캔끼리 비교해서 잰다. 직진할 때는 옆 벽과 나란하게 맞춰서
회전 오차가 쌓이지 않게 한다.

펌웨어 부호: vx 전진(+), vy 좌측(+) / 우측(-), wz 반시계(+). 속도는 1.0 = 펌웨어 최대 속도
"""
import math
import time

import numpy as np

import config
from nav.yaw import Turn

STOP = (0.0, 0.0, 0.0)
# 몸을 돌리지 않고 움직이는 상태. 이때는 벽 방향을 기준으로 몸 방향을 붙잡는다 (HEADING_HOLD)
_HOLD_STATES = ("FORWARD", "RETURN", "DODGE", "ESCAPE", "BACKOUT", "WAIT")
_CAND_DEG = np.arange(-180, 180, 5)
_CANDS = np.radians(_CAND_DEG)
_COS, _SIN = np.cos(_CANDS), np.sin(_CANDS)
_EPS = 1e-6


def _free_dist(along, lat, c, s, margin):
    """
    몸을 돌리지 않고 (c, s) = (cos φ, sin φ) 방향으로 갈 때 각 점까지 남은 거리.
    along: 진행 방향 좌표, lat: 진행 방향에 수직인 좌표 (왼쪽 +). 부딪히지 않는 점은 inf.
    차체 직사각형을 φ 방향으로 밀었을 때 그 점이 차체 앞 끝에 닿기까지 거리를 정확히 잰다
    (대각선으로 갈 때 차체 모서리가 스치는 것까지 포함)
    """
    hl, hw = config.HALF_LENGTH, config.HALF_WIDTH
    ac, as_ = np.abs(c), np.abs(s)
    reach = hl * as_ + hw * ac                      # 진행 방향에서 본 차체 반폭
    l = np.clip(lat, -reach, reach)
    with np.errstate(divide="ignore", invalid="ignore"):
        up1 = np.where(ac > _EPS, l * s / np.where(ac > _EPS, c, 1.0) + hl / np.maximum(ac, _EPS), np.inf)
        up2 = np.where(as_ > _EPS, -l * c / np.where(as_ > _EPS, s, 1.0) + hw / np.maximum(as_, _EPS), np.inf)
    front_edge = np.minimum(up1, up2)               # 그 옆 위치에서 차체 앞 끝
    hit = (np.abs(lat) < reach + margin) & (along > front_edge)
    return np.where(hit, along - front_edge, np.inf)


def _kth(a, k):
    a = a[np.isfinite(a)]
    if a.size == 0:
        return math.inf
    k = min(k, a.size) - 1
    return float(np.partition(a, k)[k])


def strip_free(pts, phi, off=0.0, margin=None):
    """
    몸 기준 phi 방향(반시계 +)으로 몸을 돌리지 않고 갈 때 부딪히기 전까지 거리 (m).
    off: 그 방향에 수직으로 비켜선 자리에서 잼 (왼쪽 +)
    """
    x, y = pts
    margin = config.CORRIDOR_MARGIN if margin is None else margin
    c, s = math.cos(phi), math.sin(phi)
    along = x * c + y * s
    lat = -x * s + y * c - off
    return _kth(_free_dist(along, lat, c, s, margin), config.KTH)


def strip_mask(pts, phi, limit, margin=None):
    """phi 방향으로 갈 때 limit(m) 안에서 부딪히는 점들 (앱 화면에 빨갛게 표시용)"""
    x, y = pts
    margin = config.CORRIDOR_MARGIN if margin is None else margin
    c, s = math.cos(phi), math.sin(phi)
    return _free_dist(x * c + y * s, -x * s + y * c, c, s, margin) < limit


def all_free(pts, margin=None):
    """5° 간격 72방향의 strip_free (한 번에 계산)"""
    x, y = pts
    margin = config.CORRIDOR_MARGIN if margin is None else margin
    if x.size == 0:
        return np.full(len(_CANDS), np.inf)
    along = np.outer(_COS, x) + np.outer(_SIN, y)
    lat = -np.outer(_SIN, x) + np.outer(_COS, y)
    d = _free_dist(along, lat, _COS[:, None], _SIN[:, None], margin)
    k = max(1, min(config.KTH, d.shape[1])) - 1
    return np.partition(d, k, axis=1)[:, k]


def _fit_line(u, v, bin_w=0.1, min_span=0.8, min_frac=0.7, max_gap=None):
    """
    점들을 u 방향으로 bin_w 칸마다 가장 가까운 점 하나씩만 남기고 직선 v = a·u + b 로 맞춤.
    곧은 면이면 (a, b, 길이) 아니면 None. 가까운 점만 쓰므로 문 틈 너머 먼 점에 덜 흔들린다.
    먼 벽일수록 라이다 잡음이 커지므로 허용 오차를 거리에 맞춰 늘린다
    """
    if u.size < 10:
        return None
    key = np.floor(u / bin_w).astype(int)
    order = np.lexsort((np.abs(v), key))
    key_s = key[order]
    first = np.ones(order.size, bool)
    first[1:] = key_s[1:] != key_s[:-1]
    uu, vv = u[order][first], v[order][first]
    if uu.size < 6 or np.ptp(uu) < min_span:
        return None
    tol = max(1.0, 0.4 + 0.6 * float(np.median(np.abs(vv))))
    # 제일 안 맞는 점을 하나씩 빼면서 다시 맞춤 (모서리에 걸친 옆벽 점 같은 것 제거)
    n0 = uu.size
    while True:
        a, b = np.polyfit(uu, vv, 1)
        res = np.abs(vv - (a * uu + b))
        worst = int(np.argmax(res))
        if res[worst] < 0.05 * tol:
            break
        if uu.size - 1 < max(6, min_frac * n0):
            return None
        uu, vv = np.delete(uu, worst), np.delete(vv, worst)
    if np.ptp(uu) < min_span or float(np.std(res)) > 0.03 * tol:
        return None
    if max_gap is not None and np.diff(np.sort(uu)).max() > max_gap:
        return None                                    # 이어진 면이 아님 (사람 + 옆벽 끝처럼 따로 떨어진 것들)
    return float(a), float(b), float(np.ptp(uu))


def side_walls(pts, reach=4.0):
    """
    양옆의 곧은 벽 (옆으로 reach m 안). (왼쪽, 오른쪽) 각각 None 또는 (여유거리 m, 틀어진 각도 rad).
    틀어진 각도: 몸이 벽보다 반시계로 돌아가 있으면 +
    """
    x, y = pts
    out = []
    for sgn in (1, -1):
        m = (np.abs(x) < 1.2) & (sgn * y > config.HALF_WIDTH + 0.02) & (sgn * y < reach)
        f = _fit_line(x[m], y[m])
        if f is None or abs(math.atan(f[0])) > math.radians(25):
            out.append(None)
            continue
        a, b, _ = f
        dist = abs(b) / math.sqrt(1 + a * a)
        out.append((dist - config.HALF_WIDTH, -math.atan(a)))
    return out[0], out[1]


def wall_misalign(pts):
    """옆 벽과 몸이 틀어진 각도 (rad). 곧은 벽이 안 보이면 None"""
    left, right = side_walls(pts)
    vals = [w[1] for w in (left, right) if w is not None]
    return None if not vals else float(np.mean(vals))


def wall_ahead(pts, front):
    """정면을 막은 것이 넓은 벽인지 (사람, 의자처럼 작은 것이 아닌지)"""
    x, y = pts
    hl = config.HALF_LENGTH
    m = (x > hl) & (x < hl + front + 0.4) & (np.abs(y) < 1.0)
    f = _fit_line(y[m], x[m], min_span=0.65, min_frac=0.6, max_gap=0.21)   # 사람 어깨 폭(0.5m)보다 넓고 곧게 이어지면 벽
    return f is not None and abs(math.atan(f[0])) < math.radians(40)


def escape_target(pts, max_r=0.6, step=0.1):
    """
    제자리에서 돌 수 있는 가장 가까운 자리 (몸 기준 dx, dy, 그 자리의 회전 여유).
    몸을 돌리지 않고 곧장 갈 수 있는 곳만 본다. 없으면 None
    """
    x, y = pts
    if x.size == 0:
        return None
    circ = math.hypot(config.HALF_LENGTH, config.HALF_WIDTH)
    need = config.TURN_MARGIN + 0.03
    free = all_free(pts)
    k = max(1, min(config.KTH, x.size)) - 1
    for r in np.arange(step, max_r + 1e-6, step):
        ok = free >= r + 0.02
        if not ok.any():
            continue
        dx, dy = r * _COS[ok], r * _SIN[ok]
        d = np.hypot(x[None, :] - dx[:, None], y[None, :] - dy[:, None])
        rad = np.partition(d, k, axis=1)[:, k] - circ
        j = int(np.argmax(rad))
        if rad[j] >= need:
            return float(dx[j]), float(dy[j]), float(rad[j])
    return None


def _rear(pts):
    """뒤로 곧장 갈 수 있는 거리. 옆에 바짝 붙은 벽 점은 세지 않는다 (좁은 곳에서 뒤가 막혔다고 잘못 보지 않게)"""
    return strip_free(pts, math.pi)


def end_offset(pts, side, max_off=3.0):
    """
    정면을 막은 것의 side 쪽 끝까지 옆 거리 (m). 그만큼 옆으로 가면 앞이 1m 이상 트임. 끝이 안 보이면 inf.
    넓은 벽 앞에서 어느 쪽으로 돌아가는 게 가까운지 고를 때 쓴다
    """
    room = strip_free(pts, side * math.pi / 2)            # 옆으로 실제로 갈 수 있는 만큼만 (벽 너머는 안 보여서 트여 보임)
    for off in np.arange(0.3, min(max_off, room - 0.05) + 1e-6, 0.1):
        if strip_free(pts, 0.0, off=side * off) >= 1.0:
            return float(off)
    return math.inf


def wrap_angle(t):
    return (t + math.pi) % (2 * math.pi) - math.pi


def _clamp(v, lim):
    return max(-lim, min(lim, v))


class ManualHold:
    """
    직접 운전(경로 기억) 중에 회전 버튼을 안 누르고 움직이는 동안, 그때 방향을 붙잡는다.
    한쪽 바퀴가 느려서 휘는 것을 오도메트리 방향(라이다)으로 바로잡고, 휘는 버릇은 움직이는 방향별로 배운다.
    회전 버튼을 누르면 그 뒤 방향을 새 기준으로 삼는다
    """

    def __init__(self):
        self.ref = None
        self.bias = [0.0] * 8
        self.err = None
        self.off = False             # 방향을 잘못 재는 것 같아서 이번 직진 동안은 붙잡기를 쉼
        self._t = None

    def apply(self, vx, vy, wz, heading, now, moving=True):
        dt = 0.0 if self._t is None else min(0.2, max(0.0, now - self._t))
        self._t = now
        v = math.hypot(vx, vy)
        if wz != 0.0 or heading is None:
            self.ref = None                              # 사람이 돌리는 중: 다 돈 뒤 방향이 새 기준
            self.err = None
            self.off = False
            return vx, vy, wz
        if not config.HEADING_HOLD or v < 0.05 or self.off:
            self.err = None
            return vx, vy, wz                            # 멈춰 있을 때는 돌리지 않음 (기준은 유지)
        if self.ref is None:
            self.ref = heading
        e = math.degrees(wrap_angle(self.ref - heading))  # 돌아야 할 각도 (반시계 +)
        if abs(e) > 30:
            # 정상이면 이만큼 틀어질 수 없음 (방향을 잘못 재는 중). 회전 버튼을 다시 누를 때까지 붙잡기를 쉼
            self.off = True
            self.err = None
            return vx, vy, wz
        b = int(round(math.atan2(vy, vx) / (math.pi / 4))) % 8
        if abs(e) < 15 and config.HOLD_LEARN > 0 and moving:
            self.bias[b] = _clamp(self.bias[b] + config.HOLD_LEARN * e * dt / max(v, 0.1), 0.6)
        self.err = -e
        return vx, vy, self.bias[b] * v + _clamp(config.HOLD_GAIN * e, config.HOLD_MAX)


class Navigator:
    def __init__(self, yaw=None):
        """yaw: nav/yaw.py 의 YawTracker. 없으면 회전을 시간으로 계산"""
        self.yaw = yaw
        self.hold_reason = None
        self.h_bias = [0.0] * 8      # 움직이는 방향(45° 단위)별로 배운 휘는 버릇 (속도 1 당 보정 회전)
        self.lat_bias = 0.0          # 전진할 때 옆으로 밀리는 버릇 (속도 1 당 보정 옆 속도)
        self.runner = None           # 기억한 길 따라가기 (nav/route.RouteRunner). None 이면 자유 순찰
        self.g = None                # 이번 주기 길 안내 (RouteRunner.guide)
        self.moving = True           # 실제로 움직이는 중인지 (main 이 오도메트리로 알려줌). 아니면 버릇을 배우지 않음
        self.reset()

    # ---------------- 외부 제어 ----------------
    def reset(self, now=None):
        now = time.time() if now is None else now
        self.state = "ROUTE" if self.runner is not None else "FORWARD"
        self.t_enter = now
        self.t_last = now
        self.lane = 0.0              # 원래 길에서 옆으로 벗어난 거리 (m, 왼쪽 +)
        self.ret_ang = 0.0           # 원래 길로 돌아오는 각도 (0 이면 돌아오는 중 아님)
        self.h_ref = None            # 붙잡을 벽 방향 (rad, yaw.wall_orient 기준)
        self.wall_ref = None         # 한쪽 벽 기준: (방향 +1 왼쪽/-1 오른쪽, 원래 길에서 그 벽까지 여유거리)
        self.h_err = None            # 지금 틀어진 각도 (도, 웹/로그 표시용)
        self.ret_sgn = 1
        self.clear_count = 0
        self.dodge_side = 0
        self.dodge_need = 0.0
        self.dodge_moved = 0.0
        self.turn = None
        self.turn_sign = 1
        self.turn_dir = 0.0          # C: 목표 방향 (몸 기준, 돌기 시작할 때)
        self.turn_left = 180.0
        self.sweep_moving = False
        self.esc_goal = (0.0, 0.0)
        self.esc_moved = (0.0, 0.0)
        self.escapes = []            # 최근 ESCAPE 시작 시각 (같은 곳에서 계속 반복하지 않게)
        self.stucks = []             # 최근 STUCK 시각
        self.last_event = ""

    def hold(self, reason="external"):
        self.hold_reason = reason

    def release(self):
        self.hold_reason = None

    @property
    def sweeping(self):
        return self.state == "SWEEP"

    def start_sweep(self, now=None):
        """B: 가던 방향으로 계속 가면서 몸만 360° 돌기"""
        now = time.time() if now is None else now
        self.turn = Turn(360.0, self.yaw, config.TURN_RATE_DEG_S * config.SWEEP_SPEED / config.TURN_SPEED, now)
        self.turn_sign = 1
        self.sweep_moving = self.yaw is not None and self.yaw.healthy(now)
        self._go("SWEEP", now, "가면서 둘러보기" if self.sweep_moving else "제자리에서 둘러보기", force=True)

    def cancel_sweep(self, now=None):
        if self.state == "SWEEP":
            self._to_forward(time.time() if now is None else now, "둘러보기 중단")

    def set_route(self, runner, now=None):
        """기억한 길 따라가기 시작 (runner=None 이면 자유 순찰로)"""
        self.runner = runner
        self.g = None
        self.reset(now)

    def _travel(self):
        """지금 가려는 방향 (몸 기준 rad). 자유 순찰이면 정면"""
        return self.g["phi"] if (self.runner is not None and self.g is not None) else 0.0

    # ---------------- 내부 ----------------
    def _go(self, state, now, why="", force=False):
        if state != self.state or force:
            self.state = state
            self.t_enter = now
            self.clear_count = 0
            if why:
                self.last_event = why

    @staticmethod
    def _lin(v, dt):
        """정규화 속도 → 이동 거리 (m)"""
        return v * config.STM32_MAX_LINEAR * dt

    def _plan_dodge(self, pts, front):
        """A: 옆으로 얼마나 비키면 앞이 트이나. 오른쪽 먼저. (방향 ±1, 거리) 또는 None"""
        need_clear = max(config.PASS_CLEAR, front + 0.6)
        for side in (-1, 1):
            room = strip_free(pts, side * math.pi / 2)
            off = 0.10
            while off <= config.MAX_DODGE + 1e-6 and off + 0.05 <= room:
                # 비키는 동안 쓰는 것과 같은 여유(+5cm)로 본다. 의자 다리 사이처럼 몸만 겨우 들어가는 틈으로는
                # 계획하지 않고 의자 전체를 돌아가게 (틈에 들어갔다가 막혀서 되돌아 나오는 일이 없게)
                if strip_free(pts, 0.0, off=side * off, margin=config.CORRIDOR_MARGIN + 0.05) >= need_clear:
                    return side, off + 0.05
                off += 0.05
        return None

    def _start_dodge(self, plan, now, why):
        self.dodge_side, self.dodge_need = plan
        self.dodge_moved = 0.0
        side = "우측" if self.dodge_side < 0 else "좌측"
        self._go("DODGE", now, f"{why} → {side}으로 비켜 지나가기 ({plan[1]:.2f}m)", force=True)

    def _corner_plan(self, pts):
        """C: 돌아갈 방향 (도, 몸 기준). 덜 꺾이는 쪽, 같으면 오른쪽. 없으면 None"""
        free = all_free(pts)
        absd = np.abs(_CAND_DEG)
        ok = (free > config.OPEN_DIST) & (absd >= 20) & (absd <= 135)
        if not ok.any():
            return None
        cost = absd + np.where(_CAND_DEG > 0, 3.0, 0.0)
        i = int(np.argmin(np.where(ok, cost, np.inf)))
        d0 = float(_CAND_DEG[i])
        sgn = 1 if d0 > 0 else -1
        other = ok & (np.sign(_CAND_DEG) == -sgn)
        if other.any():
            # 양쪽 다 트였으면, 앞을 막은 것의 끝이 확실히 가까운 쪽으로 (넓은 벽을 짧게 돌아감)
            e_this, e_other = end_offset(pts, sgn), end_offset(pts, -sgn)
            if e_other + 0.5 < e_this:
                i = int(np.argmin(np.where(other, cost, np.inf)))
                d0 = float(_CAND_DEG[i])
                sgn = -sgn
        # 처음 트인 방향에서 45° 안쪽 중 가장 멀리 트인 방향 → 꺾인 복도의 방향과 맞춘다
        win = ok & (sgn * _CAND_DEG >= abs(d0)) & (sgn * _CAND_DEG <= abs(d0) + 45)
        score = np.minimum(free, 4.0) - 0.002 * absd
        j = int(np.argmax(np.where(win, score, -np.inf)))
        return float(_CAND_DEG[j])

    def _start_corner(self, deg, now, why):
        self.turn_dir = math.radians(deg)
        self.turn_sign = 1 if deg > 0 else -1
        self.turn = Turn(abs(deg), self.yaw, config.TURN_RATE_DEG_S, now)
        side = "오른쪽" if deg < 0 else "왼쪽"
        self._go("CORNER", now, f"{why} → 트인 {side}({abs(deg):.0f}°)으로 미끄러지며 돌기", force=True)

    def _decide(self, pts, c, now, why, allow_dodge=True):
        """정면이 막혔을 때: A(비켜 지나가기) → C(트인 쪽으로 돌기) → 막다른 길(돌아 나가기)"""
        if allow_dodge:
            plan = self._plan_dodge(pts, strip_free(pts, 0.0))
            if plan:
                self._start_dodge(plan, now, why)
                return
        if self.runner is not None:
            # 기억한 길을 따라가는 중: 다른 곳으로 가 버리지 않고, 비킬 수 없으면 길이 트일 때까지 기다린다
            self._stuck_now(now, f"{why}, 비켜 갈 자리도 없음 → 길이 트일 때까지 대기")
            return
        deg = self._corner_plan(pts)
        if deg is not None:
            self._start_corner(deg, now, why)
            return
        free = all_free(pts)
        if (free > config.OPEN_DIST).any() or _rear(pts) > config.REAR_STOP + config.HYSTERESIS:
            self._start_turn_back(pts, c, now, f"{why}, 뒤만 트임")
            return
        self._stuck_now(now, f"{why}, 사방이 막힘 → 정지 대기")

    def _start_turn_back(self, pts, c, now, why, deg=180.0):
        """deg 만큼 제자리 회전. 돌 공간이 없으면 돌 수 있는 자리로 먼저 미끄러지거나 후진"""
        self.turn_left = deg
        if c.radial > config.TURN_MARGIN:
            self.turn = Turn(deg, self.yaw, config.TURN_RATE_DEG_S, now)
            self._go("TURN_BACK", now, f"{why} → {deg:.0f}° 돌아 나가기", force=True)
            return
        self.escapes = [t for t in self.escapes if now - t < 30.0]
        many_stuck = len([t for t in self.stucks if now - t < 60.0]) >= 2
        tgt = None
        if len(self.escapes) < 3 or many_stuck:
            tgt = escape_target(pts, max_r=1.0 if many_stuck else 0.6)
        if tgt is not None:
            self.escapes.append(now)
            self.esc_goal, self.esc_moved = (tgt[0], tgt[1]), (0.0, 0.0)
            ang = math.degrees(math.atan2(tgt[1], tgt[0]))
            self._go("ESCAPE", now, f"{why}, 돌 공간 없음 → {math.hypot(tgt[0], tgt[1]):.1f}m 옆 "
                                    f"({ang:+.0f}°)으로 미끄러져서 돌기", force=True)
        elif _rear(pts) > config.REAR_STOP + config.HYSTERESIS:
            self._go("BACKOUT", now, f"{why}, 돌 공간 없음 → 돌 수 있는 곳까지 후진", force=True)
        else:
            self._stuck_now(now, f"{why}, 돌 공간도 물러날 곳도 없음 → 정지 대기")

    def _stuck_now(self, now, why):
        self.stucks = [t for t in self.stucks if now - t < 60.0] + [now]
        self._go("STUCK", now, why, force=True)

    def _to_forward(self, now, why, new_heading=False):
        self.ret_ang = 0.0           # 돌아오는 각도는 지금 벗어난 거리로 새로 정함
        if new_heading:
            self.lane = 0.0          # 새 방향이면 '원래 길'도 새로 시작
            self.wall_ref = None
        self._go("ROUTE" if self.runner is not None else "FORWARD", now, why, force=True)

    # ---------------- 메인 ----------------
    def drive(self, pts, c, now=None):
        """
        pts: 로봇 좌표계 라이다 점 (x 배열, y 배열), c: nav.avoidance.Clearance (둘 다 None 이면 정지)
        반환: (vx, vy, wz)
        """
        now = time.time() if now is None else now
        dt = min(0.2, max(0.0, now - self.t_last))
        self.t_last = now
        if self.hold_reason or pts is None or c is None:
            if self.state != "HOLD":
                self._go("HOLD", now, f"정지 ({self.hold_reason or 'lidar 없음'})")
            return STOP
        x, y = np.asarray(pts[0], float), np.asarray(pts[1], float)
        keep = ~((np.abs(x) <= config.HALF_LENGTH) & (np.abs(y) <= config.HALF_WIDTH))
        pts = (x[keep], y[keep])
        if self.state == "HOLD":
            self._to_forward(now, "재개")
        if self.runner is not None:
            self.runner.allow_return = self.state == "ROUTE"
            self.g = self.runner.guide()
            if self.g is not None and self.g["event"]:
                self.last_event = self.g["event"]
        # 상태가 바뀌면 같은 주기 안에서 새 상태를 한 번 더 처리 (멈칫하지 않게)
        for _ in range(3):
            st = self.state
            cmd = getattr(self, "_" + ("forward" if st == "RETURN" else st.lower()))(pts, c, now, dt)
            if cmd is not None:
                return self._steer(cmd, now, dt)
        return STOP

    # ---------------- 방향 붙잡기 (HEADING_HOLD) ----------------
    def _steer(self, cmd, now, dt):
        """
        몸을 돌리지 않는 동작 중에, 라이다로 본 벽 방향이 그대로 유지되도록 회전을 더한다.
        바퀴 하나가 느리면 직진해도 호를 그리며 휘는데, 틀어진 만큼 반대로 돌려서 잡는다.
        같은 쪽으로 계속 휘면 그 버릇을 배워서(움직이는 방향별로) 처음부터 미리 틀어준다.
        벽이 안 보이면(넓은 홀 등) 배운 버릇만 적용한다
        """
        if self.state == "ROUTE":
            return cmd                                   # 길 따라가기는 _route 가 방향까지 정함
        if self.state not in _HOLD_STATES:
            self.h_ref = None
            self.h_err = None
            return cmd
        vx, vy, wz = cmd
        v = math.hypot(vx, vy)
        if not config.HEADING_HOLD or v < 0.05:
            return cmd                                   # 멈춰 있을 때는 돌리지 않음 (기준은 유지)
        b = int(round(math.atan2(vy, vx) / (math.pi / 4))) % 8
        ff = self.h_bias[b] * v
        if self.runner is not None and self.g is not None:
            # 길 따라가는 중에 비키기 등: 오도메트리 자세로 기억한 방향을 붙잡는다
            e = math.degrees(self.g["th_err"])
            self.h_err = -e
            if abs(e) < 15 and config.HOLD_LEARN > 0 and self.moving:
                self.h_bias[b] = _clamp(self.h_bias[b] + config.HOLD_LEARN * e * dt / max(v, 0.1), 0.6)
            return vx, vy, ff + _clamp(config.HOLD_GAIN * e, config.HOLD_MAX)
        m = self.yaw.orient_now(now) if self.yaw is not None else None
        if m is None:
            # 곧은 벽이 충분히 안 보임: 배운 버릇만 적용 (스캔끼리 비교한 회전각은 직진, 옆걸음 중에
            # 가까운 물체 때문에 1초에 몇 도씩 틀어질 수 있어서 방향 붙잡기에는 쓰지 않는다)
            self.h_err = None
            return vx, vy, wz + ff
        if self.h_ref is None:
            # 벽과 거의 나란하면 벽에 맞추고, 많이 틀어져 있으면 지금 방향을 유지
            self.h_ref = 0.0 if abs(m) <= math.radians(config.HOLD_SNAP_DEG) else m
        e = math.degrees((m - self.h_ref + math.pi / 4) % (math.pi / 2) - math.pi / 4)   # 돌아야 할 각도 (반시계 +)
        if abs(e) > 30:
            self.h_ref = None                            # 방향을 잘못 본 것. 다음 스캔에서 다시 잡음
            self.h_err = None
            return vx, vy, wz + ff
        self.h_err = -e                                  # + 면 몸이 반시계로 틀어짐
        if abs(e) < 15 and config.HOLD_LEARN > 0 and self.moving:
            self.h_bias[b] = _clamp(self.h_bias[b] + config.HOLD_LEARN * e * dt / max(v, 0.1), 0.6)
        return vx, vy, ff + _clamp(config.HOLD_GAIN * e, config.HOLD_MAX)

    # ---------------- FORWARD / RETURN ----------------
    def _forward(self, pts, c, now, dt):
        front = strip_free(pts, 0.0)
        left, right = side_walls(pts)
        mis_vals = [w[1] for w in (left, right) if w is not None]
        mis = float(np.mean(mis_vals)) if mis_vals else None
        aligning = mis is not None and abs(mis) > math.radians(8)

        if front < config.SLOW_DIST and not aligning:
            # 미리 보이는 작은 장애물은 멈추지 않고 대각선으로 비켜 간다
            plan = self._plan_dodge(pts, front)
            if plan and abs(self.lane + plan[0] * plan[1]) <= config.MAX_DODGE + 0.3:
                self._start_dodge(plan, now, "앞에 장애물")
                return None
        if front < config.AVOID_DIST:
            if wall_ahead(pts, front):
                self._decide(pts, c, now, "앞이 벽")       # 벽은 기다려도 안 비키니 바로 판단
                if self.state in ("CORNER", "DODGE"):
                    return None
                return STOP
            if config.OBSTACLE_WAIT > 0:
                self._go("WAIT", now, "정면 막힘 → 잠깐 대기")
            else:
                self._decide(pts, c, now, "정면 막힘")
            return STOP

        k = max(0.0, min(1.0, (front - config.AVOID_DIST) / (config.SLOW_DIST - config.AVOID_DIST)))
        v = config.CRUISE_MIN + (config.CRUISE_SPEED - config.CRUISE_MIN) * k

        # 원래 길에서 옆으로 얼마나 벗어났나
        #   복도(양쪽 벽, 폭이 2·CORRIDOR_SIDE 이하): 복도 가운데 기준
        #   한쪽 벽만: 그 벽까지 거리를 기억해 두고 기준으로 씀 (바퀴 때문에 옆으로 밀려도 잡힘)
        #   벽이 없으면: 명령한 옆 속도를 적분 (비킨 만큼만 앎)
        corridor = (left is not None and right is not None
                    and left[0] + right[0] < 2 * config.CORRIDOR_SIDE
                    and abs(left[1] - right[1]) < math.radians(8))
        measured = True
        if corridor:
            self.lane = (right[0] - left[0]) / 2
            self.wall_ref = None
        else:
            measured = self._lane_from_one_wall(left, right)
        vy = 0.0
        err = -self.lane
        if abs(err) < 0.02 or (self.ret_ang and (err > 0) != (self.ret_sgn > 0)):
            self.ret_ang = 0.0                       # 원래 길에 도착
        if abs(err) > 0.05 or (self.ret_ang and abs(err) > 0.02):
            sgn = 1 if err > 0 else -1
            want = math.atan2(abs(err), config.RETURN_DIST)
            if not self.ret_ang or want > self.ret_ang + math.radians(2):
                # 돌아오기 시작할 때 각도를 정하고 끝까지 그 각도로 (그림 ①처럼 곧은 대각선).
                # 돌아오는 중에 오히려 더 벌어지면(바퀴 때문에 밀림) 각도를 키움
                self.ret_ang = want
                self.ret_sgn = sgn
            ang = self.ret_ang
            room = strip_free(pts, sgn * math.pi / 2)
            path = strip_free(pts, sgn * ang)
            if room > min(abs(err), 0.3) + config.SIDE_BLOCK and path > 0.6:
                vy = sgn * min(v * math.tan(ang), config.STRAFE_SPEED, abs(err) / 0.25 * config.STRAFE_SPEED)
        if not corridor:
            self.lane += self._lin(vy, dt)

        # 바퀴 때문에 옆으로 밀리는 버릇: 복도나 벽 기준으로 원래 길 근처에 있을 때 남는 오차로 배운다
        vy_return = vy
        if config.HEADING_HOLD:
            if measured and abs(err) < 0.10 and config.LAT_LEARN > 0 and self.moving:
                self.lat_bias = _clamp(self.lat_bias + config.LAT_LEARN * err * dt / max(v, 0.1), 0.3)
            vy += self.lat_bias * v

        # 옆 벽과 나란하게 (회전 오차가 쌓이지 않게). 많이 틀어졌으면 천천히 가면서 먼저 맞춘다
        wz = 0.0
        if mis is not None:
            wz = _clamp(-config.ALIGN_GAIN * mis, 0.3 if aligning else 0.15)
            if aligning:
                v = min(v, config.CRUISE_MIN)

        # 표시용 상태: 원래 길로 돌아가는 중인지 (밀림 보정분은 빼고, 깜빡이지 않게 문턱 두 개)
        if abs(vy_return) > 0.06:
            self.state = "RETURN"
        elif abs(vy_return) < 0.03:
            self.state = "FORWARD"
        return v, vy, wz

    def _lane_from_one_wall(self, left, right):
        """한쪽 벽까지 거리로 원래 길에서 벗어난 거리를 잼. 잴 수 있었으면 True"""
        walls = [(sd, w) for sd, w in ((1, left), (-1, right)) if w is not None]
        if not walls:
            self.wall_ref = None
            return False
        if self.wall_ref is not None:
            side, ref = self.wall_ref
            w = left if side > 0 else right
            if w is not None:
                meas = (ref - w[0]) if side > 0 else (w[0] - ref)
                if abs(meas - self.lane) < 0.25:          # 갑자기 튀면 다른 벽(기둥, 문)으로 보고 기준을 새로
                    self.lane = meas
                    return True
        side, w = min(walls, key=lambda sw: sw[1][0])     # 가까운 벽을 기준으로
        self.wall_ref = (side, w[0] + self.lane if side > 0 else w[0] - self.lane)
        return False

    # ---------------- WAIT ----------------
    def _wait(self, pts, c, now, dt):
        t_in = now - self.t_enter
        if strip_free(pts, self._travel()) > config.AVOID_DIST + config.HYSTERESIS:
            self.clear_count += 1
            if self.clear_count >= config.CLEAR_CYCLES:
                self._to_forward(now, "장애물이 비킴 → 전진")
        else:
            self.clear_count = 0
            if t_in >= config.OBSTACLE_WAIT:
                self._decide(pts, c, now, "계속 막힘")
                if self.state in ("CORNER", "DODGE"):
                    return None
        return STOP

    # ---------------- DODGE (A) ----------------
    def _dodge(self, pts, c, now, dt):
        side = self.dodge_side
        need_clear = max(config.PASS_CLEAR, 0.6)
        wide = strip_free(pts, 0.0, margin=config.CORRIDOR_MARGIN + 0.05)
        remain = self.dodge_need - self.dodge_moved
        if remain <= 0 or (wide >= need_clear and self.dodge_moved >= 0.5 * self.dodge_need):
            self._to_forward(now, "비켜섬 → 지나가기")
            return None
        if now - self.t_enter > config.STRAFE_TIMEOUT:
            self._decide(pts, c, now, "비켜 지나가기가 오래 걸림", allow_dodge=False)
            return STOP
        if strip_free(pts, side * math.pi / 2) < config.SIDE_BLOCK:
            # 옆이 벽에 닿음: 더 비킬 수 없으니 여기서 앞으로 (앞이 막혔으면 FORWARD 가 다시 판단)
            if self.dodge_moved >= 0.5 * self.dodge_need:
                self._to_forward(now, "옆이 막혀 비키기 마침")
                return None
            self._decide(pts, c, now, "비키던 쪽이 막힘", allow_dodge=False)
            return STOP
        front = strip_free(pts, 0.0)
        ahead = front - config.AVOID_DIST * 0.6
        ang0 = math.pi / 2 if ahead <= 0.05 else math.atan2(remain, ahead)
        # 그 각도로 가는 길이 막혔으면 더 옆으로 (90° = 옆걸음). 그래도 막히면 살짝 뒤로 빠지면서 옆으로 (최대 130°)
        ang = None
        angs = list(np.arange(ang0, math.pi / 2, math.radians(10))) + [math.pi / 2] + \
            [math.radians(d) for d in (100, 115, 130)]
        for a in angs:
            need = min(remain / max(0.2, math.sin(a)), 0.4)
            if strip_free(pts, side * a, margin=config.CORRIDOR_MARGIN + 0.05) < need:
                continue
            # 바퀴가 느리거나 미끄러지면 실제로는 명령보다 앞쪽으로 더 간다. 25° 앞쪽 방향도 조금은 트여 있어야 함
            a2 = max(0.0, a - math.radians(25))
            if a < math.pi / 2 and strip_free(pts, side * a2, margin=config.CORRIDOR_MARGIN) < min(need, 0.25):
                continue
            ang = a
            break
        if ang is None:
            self._decide(pts, c, now, "비키던 쪽이 막힘", allow_dodge=False)
            return STOP
        v = config.STRAFE_SPEED
        vx, vy = v * math.cos(ang), side * v * math.sin(ang)
        moved = self._lin(abs(vy), dt)
        self.dodge_moved += moved
        self.lane += side * moved
        return vx, vy, 0.0

    # ---------------- CORNER (C) ----------------
    def _corner(self, pts, c, now, dt):
        turned = math.radians(self.turn.turned(now)) * self.turn_sign
        rel = self.turn_dir - turned                     # 몸 기준 목표 방향 (돌수록 0으로)
        if self.turn.done(now) or abs(rel) < math.radians(4):
            self._to_forward(now, "모퉁이 돌기 완료" + (" (라이다로 잼)" if self.turn.used_lidar else ""),
                             new_heading=True)
            return None
        vx = vy = 0.0
        if strip_free(pts, rel) > config.SLIDE_STOP:
            vx, vy = config.SLIDE_SPEED * math.cos(rel), config.SLIDE_SPEED * math.sin(rel)
        if c.radial < config.TURN_MARGIN:
            if vx == 0.0 and vy == 0.0:
                self._start_turn_back(pts, c, now, "모퉁이에서 돌 공간 없음")
                return STOP
            return vx, vy, 0.0                           # 트인 쪽으로 먼저 빠져서 돌 공간을 만든다
        return vx, vy, self.turn_sign * config.TURN_SPEED

    # ---------------- SWEEP (B) ----------------
    def _sweep(self, pts, c, now, dt):
        turned = math.radians(self.turn.turned(now))
        if self.turn.done(now):
            self._to_forward(now, "둘러보기 완료" + (" (라이다로 잼)" if self.turn.used_lidar else ""))
            return None
        vx = vy = 0.0
        if self.sweep_moving:
            travel = -turned                              # 가던 방향은 그대로, 몸이 돈 만큼 반대로 보임
            if self.runner is not None and self.g is not None:
                travel = self.g["phi"]                    # 길 따라가는 중: 길 쪽으로 (오도메트리 기준)
            if strip_free(pts, travel) > config.SLOW_DIST:
                vx, vy = config.SWEEP_LINEAR * math.cos(travel), config.SWEEP_LINEAR * math.sin(travel)
            else:
                self.sweep_moving = False                 # 앞이 가까워지면 제자리에서 마저 돈다
        if c.radial < config.TURN_MARGIN:
            self.clear_count += 1                         # 돌 공간이 없는 시간 (주기 수)
            if self.clear_count > 3 * config.CTRL_HZ:
                self._to_forward(now, "둘러보기 중단 (돌 공간 없음)")
                return STOP
            return vx, vy, 0.0
        self.clear_count = 0
        return vx, vy, config.SWEEP_SPEED

    # ---------------- ESCAPE ----------------
    def _escape(self, pts, c, now, dt):
        gx, gy = self.esc_goal
        mx, my = self.esc_moved
        rx, ry = gx - mx, gy - my
        dist = math.hypot(rx, ry)
        arrived = dist < 0.03 or c.radial > config.TURN_MARGIN + 0.03
        if arrived or now - self.t_enter > config.STRAFE_TIMEOUT:
            if c.radial > config.TURN_MARGIN:
                # 돌 자리에 옴: 다시 판단 (트인 쪽이 보이면 C, 아니면 돌아 나가기)
                self._decide(pts, c, now, "돌 자리로 이동함", allow_dodge=False)
                return None if self.state in ("CORNER", "TURN_BACK") else STOP
            if _rear(pts) > config.REAR_STOP + config.HYSTERESIS:
                self._go("BACKOUT", now, "옆으로 가도 돌 공간 없음 → 후진")
            else:
                self._stuck_now(now, "돌 공간 없음 → 정지 대기")
            return STOP
        phi = math.atan2(ry, rx)
        if strip_free(pts, phi) < 0.03:
            self.esc_goal = self.esc_moved              # 막힘: 여기서 끝내고 다시 판단
            return STOP
        v = min(config.STRAFE_SPEED, max(0.12, dist / 0.25 * config.STRAFE_SPEED))
        vx, vy = v * math.cos(phi), v * math.sin(phi)
        self.esc_moved = (mx + self._lin(vx, dt), my + self._lin(vy, dt))
        return vx, vy, 0.0

    # ---------------- TURN_BACK ----------------
    def _turn_back(self, pts, c, now, dt):
        if c.radial < config.TURN_MARGIN:
            left = max(10.0, self.turn.target - self.turn.turned(now))
            self._start_turn_back(pts, c, now, "돌다가 벽에 가까워짐", deg=left)
            return STOP
        if self.turn.done(now):
            self._to_forward(now, "돌아 나가기 완료" + (" (라이다로 잼)" if self.turn.used_lidar else ""),
                             new_heading=True)
            return None
        return 0.0, 0.0, config.TURN_SPEED

    # ---------------- BACKOUT ----------------
    def _backout(self, pts, c, now, dt):
        if c.radial > config.TURN_MARGIN + 0.02:
            self.turn = Turn(self.turn_left, self.yaw, config.TURN_RATE_DEG_S, now)
            self._go("TURN_BACK", now, "돌 공간 확보 → 돌기")
            return None
        if _rear(pts) < config.REAR_STOP or now - self.t_enter > config.BACKUP_LONG_MAX:
            self._stuck_now(now, "더 물러날 곳 없음 → 정지 대기")
            return STOP
        # 후진하면서 좌우 가운데로 (한쪽 벽에 붙은 채로는 계속 돌 공간이 안 생김)
        vy = 0.0
        diff = (c.left - c.right) / 2
        if abs(diff) > 0.03 and math.isfinite(diff):
            vy = _clamp(2.0 * diff, 0.5 * config.STRAFE_SPEED)
        elif not math.isfinite(diff):
            vy = (0.5 if c.left > c.right else -0.5) * config.STRAFE_SPEED
        return -config.BACKUP_SPEED, vy, 0.0

    # ---------------- STUCK ----------------
    def _stuck(self, pts, c, now, dt):
        if now - self.t_enter > config.STUCK_RETRY:
            self.t_enter = now
            repeated = len([t for t in self.stucks if now - t < 60.0]) >= 2
            if strip_free(pts, self._travel()) > config.AVOID_DIST + config.HYSTERESIS and \
                    (not repeated or self.runner is not None):
                self._to_forward(now, "앞이 트임 → 전진")
            else:
                # 같은 곳에서 계속 막히면 앞으로 다시 가지 말고 더 멀리 돌 자리를 찾는다
                self._decide(pts, c, now, "재시도" + (" (반복해서 막힘)" if repeated else ""),
                             allow_dodge=not repeated)
        return STOP

    # ---------------- ROUTE (기억한 길 따라가기) ----------------
    def _route(self, pts, c, now, dt):
        """
        몸 방향과 상관없이 길 위 1m 앞 점(RETURN_DIST)을 향해 미끄러져 가고 (메카넘), 몸은 기억할 때 보던 방향으로 돌린다.
        길에서 벗어나 있으면 atan(벗어난 거리 / 1m) 각도로 돌아오게 된다. 길이 꺾이는 곳에서는 미끄러지면서 돈다
        """
        g = self.g
        if g is None:
            self._stuck_now(now, "기억한 길에서 위치를 잃음 → 정지")
            return STOP
        phi, th_err = g["phi"], g["th_err"]
        free = strip_free(pts, phi)
        if free < min(g["look"], 0.6):
            # 길로 돌아가는 대각선이 막혔으면 (방금 비켜선 경우) 트일 때까지 길과 나란히 간다
            alt = g["phi_path"]
            fa = strip_free(pts, alt)
            if fa > free:
                phi, free = alt, fa
        if free < config.AVOID_DIST:
            # 기억할 때보다 벽에 덜 붙어서 꺾이는 곳까지 못 간 경우: 조금 더 앞의 길 점을 보고 미리 꺾는다
            for ahead in (0.5, 0.8):
                p2, t2 = self.runner.peek(ahead)
                if abs(wrap_angle(p2 - phi)) > math.radians(20) and strip_free(pts, p2) > config.AVOID_DIST + 0.05:
                    phi, th_err = p2, t2
                    free = strip_free(pts, phi)
                    break
        # 길은 기억할 때 실제로 지나간 곳이라, 지금 보고 가는 점(look)보다 먼 벽은 막힌 게 아니다
        # (모퉁이 앞의 벽 등). 그 점까지 가는 길 위에 뭔가 있을 때만 막힌 것으로 본다
        reach = g["look"] + 0.15
        if free < max(0.12, min(config.AVOID_DIST, reach)):
            if config.OBSTACLE_WAIT > 0:
                self._go("WAIT", now, "길이 막힘 → 잠깐 대기")
            else:
                self._decide(pts, c, now, "길이 막힘")
            return STOP
        aligned = abs(th_err) < math.radians(10) and abs(phi) < math.radians(20)
        if free < min(config.SLOW_DIST, reach + 0.15) and aligned and g["look"] > 0.6 \
                and not wall_ahead(pts, strip_free(pts, 0.0)):
            plan = self._plan_dodge(pts, strip_free(pts, 0.0))
            if plan:
                self._start_dodge(plan, now, "길에 장애물")
                return None
        k = max(0.0, min(1.0, (free - config.AVOID_DIST) / (config.SLOW_DIST - config.AVOID_DIST)))
        v = config.CRUISE_MIN + (config.CRUISE_SPEED - config.CRUISE_MIN) * k
        turn = abs(th_err)
        if turn > math.radians(45):
            v *= 0.35                                   # 크게 꺾이는 곳: 천천히 미끄러지면서 돈다
        elif turn > math.radians(20):
            v *= 0.7
        e = math.degrees(th_err)
        b = int(round(phi / (math.pi / 4))) % 8
        ff = 0.0
        if config.HEADING_HOLD:
            ff = self.h_bias[b] * v
            if abs(e) < 15 and config.HOLD_LEARN > 0 and self.moving:
                self.h_bias[b] = _clamp(self.h_bias[b] + config.HOLD_LEARN * e * dt / max(v, 0.1), 0.6)
        lim = config.TURN_SPEED
        if c.radial < config.TURN_MARGIN and abs(e) > 10:
            lim = 0.05                                  # 벽에 가까우면 크게 돌지 않고 조금씩만
        self.h_err = -e
        vx, vy = v * math.cos(phi), v * math.sin(phi)
        # 기억한 길이 벽에 바짝 붙어 있어도 옆벽과 12cm 는 떨어져서 간다 (바퀴 때문에 밀리는 것도 여기서 잡힘)
        push = 0.0
        if c.left < 0.12:
            push -= 2.0 * (0.12 - max(c.left, 0.0))
        if c.right < 0.12:
            push += 2.0 * (0.12 - max(c.right, 0.0))
        vy += _clamp(push, 0.15)
        return vx, vy, ff + _clamp(config.HOLD_GAIN * e, lim)

    def _hold(self, pts, c, now, dt):
        self._to_forward(now, "재개")
        return None
