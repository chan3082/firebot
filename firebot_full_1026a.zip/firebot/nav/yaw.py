"""
라이다로 제자리 회전 각도 재기 (자이로 대용)

제자리에서 돌면 주변 벽이 반대 방향으로 돌아 보인다. 새 스캔을 바로 앞 스캔과 비교해서
몇 도 밀렸는지 찾고, 그걸 계속 더해서 누적 회전각을 만든다.

- 시간으로만 계산하면 배터리 전압이나 바닥 상태에 따라 180°가 120°나 300°가 된다
  (config.TURN_RATE_DEG_S 보정을 해도 매번 달라짐). 이걸로 실제로 돈 만큼을 잰다
- 매 스캔을 바로 앞 스캔과만 비교하므로, 복도처럼 앞뒤가 똑같이 생긴 곳에서도 180°를 헷갈리지 않는다
- 한 번에 찾는 범위는 ±MAX_STEP_DEG. 라이다 7Hz, 회전 45°/s 면 스캔 사이 6° 정도라 충분하다
- 비교가 안 되면 (점이 너무 적음, 주변이 텅 빔) healthy() 가 False 가 되고, 그때는 시간으로 계산한다

직진하면서 방향을 붙잡을 때(nav/navigator.py 의 HEADING_HOLD)는 wall_orient() 를 먼저 쓴다.
스캔끼리 비교하는 방식은 직진 중에 가까운 물체의 각도가 바뀌어(시차) 1초에 0.5~2° 씩 틀어진 값이 쌓이는데,
벽 방향은 직진해도 그대로라 오차가 쌓이지 않는다 (시뮬레이터에서 잡음 넣고 오차 2° 이내).

부호: 반시계(좌회전) 회전이 + (펌웨어 wz 와 같음)
"""
import math
import time

import numpy as np

BINS = 360              # 1° 간격
MAX_STEP_DEG = 30       # 스캔 한 번 사이에 돌 수 있는 최대 각도
MAX_RANGE = 6.0         # 이보다 먼 점은 비교에서 뺀다 (잡음이 많음)
MIN_OVERLAP = 60        # 두 스캔에 공통으로 있는 칸이 이만큼은 있어야 믿는다
MAX_SCORE = 0.12        # 가장 잘 맞는 위치의 차이 (거리 비의 로그, 중앙값). 이보다 크면 못 믿음

_SHIFTS = np.arange(-MAX_STEP_DEG, MAX_STEP_DEG + 1)
_IDX = (np.arange(BINS)[None, :] + _SHIFTS[:, None]) % BINS


def profile(x, y):
    """로봇 좌표계 점 → 1° 칸마다 가장 가까운 거리 (없으면 nan)"""
    x, y = np.asarray(x, float), np.asarray(y, float)
    d = np.hypot(x, y)
    keep = (d > 0.05) & (d < MAX_RANGE)
    idx = np.floor(np.degrees(np.arctan2(y[keep], x[keep])) % 360).astype(int) % BINS
    prof = np.full(BINS, np.inf)
    np.minimum.at(prof, idx, d[keep])
    prof[np.isinf(prof)] = np.nan
    return prof


def best_shift(prev, cur):
    """
    cur(φ) = prev(φ + δ) 가 되는 δ(도)를 찾는다. 로봇이 반시계로 δ 돌았다는 뜻.
    못 찾으면 None
    """
    ref = prev[_IDX]                                   # (후보 수, 360)
    valid = ~np.isnan(ref) & ~np.isnan(cur)[None, :]
    n = valid.sum(axis=1)
    with np.errstate(invalid="ignore", divide="ignore"):
        diff = np.abs(np.log(ref) - np.log(cur)[None, :])
    diff = np.where(valid, diff, np.nan)
    scores = np.full(len(_SHIFTS), np.inf)
    ok = n >= MIN_OVERLAP
    if not ok.any():
        return None
    scores[ok] = np.nanmedian(diff[ok], axis=1)
    i = int(np.argmin(scores))
    best = scores[i]
    if not np.isfinite(best) or best > MAX_SCORE:
        return None
    finite = scores[np.isfinite(scores)]
    med = float(np.median(finite)) if finite.size else 0.0
    if finite.size < 5 or (med - best) < max(0.3 * med, 0.02):
        return None                                    # 어디에 맞춰도 비슷함 (둥근 방, 텅 빈 곳) → 믿을 수 없음
    delta = float(_SHIFTS[i])
    if 0 < i < len(_SHIFTS) - 1 and np.isfinite(scores[i - 1]) and np.isfinite(scores[i + 1]):
        a, b, c = scores[i - 1], scores[i], scores[i + 1]
        den = a - 2 * b + c
        if den > 1e-9:
            delta += 0.5 * (a - c) / den               # 1° 칸 사이를 포물선으로 보간
    return delta


def _straight_pieces(x, y, r, out, depth=0):
    """
    각도 순으로 이어진 점 줄을 곧은 조각으로 나눈다. 양 끝을 잇는 선에서 가장 먼 점에서 자르기를 반복하고,
    25cm 이상 곧게 이어진 조각만 (방향, 길이) 로 남긴다
    """
    n = x.size
    if n < 10:
        return
    rm = float(r.mean())
    cx, cy = x[-1] - x[0], y[-1] - y[0]
    cl = math.hypot(cx, cy)
    if cl < 1e-6:
        return
    dev = np.abs((x - x[0]) * cy - (y - y[0]) * cx) / cl
    i = int(np.argmax(dev))
    if dev[i] > 0.08 + 0.03 * rm and depth < 12 and 0 < i < n - 1:
        _straight_pieces(x[:i + 1], y[:i + 1], r[:i + 1], out, depth + 1)
        _straight_pieces(x[i:], y[i:], r[i:], out, depth + 1)
        return
    dx, dy = x - x.mean(), y - y.mean()
    sxx, syy, sxy = (dx * dx).mean(), (dy * dy).mean(), (dx * dy).mean()
    psi = 0.5 * math.atan2(2 * sxy, sxx - syy)
    ux, uy = math.cos(psi), math.sin(psi)
    length = float(np.ptp(dx * ux + dy * uy))
    rms = float(np.sqrt(((-dx * uy + dy * ux) ** 2).mean()))
    if length >= 0.25 and rms < 0.03 + 0.012 * rm:
        out.append((psi, length))


def wall_orient(x, y, max_r=8.0):
    """
    스캔에서 곧은 면(벽, 상자 면)들의 방향을 모아, 90° 단위로 겹친 대표 방향 (rad, -45°~45°).
    실내 벽은 대부분 서로 직각이라 로봇이 δ 만큼 반시계로 돌면 이 값은 -δ 가 되고, 직진만 하면 그대로다.
    스캔끼리 비교하는 회전각(직진 중에는 가까운 물체의 시차 때문에 조금씩 틀어짐)과 달리 오차가 쌓이지 않는다.
    반환: (방향 또는 None, 일치도 0~1, 곧은 면 길이 합 m)
    """
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    r = np.hypot(x, y)
    k = (r > 0.15) & (r < max_r)
    x, y, r = x[k], y[k], r[k]
    if x.size < 20:
        return None, 0.0, 0.0
    o = np.argsort(np.arctan2(y, x))
    x, y, r = x[o], y[o], r[o]
    gap = np.hypot(np.diff(x), np.diff(y))
    cut = np.where(gap > 0.06 + 0.04 * np.minimum(r[:-1], r[1:]))[0] + 1
    pieces = []
    for a, b in zip(np.r_[0, cut], np.r_[cut, x.size]):
        _straight_pieces(x[a:b], y[a:b], r[a:b], pieces)
    if not pieces:
        return None, 0.0, 0.0
    psi = np.array([p[0] for p in pieces])
    w = np.array([p[1] for p in pieces])
    z = (w * np.exp(4j * psi)).sum()
    return float(np.angle(z) / 4), float(abs(z) / w.sum()), float(w.sum())


ORIENT_MIN_CONF = 0.5       # 벽 방향 일치도가 이보다 낮으면 (둥근 곳, 어수선한 곳) 안 씀
ORIENT_MIN_LEN = 0.8        # 곧은 면 길이 합이 이보다 짧으면 안 씀 (m)


class YawTracker:
    """main.py 가 새 스캔이 올 때마다 update() 를 부른다. 회전 중에는 yaw 의 변화량만 쓴다"""

    def __init__(self):
        self.yaw = 0.0
        self.updates = 0
        self.fails = 0
        self._prev = None
        self._last_ok = -1e9
        self.orient = None           # 벽 방향 (rad, wall_orient). 믿을 수 없으면 None
        self.orient_t = -1e9

    def update(self, x, y, now=None):
        now = time.time() if now is None else now
        a, conf, length = wall_orient(x, y)
        if a is not None and conf >= ORIENT_MIN_CONF and length >= ORIENT_MIN_LEN:
            self.orient, self.orient_t = a, now
        else:
            self.orient = None
        cur = profile(x, y)
        if self._prev is not None:
            d = best_shift(self._prev, cur)
            if d is None:
                self.fails += 1
            else:
                self.yaw += d
                self.updates += 1
                self._last_ok = now
        self._prev = cur

    def orient_now(self, now=None):
        """최근 스캔의 벽 방향 (rad). 낡았거나 믿을 수 없으면 None"""
        now = time.time() if now is None else now
        return self.orient if (self.orient is not None and now - self.orient_t < 0.5) else None

    def healthy(self, now=None):
        """최근에 비교가 잘 됐는지. 아니면 회전은 시간으로 계산한다"""
        now = time.time() if now is None else now
        return now - self._last_ok < 0.6


class Turn:
    """
    목표 각도만큼 도는 동안의 진행 상황.
    라이다 회전각이 믿을 만하면 그걸로, 아니면 시간(config.TURN_RATE_DEG_S)으로 잰다.
    둘 다 쓸 수 없게 되어도 끝없이 돌지 않도록 시간 기준의 TIME_CAP 배에서 끊는다
    """
    TIME_CAP = 2.5

    def __init__(self, deg, tracker, rate_deg_s, now):
        self.target = abs(deg)
        self.tracker = tracker
        self.rate = max(1.0, rate_deg_s)
        self.t0 = now
        self.yaw0 = tracker.yaw if tracker else 0.0
        self.used_lidar = False
        self._base, self._base_t = 0.0, now      # 마지막으로 믿을 수 있었던 값과 그 시각

    def turned(self, now):
        """지금까지 돈 각도 (도). 라이다 값이 끊기면 마지막 값에서 시간으로 이어 붙인다"""
        if self.tracker is not None and self.tracker.healthy(now):
            self.used_lidar = True
            self._base, self._base_t = abs(self.tracker.yaw - self.yaw0), now
            return self._base
        return self._base + (now - self._base_t) * self.rate

    def done(self, now):
        if now - self.t0 > self.TIME_CAP * self.target / self.rate:
            return True
        return self.turned(now) >= self.target - 2.0
