"""
라이다 오도메트리 (SLAM 없이 '얼마나, 어디로 움직였나'를 잼)

  ScanMatcher   기준 스캔 하나에 새 스캔을 맞춰서 둘 사이의 이동(dx, dy, 회전)을 구한다 (점-선 ICP)
  LidarOdom     출발점 기준 로봇 위치 (x, y, θ). 키 스캔(30cm 또는 15° 마다 새로)에 매 스캔을 맞춘다
                명령 속도로 짐작한 움직임을 같이 써서, 앞뒤가 똑같이 생긴 긴 복도처럼
                스캔만으로 알 수 없는 방향은 그 짐작을 따른다
                실내 벽이 서로 직각이라는 점을 써서(nav/yaw.wall_orient) 방향 오차가 쌓이지 않게 한다

좌표: 출발할 때 로봇 위치가 (0, 0), 앞이 +x, 왼쪽이 +y, 반시계가 +θ (rad)
"""
import math

import numpy as np

import config

try:
    from scipy.spatial import cKDTree
except Exception:                 # scipy 가 없으면 느리지만 직접 찾는다
    cKDTree = None


# ---------------------------------------------------------------- 자세 계산
def compose(a, b):
    """a 자세에서 본 b 자세 → 바깥 좌표 (a ∘ b)"""
    c, s = math.cos(a[2]), math.sin(a[2])
    return np.array([a[0] + c * b[0] - s * b[1], a[1] + s * b[0] + c * b[1], wrap(a[2] + b[2])])


def inverse(a):
    c, s = math.cos(a[2]), math.sin(a[2])
    return np.array([-c * a[0] - s * a[1], s * a[0] - c * a[1], -a[2]])


def relative(a, b):
    """a 에서 본 b (a⁻¹ ∘ b)"""
    return compose(inverse(a), b)


def wrap(t):
    return (t + math.pi) % (2 * math.pi) - math.pi


def transform(p, x, y):
    c, s = math.cos(p[2]), math.sin(p[2])
    return p[0] + c * x - s * y, p[1] + s * x + c * y


# ---------------------------------------------------------------- 점 고르기
def _prep(x, y, spacing, max_r=8.0):
    """가까운 점끼리 spacing 보다 촘촘하면 하나만 남김 (각도 순)"""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    r = np.hypot(x, y)
    k = (r > 0.15) & (r < max_r)
    x, y = x[k], y[k]
    if x.size == 0:
        return x, y
    o = np.argsort(np.arctan2(y, x))
    x, y = x[o], y[o]
    keep = [0]
    lx, ly = x[0], y[0]
    for i in range(1, x.size):
        if (x[i] - lx) ** 2 + (y[i] - ly) ** 2 >= spacing * spacing:
            keep.append(i)
            lx, ly = x[i], y[i]
    keep = np.array(keep)
    return x[keep], y[keep]


def _normals(x, y, win=2):
    """각도 순 점들의 법선 (앞뒤 win 개 점으로 직선 맞춤). 직선이 아니면 nan"""
    n = x.size
    nx = np.full(n, np.nan)
    ny = np.full(n, np.nan)
    if n < 2 * win + 1:
        return nx, ny
    X = np.lib.stride_tricks.sliding_window_view(x, 2 * win + 1)
    Y = np.lib.stride_tricks.sliding_window_view(y, 2 * win + 1)
    dx, dy = X - X.mean(1)[:, None], Y - Y.mean(1)[:, None]
    sxx, syy, sxy = (dx * dx).mean(1), (dy * dy).mean(1), (dx * dy).mean(1)
    half = (sxx + syy) / 2
    disc = np.sqrt(np.maximum(half * half - (sxx * syy - sxy * sxy), 0.0))
    l1, l2 = half + disc, np.maximum(half - disc, 0.0)
    psi = 0.5 * np.arctan2(2 * sxy, sxx - syy)            # 직선 방향
    span = np.hypot(X[:, -1] - X[:, 0], Y[:, -1] - Y[:, 0])
    rc = np.hypot(x, y)[win:n - win]
    ok = (l2 < 0.15 * l1 + 1e-6) & (span < 0.25 + 0.06 * rc)
    nx[win:n - win] = np.where(ok, -np.sin(psi), np.nan)
    ny[win:n - win] = np.where(ok, np.cos(psi), np.nan)
    return nx, ny


class _NN:
    def __init__(self, px, py):
        self.p = np.c_[px, py]
        self.tree = cKDTree(self.p) if cKDTree is not None else None

    def query(self, qx, qy):
        q = np.c_[qx, qy]
        if self.tree is not None:
            d, j = self.tree.query(q)
            return d, j
        d2 = ((q[:, None, :] - self.p[None, :, :]) ** 2).sum(-1)
        j = d2.argmin(1)
        return np.sqrt(d2[np.arange(len(j)), j]), j


# ---------------------------------------------------------------- 스캔 맞추기
class ScanMatcher:
    """기준 스캔(로봇 좌표계). match() 는 새 스캔을 이 기준 좌표계로 옮기는 자세 (dx, dy, dθ) 를 구한다"""
    SIGMA_R = 0.02          # 점-선 거리 잡음 (m)
    WEAK_MIN = 25.0         # 이동 방향 정보량이 이보다 작으면 (긴 복도의 앞뒤) 그 방향은 짐작(명령 속도)을 그대로 씀

    def __init__(self, x, y):
        px, py = _prep(x, y, 0.03)
        nx, ny = _normals(px, py)
        ok = np.isfinite(nx)
        self.x, self.y, self.nx, self.ny = px[ok], py[ok], nx[ok], ny[ok]
        self.ok = self.x.size >= 30
        self.nn = _NN(self.x, self.y) if self.ok else None

    def match(self, qx, qy, guess=(0.0, 0.0, 0.0), sigma=(0.3, 0.3, math.radians(20)), iters=20):
        """
        guess: 짐작한 자세, sigma: 그 짐작의 불확실함 (m, m, rad).
        반환: (자세 np.array, 정보 dict) 또는 (None, 정보)
          정보: inlier (맞은 점 비율), rms (m), weak (잘 안 잡히는 방향의 정보량. 작으면 그 방향은 짐작을 따랐다는 뜻)
        """
        info = {"inlier": 0.0, "rms": 9.9, "weak": 0.0, "n": 0}
        if not self.ok:
            return None, info
        sx, sy = _prep(qx, qy, 0.05)
        if sx.size < 20:
            return None, info
        p = np.array(guess, float)
        prior = p.copy()
        lam = np.diag([1 / sigma[0] ** 2, 1 / sigma[1] ** 2, 1 / sigma[2] ** 2])
        w0 = 1.0 / self.SIGMA_R ** 2
        for it in range(iters):
            c, s = math.cos(p[2]), math.sin(p[2])
            qx2, qy2 = p[0] + c * sx - s * sy, p[1] + s * sx + c * sy
            d, j = self.nn.query(qx2, qy2)
            dmax = max(0.12, 0.5 * (0.7 ** it))
            m = d < dmax
            if m.sum() < 15:
                return None, info
            nx, ny = self.nx[j[m]], self.ny[j[m]]
            ex, ey = qx2[m] - self.x[j[m]], qy2[m] - self.y[j[m]]
            r = nx * ex + ny * ey
            hub = 0.03
            w = np.where(np.abs(r) <= hub, 1.0, hub / np.maximum(np.abs(r), 1e-9)) * w0
            ax, ay = sx[m], sy[m]
            jt = nx * (-s * ax - c * ay) + ny * (c * ax - s * ay)
            J = np.stack([nx, ny, jt], 1)
            H = (J * w[:, None]).T @ J + lam
            g = (J * w[:, None]).T @ r + lam @ (p - prior)
            try:
                delta = -np.linalg.solve(H, g)
            except np.linalg.LinAlgError:
                return None, info
            p = p + delta
            p[2] = wrap(p[2])
            if abs(delta[0]) < 5e-4 and abs(delta[1]) < 5e-4 and abs(delta[2]) < 3e-4:
                break
        c, s = math.cos(p[2]), math.sin(p[2])
        qx2, qy2 = p[0] + c * sx - s * sy, p[1] + s * sx + c * sy
        d, j = self.nn.query(qx2, qy2)
        good = d < 0.08
        info["inlier"] = float(good.mean())
        info["n"] = int(good.sum())
        if good.any():
            rr = self.nx[j[good]] * (qx2[good] - self.x[j[good]]) + self.ny[j[good]] * (qy2[good] - self.y[j[good]])
            info["rms"] = float(np.sqrt((rr ** 2).mean()))
            Hm = (J * w[:, None]).T @ J / w0
            ev, vec = np.linalg.eigh(Hm[:2, :2])
            info["weak"] = float(ev[0])            # 가장 약한 이동 방향의 '점 수' 정도
            if ev[0] < self.WEAK_MIN:
                # 그 방향은 스캔으로 알 수 없음 (앞뒤가 똑같은 복도). 잡음에 끌려가지 않게 짐작한 값으로 되돌림
                v = vec[:, 0]
                p[:2] -= v * float(v @ (p[:2] - prior[:2]))
                info["degenerate"] = True
        return p, info


# ---------------------------------------------------------------- 오도메트리
class LidarOdom:
    KF_DIST = 0.30          # 키 스캔을 새로 잡는 이동 거리 (m)
    KF_ANG = math.radians(15)

    def __init__(self):
        self.reset()

    def reset(self, pose=(0.0, 0.0, 0.0)):
        self.pose = np.array(pose, float)
        self.kf = None              # (ScanMatcher, 그 때의 자세)
        self.motion = np.zeros(3)   # 앞 스캔 이후 명령 속도로 짐작한 움직임 (앞 스캔 로봇 좌표)
        self.wall_ref = None        # 출발 때 벽 방향 (바깥 좌표, rad, 90° 주기)
        self.last_info = {}
        self.matched = 0
        self.lost = 0
        if not hasattr(self, "speed_scale"):
            self.speed_scale = 1.0  # 실제 이동 / 명령 속도로 짐작한 이동 (스캔으로 잘 잡힐 때 배움. reset 해도 유지)

    # 매 제어 주기: 명령 속도로 움직임 짐작
    def add_motion(self, vx, vy, wz, dt):
        lin = config.STM32_MAX_LINEAR * self.speed_scale
        ang = math.radians(config.TURN_RATE_DEG_S / max(1e-6, config.TURN_SPEED))
        th = self.motion[2]
        dx, dy = vx * lin * dt, vy * lin * dt
        self.motion[0] += math.cos(th) * dx - math.sin(th) * dy
        self.motion[1] += math.sin(th) * dx + math.cos(th) * dy
        self.motion[2] = wrap(th + wz * ang * dt)

    # 새 스캔마다
    def update(self, x, y, orient=None, dyaw=None):
        """
        x, y: 로봇 좌표계 스캔 한 바퀴. orient: yaw.wall_orient 방향 (rad) 또는 None
        dyaw: 앞 스캔 이후 YawTracker 가 잰 회전 (rad) 또는 None. 명령 속도보다 믿을 만해서 짐작에 쓴다
              (바퀴 하나가 느리면 명령한 회전과 실제 회전이 다르다)
        """
        if dyaw is not None:
            self.motion[2] = dyaw
        predicted = compose(self.pose, self.motion)
        mot = self.motion.copy()
        self.motion = np.zeros(3)
        if self.kf is None:
            self.pose = predicted
            self._new_kf(x, y)
            self._wall_init(orient)
            return
        matcher, kf_pose = self.kf
        guess = relative(kf_pose, predicted)
        step = math.hypot(mot[0], mot[1])
        sigma = (0.03 + 0.4 * step, 0.03 + 0.4 * step, math.radians(2) + 0.4 * abs(mot[2]))
        p, info = matcher.match(x, y, guess, sigma)
        self.last_info = info
        if p is not None and (info["inlier"] > 0.5 or info["n"] >= 40) and info["rms"] < 0.045:
            prev = self.pose
            self.pose = compose(kf_pose, p)
            self.matched += 1
            moved = relative(prev, self.pose)
            if not info.get("degenerate") and step > 0.01:
                # 명령 속도와 실제 이동의 비율을 배움 (바퀴가 느리거나 STM32_MAX_LINEAR 가 실제와 다를 때)
                ratio = math.hypot(moved[0], moved[1]) / step
                if 0.3 < ratio < 3.0:
                    self.speed_scale = min(2.0, max(0.5, self.speed_scale * (1 + 0.05 * (ratio - 1))))
        else:
            self.pose = predicted                        # 못 맞추면 명령 속도로 짐작한 대로
            self.lost += 1
        self._wall_fix(orient)
        rel = relative(kf_pose, self.pose)
        if (math.hypot(rel[0], rel[1]) > self.KF_DIST or abs(rel[2]) > self.KF_ANG
                or p is None or info["inlier"] < 0.7):
            self._new_kf(x, y)

    def _new_kf(self, x, y):
        m = ScanMatcher(x, y)
        self.kf = (m, self.pose.copy()) if m.ok else None

    # 벽 방향(90° 주기)으로 방향 오차 바로잡기
    def _wall_init(self, orient):
        if orient is not None and self.wall_ref is None:
            self.wall_ref = wrap(self.pose[2] + orient)

    def _wall_fix(self, orient):
        if orient is None:
            return
        if self.wall_ref is None:
            self._wall_init(orient)
            return
        cand = self.wall_ref - orient                    # 이 값 + 90°·k 중 지금 짐작과 가까운 것
        k = round((self.pose[2] - cand) / (math.pi / 2))
        cand = cand + k * math.pi / 2
        err = wrap(cand - self.pose[2])
        if abs(err) < math.radians(5):                   # 크게 다르면 비스듬한 벽 → 무시
            self.nudge(np.array([0.0, 0.0, 0.3 * err]))

    def nudge(self, delta, full=None):
        """
        자세를 바로잡는다 (delta: 바깥 좌표에서 더할 dx, dy, dθ. dθ 는 지금 위치를 중심으로 돌림).
        full 을 주면 그 자세로 바꾼다. 키 스캔 자세도 같이 옮겨서 다음 맞추기에서 되돌아가지 않게 한다
        """
        old = self.pose.copy()
        if full is not None:
            new = np.array(full, float)
        else:
            new = old + delta
            new[2] = wrap(new[2])
        if self.kf is not None:
            m, kf_pose = self.kf
            self.kf = (m, compose(new, relative(old, kf_pose)))
        self.pose = new
