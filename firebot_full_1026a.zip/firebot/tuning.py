"""
웹 앱에서 바꿀 수 있는 설정

config.py 의 일부 값을 앱의 '설정' 화면에서 바로 바꾼다.
바꾼 값은 data/settings.json 에 저장되고, 다음에 실행할 때도 유지된다.
(config.py 를 고친 값보다 앱에서 바꾼 값이 우선한다. '기본값으로'를 누르면 config.py 값으로 돌아간다)

주행과 감지 코드는 매 순간 config 값을 다시 읽으므로, 바꾸면 재시작 없이 바로 적용된다.
"""
import json
import threading

import config

FILE = config.DATA_DIR / "settings.json"

# (키, 묶음, 이름, 종류, 최소, 최대, 단위, 간격, 설명)
ITEMS = [
    ("CRUISE_SPEED", "주행", "전진 속도", "float", 0.10, 0.80, "%", 0.05,
     "모터 최대 출력 대비 비율이에요. 바닥에서 잘 안 움직이면 올리세요"),
    ("STRAFE_SPEED", "주행", "옆으로 비키는 속도", "float", 0.10, 0.80, "%", 0.05, ""),
    ("OBSTACLE_WAIT", "주행", "장애물 앞 대기 시간", "float", 0.0, 5.0, "초", 0.5,
     "사람이 비켜줄 시간이에요. 0이면 바로 옆으로 비켜요"),
    ("AVOID_DIST", "주행", "회피 시작 거리", "float", 0.20, 0.80, "m", 0.05,
     "차체 앞 끝에서 장애물까지의 거리예요"),
    ("SLOW_DIST", "주행", "감속 시작 거리", "float", 0.40, 1.50, "m", 0.05, ""),
    ("SCAN_ENABLED", "주행", "주기적으로 둘러보기", "bool", None, None, "", None,
     "가던 방향으로 계속 가면서 몸만 360° 돌려 카메라로 주변을 살펴요 (예전 방식은 멈춰서 45°씩)"),
    ("SCAN_INTERVAL", "주행", "둘러보기 간격", "float", 10, 120, "초", 5, ""),
    ("HEADING_HOLD", "주행", "직진 방향 붙잡기", "bool", None, None, "", None,
     "라이다로 본 벽 방향을 기준으로, 바퀴 하나가 느려서 직진이 휘는 것을 바로잡아요"),
    ("YOLO_CONF", "화재 감지", "검출 신뢰도 기준", "float", 0.20, 0.80, "", 0.05,
     "낮추면 더 잘 잡지만 불이 아닌 것도 잡을 수 있어요"),
    ("CONFIRM_FRAMES", "화재 감지", "확정에 필요한 연속 검출", "int", 2, 10, "회", 1, ""),
    ("FLICKER_REQUIRED", "화재 감지", "일렁임이 있어야만 확정", "bool", None, None, "", None,
     "켜면 정지된 화재 사진으로는 알림이 울리지 않아요"),
    ("FLICKER_MOTION_MIN", "화재 감지", "일렁임 기준 (변화량)", "float", 0.5, 10.0, "", 0.5, ""),
    ("FLICKER_STD_MIN", "화재 감지", "일렁임 기준 (흔들림)", "float", 0.2, 5.0, "", 0.1, ""),
    ("ALERT_COOLDOWN", "화재 감지", "같은 알림 반복 간격", "float", 10, 300, "초", 10, ""),
    ("FIRE_HOLD", "화재 감지", "확정 후 멈춰서 감시", "bool", None, None, "", None,
     "켜면 불에서 물러나 멈춘 채 지켜봐요. '순찰 다시 시작'을 누르면 불 반대쪽으로 돌아서 순찰해요. "
     "끄면 물러난 뒤 바로 돌아서 순찰을 계속해요"),
    ("FIRE_KEEP_DIST", "화재 감지", "불과 떨어질 거리", "float", 0.5, 2.0, "m", 0.1,
     "확정 후 정면과 이 거리만큼 떨어질 때까지 뒤로 물러나요"),
]
_BY_KEY = {it[0]: it for it in ITEMS}
_DEFAULTS = {it[0]: getattr(config, it[0]) for it in ITEMS}
_lock = threading.Lock()


def _coerce(key, value):
    _, _, _, kind, lo, hi, *_ = _BY_KEY[key]
    if kind == "bool":
        if isinstance(value, str):
            return value.lower() in ("1", "true", "on", "yes")
        return bool(value)
    v = float(value)
    v = max(lo, min(hi, v))
    return int(round(v)) if kind == "int" else round(v, 3)


def _saved():
    if FILE.exists():
        try:
            return json.loads(FILE.read_text())
        except Exception:
            pass
    return {}


def _fix_dependencies():
    # 감속 시작은 회피 시작보다 멀어야 한다
    if config.SLOW_DIST < config.AVOID_DIST + 0.10:
        config.SLOW_DIST = round(config.AVOID_DIST + 0.10, 3)


def load():
    """실행 시작 때 한 번: 저장된 값을 config 에 반영"""
    for k, v in _saved().items():
        if k in _BY_KEY:
            setattr(config, k, _coerce(k, v))
    _fix_dependencies()


def describe():
    out = []
    for key, group, label, kind, lo, hi, unit, step, help_ in ITEMS:
        out.append({"key": key, "group": group, "label": label, "type": kind, "min": lo, "max": hi,
                    "unit": unit, "step": step, "help": help_,
                    "value": getattr(config, key), "default": _DEFAULTS[key]})
    return out


def update(changes: dict):
    with _lock:
        saved = _saved()
        slow_before = config.SLOW_DIST
        for k, v in changes.items():
            if k not in _BY_KEY:
                continue
            val = _coerce(k, v)
            setattr(config, k, val)
            saved[k] = val
        _fix_dependencies()
        if config.SLOW_DIST != slow_before:
            saved["SLOW_DIST"] = config.SLOW_DIST
        config.DATA_DIR.mkdir(exist_ok=True)
        FILE.write_text(json.dumps(saved, indent=1))
    return describe()


def reset():
    with _lock:
        for k, v in _DEFAULTS.items():
            setattr(config, k, v)
        if FILE.exists():
            FILE.unlink()
    return describe()
