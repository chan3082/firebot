"""
순찰 상위 상태머신

  PATROL   주행 로직에 주행을 맡기고 계속 감시
           (config.NAV_STYLE: "mecanum" 이면 nav/navigator.py, "legacy" 면 nav/avoidance.py)
  SCAN     SCAN_INTERVAL 마다 사방 둘러보기 (전방 카메라 1대의 사각 보완)
           메카넘 방식: 가던 방향으로 계속 가면서 몸만 360° 돈다 (멈추지 않음)
           예전 방식: 멈춰서 45°씩 돌며 각 방향을 잠깐씩 관찰
  CONFIRM  후보가 잡히면 정지하고 연속 프레임 + 일렁임으로 확인
  ALERT    확정되면 사진과 직전 영상을 저장하고 알림
  FIRE_BACKOFF  불 쪽(정면)과 FIRE_KEEP_DIST 이상 떨어지도록 뒤로 물러남
  FIRE_WATCH    멈춘 채 불을 계속 비추며 대기 (config.FIRE_HOLD = True, 기본)
                웹에서 '순찰 다시 시작'을 누르면 LEAVE 로
  LEAVE    불 반대쪽으로 180° 돌아서 순찰 재개 (FIRE_HOLD = False 면 확정 뒤 바로 이쪽)
           예전에는 확정 뒤 그대로 전진해서 불 쪽으로 다가갔다
           기억한 길을 따라가는 중(경로 순찰)이면 돌지 않고 길을 이어서 간다

회전량은 라이다로 잰다 (nav/yaw.py). 라이다 비교가 안 될 때만 시간(config.TURN_RATE_DEG_S)으로 계산한다.
"""
import time

import config
from nav.avoidance import compute_clearance
from nav.yaw import Turn


class Patrol:
    def __init__(self, avoider, watcher, alerts, yaw=None):
        self.avoider = avoider
        self.watcher = watcher
        self.alerts = alerts
        self.yaw = yaw                 # nav.yaw.YawTracker (없으면 회전을 시간으로 계산)

        self.state = "PATROL"
        self.t_enter = time.time()
        self.last_scan = time.time()
        self.reject_until = 0.0        # 알림 직후 재확인 억제

        self._scan_step = 0
        self._scan_phase = "turn"      # turn -> look
        self._alert_done = False
        self._turn = None              # 진행 중인 회전 (둘러보기, 돌아서 나가기)
        self.last_reason = ""
        self.event = ""                # 웹에 보여줄 설명

    # ------------------------------------------------------------------
    def _go(self, state, now):
        if state != self.state:
            # 순찰로 돌아올 때 회피 상태를 처음부터 다시 판단하게 한다
            # (가면서 둘러보기가 끝난 경우는 주행이 이어지는 중이라 그대로 둔다: 원래 길 기억 유지)
            if state == "PATROL" and not (self.state == "SCAN" and getattr(self, "_sweep", False)):
                self.avoider.reset(now)
            self.state = state
            self.t_enter = now
            self.event = ""

    def _candidate(self, now):
        """이동 중에도 후보가 보이면 멈춰서 확인할 값인지"""
        if now < self.reject_until or self.alerts.in_cooldown(now):
            return False
        det, hits = self.watcher.best()
        return det is not None and hits >= config.CANDIDATE_HITS

    def resume(self, now=None):
        """
        웹에서 '순찰 다시 시작'을 눌렀을 때.
        화재 감시 중이었으면 불 반대쪽으로 돌아선 뒤 순찰한다 (그대로 가면 불 쪽으로 감)
        """
        now = time.time() if now is None else now
        after_fire = self.state in ("ALERT", "FIRE_BACKOFF", "FIRE_WATCH", "LEAVE")
        self.watcher.reset()
        self.last_scan = now
        if after_fire and not self._on_route():
            self._start_leave(now)
            return
        if after_fire:
            self.reject_until = now + config.ALERT_COOLDOWN    # 같은 불로 다시 서지 않게
        self.state = "SCAN"            # _go 가 PATROL 전환으로 인식하도록
        self._sweep = False            # (둘러보기 끝으로 보지 않고 주행 상태를 처음부터 다시)
        self._go("PATROL", now)

    def _on_route(self):
        """기억한 길을 따라가는 중인지 (그러면 불 반대로 돌지 않고 길을 이어서 간다)"""
        return getattr(self.avoider, "runner", None) is not None

    def _start_leave(self, now):
        self.reject_until = now + config.ALERT_COOLDOWN    # 같은 불로 다시 서지 않게
        self._turn = Turn(180.0, self.yaw, config.TURN_RATE_DEG_S, now)
        self._go("LEAVE", now)
        self.event = "불 반대쪽으로 돌아서 순찰 재개"

    def _after_alert(self, now):
        if config.FIRE_HOLD:
            self._go("FIRE_WATCH", now)
            self.event = "불에서 떨어져 멈춘 채 지켜보는 중. 확인 후 '순찰 다시 시작'을 누르세요"
        elif self._on_route():
            self.reject_until = now + config.ALERT_COOLDOWN
            self._go("PATROL", now)
            self.event = "경로 순찰 이어서"
        else:
            self._start_leave(now)

    # ------------------------------------------------------------------
    def step(self, pts, now=None):
        """pts: 로봇 좌표계 라이다 점 (x, y) 또는 None"""
        now = time.time() if now is None else now
        dt = now - self.t_enter
        clearance = compute_clearance(*pts) if pts is not None else None

        # 라이다가 끊기면 무조건 정지
        if clearance is None and self.state in ("PATROL", "SCAN", "FIRE_BACKOFF", "LEAVE"):
            self.avoider.hold("lidar")
            return 0.0, 0.0, 0.0
        self.avoider.release()

        # ---------------- PATROL ----------------
        if self.state == "PATROL":
            if self._candidate(now):
                self._go("CONFIRM", now)
                self.watcher.flicker.reset()
                return 0.0, 0.0, 0.0
            # 주행이 안정된 상태에서만 둘러보기 시작
            if (config.SCAN_ENABLED
                    and now - self.last_scan > config.SCAN_INTERVAL
                    and self.avoider.state in ("FORWARD", "ROUTE")
                    and clearance.radial > config.TURN_MARGIN):
                if hasattr(self.avoider, "start_sweep"):
                    # 메카넘 방식: 가던 방향으로 계속 가면서 몸만 360° 돈다
                    self.avoider.start_sweep(now)
                    self._go("SCAN", now)
                    self._sweep = True
                    return 0.0, 0.0, 0.0
                self._sweep = False
                self._scan_step = 0
                self._scan_phase = "turn"
                self._turn = Turn(360.0 / config.SCAN_STEPS, self.yaw, config.TURN_RATE_DEG_S, now)
                self._go("SCAN", now)
                return 0.0, 0.0, 0.0
            return self.avoider.drive(pts, clearance, now)

        # ---------------- SCAN (가면서 둘러보기) ----------------
        if self.state == "SCAN" and getattr(self, "_sweep", False):
            if self._candidate(now):
                self.avoider.cancel_sweep(now)
                self._go("CONFIRM", now)
                self.watcher.flicker.reset()
                return 0.0, 0.0, 0.0
            cmd = self.avoider.drive(pts, clearance, now)
            if not self.avoider.sweeping:
                self.last_scan = now
                self._go("PATROL", now)
            return cmd

        # ---------------- SCAN (멈춰서 45°씩, 예전 방식) ----------------
        if self.state == "SCAN":
            # 도는 도중 장애물이 가까워지면 중단
            if clearance.radial < config.TURN_MARGIN:
                self.last_scan = now
                self._go("PATROL", now)
                return 0.0, 0.0, 0.0
            if self._candidate(now):
                self._go("CONFIRM", now)
                self.watcher.flicker.reset()
                return 0.0, 0.0, 0.0

            if self._scan_phase == "turn":
                if not self._turn.done(now):
                    return 0.0, 0.0, config.TURN_SPEED
                self._scan_phase = "look"
                self.t_enter = now
                self.watcher.reset()          # 회전 중 프레임은 버린다
                return 0.0, 0.0, 0.0

            # look 단계: 멈춰서 관찰
            if dt < config.SCAN_SETTLE + config.SCAN_LOOK:
                return 0.0, 0.0, 0.0
            self._scan_step += 1
            if self._scan_step >= config.SCAN_STEPS:
                self.last_scan = now
                self._go("PATROL", now)
            else:
                self._scan_phase = "turn"
                self._turn = Turn(360.0 / config.SCAN_STEPS, self.yaw, config.TURN_RATE_DEG_S, now)
                self.t_enter = now
            return 0.0, 0.0, 0.0

        # ---------------- CONFIRM ----------------
        if self.state == "CONFIRM":
            det, hits = self.watcher.best()
            fl = self.watcher.flicker_info()
            fallback = self.watcher.fallback
            need_flicker = config.FLICKER_REQUIRED or (fallback and config.FALLBACK_REQUIRE_FLICKER)
            # 일렁임 분석에는 FLICKER_WINDOW 만큼 시간이 필요하다.
            # 필수가 아니어도 그만큼은 기다려서, 잡히면 판정 근거에 넣는다
            grace = dt >= config.FLICKER_WINDOW + 0.5

            if det is not None and hits >= config.CONFIRM_FRAMES:
                if fl["ok"] or (not need_flicker and grace):
                    reason = "YOLO 연속 검출" if not fallback else "색상 검출(임시)"
                    if fl["ok"]:
                        reason += " + 일렁임"
                    self.last_reason = {
                        "reason": reason,
                        "label": det.label,
                        "conf": round(det.conf, 2),
                        "flicker": bool(fl["ok"]),
                        "motion": round(fl["motion"], 1),
                        "std": round(fl["std"], 1),
                        "detector": self.watcher.detector_name,
                    }
                    self.last_det = det
                    self._alert_done = False
                    self._go("ALERT", now)
                    return 0.0, 0.0, 0.0

            # 한동안 검출이 없거나 시간 초과면 포기
            lost = time.time() - self.watcher.last_det_time > 2.0
            if dt > config.CONFIRM_TIMEOUT or (lost and dt > 1.0):
                self.reject_until = now + 5.0   # 같은 장면으로 바로 다시 서지 않게
                self._go("PATROL", now)
            return 0.0, 0.0, 0.0

        # ---------------- ALERT ----------------
        if self.state == "ALERT":
            if not self._alert_done:           # 저장은 한 번만
                self._alert_done = True
                self.alerts.raise_alert(self.last_reason, getattr(self, "last_det", None))
                return 0.0, 0.0, 0.0
            if dt > 1.0:
                self._go("FIRE_BACKOFF", now)
                self.event = "불에서 물러나는 중"
            return 0.0, 0.0, 0.0

        # ---------------- FIRE_BACKOFF ----------------
        if self.state == "FIRE_BACKOFF":
            # 정면(불 쪽)과 FIRE_KEEP_DIST 이상 떨어질 때까지 뒤로. 뒤가 막히면 거기서 멈춤
            if (clearance.front >= config.FIRE_KEEP_DIST
                    or clearance.rear < config.REAR_STOP + config.HYSTERESIS
                    or dt > config.FIRE_BACKOFF_MAX):
                self._after_alert(now)
                return 0.0, 0.0, 0.0
            return -config.BACKUP_SPEED, 0.0, 0.0

        # ---------------- FIRE_WATCH ----------------
        if self.state == "FIRE_WATCH":
            return 0.0, 0.0, 0.0              # 웹에서 '순찰 다시 시작'을 누를 때까지 그대로

        # ---------------- LEAVE ----------------
        if self.state == "LEAVE":
            # 돌 공간이 없으면 돌지 않고 그냥 순찰로 (회피 로직이 알아서 빠져나감)
            if clearance.radial < config.TURN_MARGIN or self._turn.done(now):
                self.last_scan = now
                self._go("PATROL", now)
                return 0.0, 0.0, 0.0
            return 0.0, 0.0, config.TURN_SPEED

        return 0.0, 0.0, 0.0
