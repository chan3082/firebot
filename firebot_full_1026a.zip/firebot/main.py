#!/usr/bin/env python3
"""
화재 감지 순찰 로봇 메인

  python3 main.py --dry-run     모터 없이 판단만 (권장 첫 실행)
  python3 main.py --no-camera   카메라와 화재 감지 없이 주행과 회피만
  python3 main.py --dry-run --no-lidar
                                라이다 없이 화재 감지, 자동 촬영, 알림만 시험 (사방이 트였다고 가정)
  python3 main.py               전체 동작

실행하면 웹 사이트가 같이 열린다:  http://<로봇IP>:8000
사이트의 '비상 정지' 버튼이나 터미널의 Ctrl+C 로 멈춘다.
"""
import envcheck
envcheck.ensure_venv()

import argparse          # noqa: E402
import math              # noqa: E402
import queue             # noqa: E402
import signal            # noqa: E402
import sys               # noqa: E402
import threading         # noqa: E402
import time              # noqa: E402

import numpy as np       # noqa: E402
import config            # noqa: E402
import tuning            # noqa: E402
from nav.avoidance import Avoider, compute_clearance   # noqa: E402


def _on_sigterm(*_):
    raise KeyboardInterrupt


def fmt(v):
    return " inf " if v == float("inf") else f"{v:5.2f}"


class Shared:
    """메인 루프와 웹 사이트가 같이 보는 상태"""

    def __init__(self, mode):
        self.lock = threading.Lock()
        self.stopped = False
        self.data = {"mode": mode}

    def update(self, **kw):
        with self.lock:
            self.data.update(kw)

    def snapshot(self):
        with self.lock:
            d = dict(self.data)
        d["stopped"] = self.stopped
        return d


class _NoLidar:
    """--no-lidar 시험용: 로봇 둘레 3m 에 벽이 있다고 치고 점을 돌려준다 (사방이 트인 상태)"""

    def __init__(self, radius=3.0):
        import numpy as np
        th = np.radians(np.arange(0, 360, 1.0))
        self._pts = (radius * np.cos(th), radius * np.sin(th))

    def points(self):
        return self._pts

    def scan_points(self):
        return None               # 회전각은 시간으로 계산

    def close(self):
        pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="모터 명령을 보내지 않음")
    ap.add_argument("--no-camera", action="store_true", help="카메라와 화재 감지 사용 안 함")
    ap.add_argument("--no-lidar", action="store_true",
                    help="라이다 없이 실행 (--dry-run 과 같이만). 화재 감지와 알림 시험용")
    args = ap.parse_args()
    if args.no_lidar and not args.dry_run:
        ap.error("--no-lidar 는 --dry-run 과 같이만 쓸 수 있음 (라이다 없이 실제로 달리면 위험)")

    tuning.load()                 # 앱 설정 화면에서 바꾼 값 반영
    mode = "모터 끔" if args.dry_run else ("카메라 끔" if args.no_camera else "")
    if args.no_lidar:
        mode = "모터 끔, 라이다 없음"
    shared = Shared(mode)

    push = None
    try:
        from notify.push import PushService
        push = PushService()
    except Exception as e:
        print(f"[main] 푸시 알림을 쓸 수 없음 ({e}). python3-cryptography 설치를 확인")

    if args.no_lidar:
        lidar = _NoLidar()
        print("[main] 라이다 없이 실행: 사방이 3m 트여 있다고 가정 (모터 끔)")
    else:
        from hw.lidar import Lidar
        lidar = Lidar()
        print(f"[main] 라이다 열림: {config.LIDAR_PORT}")

    stm = None
    if not args.dry_run:
        from hw.stm32 import STM32
        stm = STM32()
        time.sleep(1.2)
        if not stm.link_ok():
            print("[main] STM32 상태 메시지가 없음. 포트와 펌웨어 확인")
        stm.arm(True)
        print("[main] STM32 시동")

    cam = watcher = alerts = patrol = None
    if not args.no_camera:
        from hw.camera import Camera
        from vision.watcher import FireWatcher
        from notify.alerts import AlertManager
        from mission.patrol import Patrol

        cam = Camera()
        watcher = FireWatcher(cam)
        alerts = AlertManager(cam, watcher, push)

    from nav.yaw import YawTracker
    yaw = YawTracker()            # 라이다로 회전각 측정 (둘러보기 45°, 막다른 길 180°)
    last_scan_id = -1

    if config.NAV_STYLE == "legacy":
        avoider = Avoider(yaw=yaw)          # 예전 방식: 정면 고정, 우측 → 좌측 → 후진
    else:
        from nav.navigator import Navigator
        avoider = Navigator(yaw=yaw)        # 메카넘 방식: A 비켜 지나가기, B 가면서 둘러보기, C 미끄러지며 돌기
    print(f"[main] 주행 방식: {'예전 방식 (정면 고정)' if config.NAV_STYLE == 'legacy' else '메카넘 방식'}")
    if watcher:
        patrol = Patrol(avoider, watcher, alerts, yaw=yaw)

    # ---------------- 경로 기억하고 따라가기 (nav/route.py) ----------------
    from nav.odom import LidarOdom, wrap
    from nav.route import Route, RouteLocalizer, RouteRecorder, RouteRunner
    from nav.navigator import strip_free, strip_mask, ManualHold
    from nav.mountcheck import MountCheck
    from collections import deque
    route_file = config.DATA_DIR / "route.npz"
    mount = MountCheck() if (getattr(config, "MOUNT_CHECK", True) and not args.no_lidar) else None
    manual_hold = ManualHold()    # 경로 기억 중 직접 운전할 때 방향 붙잡기
    moved = deque(maxlen=60)      # (시각, x, y) 오도메트리. 실제로 움직이는지 판단 (멈춰 있으면 휘는 버릇을 배우지 않음)
    blackbox = None
    if getattr(config, "RECORD_RUNS", True) and not args.no_lidar:
        from nav.blackbox import BlackBox
        blackbox = BlackBox({"args": " ".join(sys.argv[1:])})
        print(f"[main] 주행 기록: {blackbox.path.relative_to(config.BASE_DIR)} (이상하게 움직이면 이 파일을 보내 주세요)")
    odom = LidarOdom()            # 라이다로 잰 위치 (경로 기억을 시작한 곳이 원점)
    R = {
        "mode": "free",           # free 자유 순찰 | teach 경로 기억 중 | route 경로 순찰 | idle 대기
        "route": None, "loc": None, "rec": None, "runner": None,
        "framed": False,          # odom 좌표가 기억한 길 좌표와 같은지 (기억 직후)
        "manual": ((0.0, 0.0, 0.0), 0.0),
        "scans": 0, "fix": None,
        "stall": (0.0, 0.0),      # (길을 간 거리 m, 그때 시각): 오래 그대로면 앱에 알림
        "warn": "",
    }
    STALL_WARN_SEC = 60.0
    if route_file.exists():
        try:
            R["route"] = Route.load(route_file)
            R["loc"] = RouteLocalizer(R["route"])
            print(f"[main] 기억한 길 있음: {R['route'].length:.1f}m, "
                  f"{'한 바퀴 도는 길' if R['route'].closed else '갔다가 돌아오는 길'}")
        except Exception as e:
            print(f"[main] 기억한 길을 읽지 못함 ({e})")
    requests = queue.Queue()      # 웹에서 온 경로 명령은 메인 루프에서 처리 (스캔, 오도메트리와 같은 스레드)
    start_mode = getattr(config, "START_MODE", "free")
    if start_mode == "idle":
        R["mode"] = "idle"
    elif start_mode == "route" and R["route"] is not None and not args.no_lidar:
        R["mode"] = "idle"        # 첫 스캔이 들어오면 경로 순찰 시작을 시도 (실패하면 대기)
        requests.put(("route_start", {}, {}, threading.Event(), time.time()))

    def handle_route(action, body, sp, now):
        """메인 루프 안에서 실행. 반환: {"ok", "msg"}"""
        if sp is None:
            return {"ok": False, "msg": "라이다 스캔이 없어서 경로 기능을 쓸 수 없어요"}
        x, y = sp[0], sp[1]
        if action == "teach_start":
            odom.reset()
            R.update(rec=RouteRecorder(), framed=True, mode="teach", runner=None)
            if hasattr(avoider, "set_route"):
                avoider.set_route(None, now)
            shared.stopped = False
            if stm:
                stm.arm(True)
            return {"ok": True, "msg": "경로 기억 시작. 방향 버튼으로 순찰할 길을 운전하고, "
                                       "한 바퀴 돌았으면 출발점에서 '기억 끝'을 눌러 주세요"}
        if action == "teach_cancel":
            R.update(rec=None, mode="idle")
            return {"ok": True, "msg": "경로 기억을 취소했어요"}
        if action == "teach_stop":
            if R["mode"] != "teach" or R["rec"] is None:
                return {"ok": False, "msg": "경로 기억 중이 아니에요"}
            route, why = R["rec"].finish(x, y, odom.pose)
            if route is None:
                return {"ok": False, "msg": f"저장하지 못했어요: {why}"}
            route.save(route_file)
            R.update(route=route, loc=RouteLocalizer(route), rec=None, mode="idle", framed=True)
            print(f"[main] 경로 저장: {route.length:.1f}m, {why}")
            return {"ok": True, "msg": f"{route.length:.1f}m 길을 기억했어요. {why}. '경로 순찰 시작'을 누르면 따라가요"}
        if action == "route_start":
            route = R["route"]
            if route is None:
                return {"ok": False, "msg": "기억한 길이 없어요. 먼저 '경로 기억 시작'으로 한 번 운전해 주세요"}
            pose = None
            if R["framed"]:
                pose, _ = R["loc"].localize(x, y, odom.pose)
            if pose is None:
                pose, info = R["loc"].global_localize(x, y)
                if pose is None:
                    return {"ok": False, "msg": info.get("why", "위치를 찾지 못했어요")}
            odom.reset(pose)
            runner = RouteRunner(route, odom)
            R.update(runner=runner, mode="route", framed=True, stall=(-1e9, now), warn="")
            avoider.set_route(runner, now)
            if patrol:
                patrol.resume(now)
            shared.stopped = False
            if stm:
                stm.arm(True)
            return {"ok": True, "msg": f"경로 순찰 시작 (길의 {runner.progress() * 100:.0f}% 지점부터)"}
        if action == "free_start":
            if hasattr(avoider, "set_route"):
                avoider.set_route(None, now)
            R.update(runner=None, mode="free")
            if patrol:
                patrol.resume(now)
            shared.stopped = False
            if stm:
                stm.arm(True)
            return {"ok": True, "msg": "자유 순찰 시작"}
        if action == "route_clear":
            if R["mode"] == "route":
                avoider.set_route(None, now)
            R.update(route=None, loc=None, runner=None, mode="idle" if R["mode"] in ("route", "teach") else R["mode"])
            try:
                route_file.unlink()
            except FileNotFoundError:
                pass
            return {"ok": True, "msg": "기억한 길을 지웠어요"}
        return {"ok": False, "msg": f"알 수 없는 명령: {action}"}

    def route_info():
        """웹 앱 경로 탭 지도용 (웹 스레드에서 부름)"""
        d = {"mode": R["mode"], "pose": [round(float(v), 3) for v in odom.pose]}
        route = R["route"]
        if route is not None:
            d["route"] = route.summary()
        rec = R["rec"]
        if rec is not None:
            path = list(rec.path)
            step = max(1, len(path) // 400)
            d["teach_path"] = [[round(float(p[0]), 2), round(float(p[1]), 2)] for p in path[::step]]
            d["teach_len"] = round(rec.length, 1)
        runner = R["runner"]
        if runner is not None:
            d["laps"] = runner.laps
            d["progress"] = round(runner.progress(), 3)
        if R["warn"] and R["mode"] == "route":
            d["warn"] = R["warn"]
        return d

    # ---------------- 웹에서 누른 버튼 처리 ----------------
    def control(action, body=None):
        body = body or {}
        if action == "stop":
            shared.stopped = True
            R["manual"] = ((0.0, 0.0, 0.0), 0.0)
            if stm:
                stm.stop()
                stm.arm(False)            # 즉시 정지 (펌웨어가 PWM을 바로 끔)
            print("[main] 웹에서 비상 정지")
            return {"ok": True, "msg": "정지함"}
        if action == "resume":
            if stm:
                stm.arm(True)
            if R["mode"] == "idle":
                R["mode"] = "free"
            if patrol:
                patrol.resume()
            else:
                avoider.reset()
            shared.stopped = False
            print("[main] 웹에서 재개")
            return {"ok": True, "msg": "재개함"}
        if action == "drive":
            if R["mode"] != "teach":
                return {"ok": False, "msg": "직접 운전은 경로 기억 중에만 할 수 있어요"}
            lim = lambda v, m: max(-m, min(m, float(v or 0.0)))  # noqa: E731
            R["manual"] = ((lim(body.get("vx"), config.CRUISE_SPEED), lim(body.get("vy"), config.STRAFE_SPEED),
                            lim(body.get("wz"), config.TURN_SPEED)), time.time())
            return {"ok": True}
        if action in ("teach_start", "teach_stop", "teach_cancel", "route_start", "free_start", "route_clear"):
            if args.no_lidar:
                return {"ok": False, "msg": "라이다 없이 실행 중이라 경로 기능을 쓸 수 없어요"}
            box = {}
            done = threading.Event()
            requests.put((action, body, box, done, time.time()))
            if not done.wait(20.0):
                return {"ok": False, "msg": "로봇이 응답하지 않아요"}
            return box
        return {"ok": False, "msg": f"알 수 없는 명령: {action}"}

    from web.server import WebServer
    web = WebServer(cam, watcher, alerts, status_fn=shared.snapshot, control_fn=control, push=push,
                    route_fn=route_info)

    period = 1.0 / config.CTRL_HZ
    last_print = 0.0
    last_event = ""
    last_cmd = (0.0, 0.0, 0.0)
    prev_t = time.time()
    signal.signal(signal.SIGTERM, _on_sigterm)

    try:
        while True:
            t0 = time.time()
            new_scan = False
            odom.add_motion(*last_cmd, min(0.2, max(0.0, t0 - prev_t)))
            prev_t = t0
            sp = lidar.scan_points()
            if sp is not None and sp[2] != last_scan_id:
                last_scan_id = sp[2]
                y0 = yaw.yaw
                yaw.update(sp[0], sp[1], t0)
                dyaw = math.radians(yaw.yaw - y0) if yaw.healthy(t0) else None
                odom.update(sp[0], sp[1], yaw.orient_now(t0), dyaw)
                new_scan = True
                if blackbox is not None:
                    blackbox.add_scan(t0, sp[2], sp[0], sp[1], odom.pose, dyaw)
                if mount is not None and not mount.done:
                    prob = mount.update(last_cmd, None if dyaw is None else math.degrees(dyaw), sp[0], sp[1], t0)
                    if prob:
                        shared.stopped = True
                        R["manual"] = ((0.0, 0.0, 0.0), 0.0)
                        if stm:
                            stm.stop()
                        shared.update(warn=prob)
                        if blackbox is not None:
                            blackbox.note(mount_problem=prob)
                        print("\n" + "!" * 64 + f"\n  {prob}\n  로봇을 세웠어요\n" + "!" * 64 + "\n")
                    elif mount.done:
                        print("[main] 라이다 방향 확인 OK (도는 방향, 가는 방향 모두 맞음)")
                if R["mode"] == "teach" and R["rec"] is not None:
                    R["rec"].add(odom.pose, sp[0], sp[1])
                if R["mode"] == "route" and R["loc"] is not None:
                    R["scans"] += 1
                    if R["scans"] % 2 == 0:
                        # 기억한 키 스캔과 맞춰서 위치를 다시 잡는다 (오차가 쌓이지 않게)
                        fixed, _ = R["loc"].localize(sp[0], sp[1], odom.pose)
                        if fixed is not None:
                            p = odom.pose
                            blend = p + 0.5 * (fixed - p)
                            blend[2] = wrap(p[2] + 0.5 * wrap(fixed[2] - p[2]))
                            odom.nudge(None, full=blend)
            waiting = []
            while not requests.empty():
                req = requests.get_nowait()
                action, body, box, done, t_req = req
                if sp is None and t0 - t_req < 5.0:
                    waiting.append(req)            # 라이다 스캔이 들어올 때까지 잠깐 기다림 (켜자마자 등)
                    continue
                try:
                    box.update(handle_route(action, body, sp, t0))
                except Exception as e:
                    box.update({"ok": False, "msg": f"처리 중 오류: {e}"})
                print(f"[main] {action}: {box.get('msg', '')}")
                done.set()
            for req in waiting:
                requests.put(req)
            pts = lidar.points()
            if pts and sp is not None and abs(last_cmd[2]) > 0.05:
                # 도는 중에는 겹친 스캔이 몇 도씩 어긋나 번지므로 최신 한 바퀴만 쓴다
                pts = (sp[0], sp[1])
            c = compute_clearance(*pts) if pts else None
            # 실제로 움직이는지 (라이다 오도메트리로 최근 0.6초 동안 3cm 이상)
            moved.append((t0, float(odom.pose[0]), float(odom.pose[1])))
            while len(moved) > 2 and t0 - moved[0][0] > 0.6:
                moved.popleft()
            moving = math.hypot(moved[-1][1] - moved[0][1], moved[-1][2] - moved[0][2]) > 0.03 if not args.dry_run else False
            if hasattr(avoider, "moving"):
                avoider.moving = moving

            if shared.stopped:
                vx = vy = wz = 0.0
                state = "STOPPED"
            elif R["mode"] == "teach":
                # 경로 기억: 앱의 방향 버튼으로 직접 운전 (0.4초 동안 버튼 신호가 없으면 정지)
                (vx, vy, wz), mt = R["manual"]
                if t0 - mt > 0.4 or c is None:
                    vx = vy = wz = 0.0
                if (vx or vy) and strip_free(pts, math.atan2(vy, vx)) < 0.12:
                    vx = vy = 0.0                 # 부딪히기 직전이면 그쪽으로는 안 감
                if wz and c is not None and c.radial < 0.0:
                    wz = 0.0
                # 회전 버튼을 안 누르고 움직이는 동안은 방향을 붙잡는다 (한쪽 바퀴가 느려서 휘는 것)
                vx, vy, wz = manual_hold.apply(vx, vy, wz, float(odom.pose[2]), t0, moving)
                state = "TEACH"
            elif R["mode"] == "idle":
                vx = vy = wz = 0.0
                state = "IDLE"
            elif patrol:
                vx, vy, wz = patrol.step(pts, t0)
                driving = patrol.state in ("PATROL", "SCAN")
                state = f"{patrol.state}/{avoider.state}" if driving else patrol.state
            else:
                vx, vy, wz = avoider.drive(pts, c, t0)
                state = avoider.state

            last_cmd = (vx, vy, wz)
            if stm and not shared.stopped:
                stm.velocity(vx, vy, wz)
            elif stm:
                stm.heartbeat()

            if R["mode"] == "route" and R["runner"] is not None and R["route"] is not None:
                # 길을 오래 못 가면 앱에 알림: 길이 막혔거나, 출발점이 아닌 곳에서 시작해서 위치를 잘못 알고 있을 수 있음
                done_m = (R["runner"].laps + R["runner"].progress()) * R["route"].length
                navigating = not shared.stopped and (not patrol or patrol.state in ("PATROL", "SCAN"))
                if not navigating or abs(done_m - R["stall"][0]) > 0.3:
                    R["stall"] = (done_m, t0)
                    if R["warn"]:
                        R["warn"] = ""
                        print("[main] 다시 길을 가는 중")
                elif t0 - R["stall"][1] > STALL_WARN_SEC and not R["warn"]:
                    R["warn"] = (f"{STALL_WARN_SEC:.0f}초 넘게 길을 못 가고 있어요. 길이 막혔거나, 출발점이 아닌 곳에서 시작해서 "
                                 "위치를 잘못 알고 있을 수 있어요. 막힌 게 아니면 출발점에 놓고 '경로 순찰 시작'을 다시 눌러 주세요")
                    print(f"[main] {R['warn']}")

            event = (patrol.event if patrol and patrol.event else avoider.last_event)
            nav = {"mode": R["mode"], "pose": [round(float(v), 2) for v in odom.pose[:2]] +
                   [round(math.degrees(float(odom.pose[2])))]}
            if R["runner"] is not None:
                nav.update(laps=R["runner"].laps, progress=round(R["runner"].progress(), 3))
            if R["warn"] and R["mode"] == "route":
                nav["warn"] = R["warn"]
            if R["rec"] is not None:
                nav["teach_len"] = round(R["rec"].length, 1)
            if R["mode"] in ("teach", "idle"):
                top = R["mode"].upper()
            else:
                top = patrol.state if patrol else "PATROL"
            shared.update(
                nav=nav,
                state=top,
                avoid=(avoider.state if not patrol or patrol.state in ("PATROL", "SCAN") else ""),
                event=event,
                cmd=[round(vx, 2), round(vy, 2), round(wz, 2)],
                clearance=None if c is None else {"front": c.front, "left": c.left,
                                                  "right": c.right, "rear": c.rear},
                lidar_ok=c is not None,
                stm_ok=bool(stm and stm.link_ok()) if stm else False,
            )
            if new_scan and pts:
                # 앱 '라이다로 본 주변' 화면: 3m 안 점들과, 지금 가는 방향으로 0.8m 안에서 부딪히는 점 표시
                px_, py_ = pts
                near = (np.abs(px_) < 3.0) & (np.abs(py_) < 3.0)
                px_, py_ = px_[near], py_[near]
                step = max(1, -(-px_.size // 400))
                px_, py_ = px_[::step], py_[::step]
                v_ = math.hypot(vx, vy)
                hit = strip_mask((px_, py_), math.atan2(vy, vx), config.SLOW_DIST) if v_ > 0.02 else np.zeros(px_.size, bool)
                shared.update(scan={"x": np.round(px_, 2).tolist(), "y": np.round(py_, 2).tolist(),
                                    "hit": np.flatnonzero(hit).tolist()})
            if blackbox is not None:
                herr_ = manual_hold.err if R["mode"] == "teach" else getattr(avoider, "h_err", None)
                blackbox.add_row(t0, last_scan_id, (vx, vy, wz), state, getattr(avoider, "state", ""), event,
                                 herr_, c, R["mode"])

            if event != last_event:
                last_event = event
                if event:
                    print(f"  >> {event}")

            if t0 - last_print > 0.25:
                last_print = t0
                cs = "no data" if c is None else \
                    f"F{fmt(c.front)} L{fmt(c.left)} R{fmt(c.right)} B{fmt(c.rear)}"
                extra = ""
                if watcher:
                    det, hits = watcher.best()
                    if det:
                        fl = watcher.flicker_info()
                        extra = (f" | {det.label} {det.conf:.2f} hit{hits} "
                                 f"일렁임 {'O' if fl['ok'] else 'X'}({fl['motion']:.1f}/{fl['std']:.1f})")
                herr = manual_hold.err if R["mode"] == "teach" else getattr(avoider, "h_err", None)
                hold = "" if herr is None else f" 방향{herr:+.0f}°"
                where = ""
                if R["mode"] in ("teach", "route"):
                    where = f" @({odom.pose[0]:+.1f},{odom.pose[1]:+.1f})"
                    if R["runner"] is not None:
                        where += f" {R['runner'].laps}바퀴 {R['runner'].progress() * 100:.0f}%"
                print(f"[{state:20s}] {cs} -> {vx:+.2f} {vy:+.2f} {wz:+.2f}{hold}{where}{extra}")

            time.sleep(max(0.0, period - (time.time() - t0)))

    except KeyboardInterrupt:
        print("\n중단")
    finally:
        if stm:
            stm.close()
        if blackbox is not None:
            blackbox.save()
            print(f"[main] 주행 기록 저장: {blackbox.path.relative_to(config.BASE_DIR)}")
        if watcher:
            watcher.close()
        if cam:
            cam.close()
        lidar.close()
        web.close()
        print("정지 완료")


if __name__ == "__main__":
    main()
