#!/usr/bin/env python3
"""
PC에서 실행하는 알림 수신 서버 (선택 사항)

RPi가 알림을 밀어서 보내게 하고 싶을 때만 쓴다.
안 써도 RPi의 확인 페이지(http://로봇IP:8000)로 볼 수 있다.

PC에서:
    python receiver.py            기본 9000 포트
    python receiver.py 9100       포트 지정

그다음 RPi의 config.py 에서
    PC_RECEIVER_URL = "http://192.168.137.1:9000"
핫스팟에서 PC 주소는 보통 192.168.137.1 이다.

받은 파일은 이 스크립트 옆의 received/ 폴더에 쌓인다.
파이썬 기본 기능만 쓰므로 추가 설치가 필요 없다.
"""
import json
import sys
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

OUT = Path(__file__).resolve().parent / "received"
OUT.mkdir(exist_ok=True)


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        parsed = urlparse(self.path)

        if parsed.path == "/alert":
            try:
                item = json.loads(body)
            except Exception:
                item = {"raw": body[:200].decode(errors="ignore")}
            line = (f"{datetime.now():%H:%M:%S}  화재 알림  "
                    f"{item.get('time', '')}  근거 {item.get('reason', '-')}  "
                    f"신뢰도 {item.get('conf', '-')}  일렁임 {item.get('flicker', '-')}")
            print("\a" + line, flush=True)       # \a 는 알림음
            with (OUT / "alerts.log").open("a", encoding="utf-8") as f:
                f.write(json.dumps(item, ensure_ascii=False) + "\n")

        elif parsed.path == "/file":
            name = parse_qs(parsed.query).get("name", ["file.bin"])[0]
            name = Path(name).name                # 경로 주입 방지
            (OUT / name).write_bytes(body)
            print(f"           파일 저장: {name}  ({len(body)/1024:.0f} KB)", flush=True)

        self.send_response(200)
        self.send_header("Content-Length", "2")
        self.end_headers()
        self.wfile.write(b"ok")

    def log_message(self, *a):
        pass


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 9000
    print(f"수신 대기 중: 포트 {port}, 저장 위치 {OUT}")
    print("RPi config.py 에 PC_RECEIVER_URL 을 넣어야 전송됩니다. Ctrl+C 종료\n")
    try:
        ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
    except KeyboardInterrupt:
        print("\n종료")


if __name__ == "__main__":
    main()
