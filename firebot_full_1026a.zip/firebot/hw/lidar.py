"""
YDLIDAR X4PRO 드라이버 (순수 Python)

데이터시트
  - UART 128000 bps, 3.3V, 단방향(Tx only). 전원 인가 시 자동 송출
  - 측정 0.12 ~ 10 m. 0.12m 미만은 거리 0(무효)
  - 각도는 시계방향(+), 0°는 라이다 모터 쪽

패킷: PH(2) CT(1) LSN(1) FSA(2) LSA(2) CS(2) S1..Sn(2*LSN), little-endian
"""
import threading
import time
from collections import deque

import numpy as np

import config

HEADER = b"\xaa\x55"
PH = 0x55AA
HDR_LEN = 10


class X4ProParser:
    """바이트 스트림을 1회전 단위 스캔으로 조립"""

    def __init__(self, min_range=0.12, max_range=10.0):
        self.min_range = min_range
        self.max_range = max_range
        self.buf = bytearray()
        self._ang, self._dist = [], []
        self._last_fsa = None
        self.packets = 0
        self.bad_checksum = 0

    def feed(self, data: bytes):
        self.buf.extend(data)
        scans = []
        while True:
            i = self.buf.find(HEADER)
            if i < 0:
                del self.buf[:-1]
                break
            if i > 0:
                del self.buf[:i]
            if len(self.buf) < HDR_LEN:
                break
            ct, lsn = self.buf[2], self.buf[3]
            if lsn == 0:
                del self.buf[:2]
                continue
            total = HDR_LEN + 2 * lsn
            if len(self.buf) < total:
                break

            pkt = bytes(self.buf[:total])
            del self.buf[:total]

            fsa = pkt[4] | (pkt[5] << 8)
            lsa = pkt[6] | (pkt[7] << 8)
            cs = pkt[8] | (pkt[9] << 8)
            samples = np.frombuffer(pkt[10:], dtype="<u2")

            calc = PH ^ (ct | (lsn << 8)) ^ fsa ^ lsa ^ int(np.bitwise_xor.reduce(samples))
            if calc != cs:
                self.bad_checksum += 1
                continue
            self.packets += 1

            scan = self._handle(fsa, lsa, samples)
            if scan is not None:
                scans.append(scan)
        return scans

    def _handle(self, fsa, lsa, samples):
        a_start = (fsa >> 1) / 64.0
        a_end = (lsa >> 1) / 64.0
        n = len(samples)

        finished = None
        if self._last_fsa is not None and a_start < self._last_fsa - 180.0:
            finished = self._flush()
        self._last_fsa = a_start

        if n > 1:
            diff = (a_end - a_start) % 360.0
            ang = a_start + diff * np.arange(n) / (n - 1)
        else:
            ang = np.array([a_start])

        dist_mm = samples.astype(np.float64) / 4.0
        valid = dist_mm > 0
        corr = np.zeros(n)
        d = dist_mm[valid]
        corr[valid] = np.degrees(np.arctan(21.8 * (155.3 - d) / (155.3 * d)))
        ang = (ang + corr) % 360.0

        dist_m = dist_mm / 1000.0
        keep = valid & (dist_m >= self.min_range) & (dist_m <= self.max_range)
        self._ang.append(ang[keep])
        self._dist.append(dist_m[keep])
        return finished

    def _flush(self):
        if not self._ang:
            return None
        ang = np.concatenate(self._ang)
        dist = np.concatenate(self._dist)
        self._ang, self._dist = [], []
        return ang, dist


def _to_robot(ang, dist):
    """라이다 각도(도)와 거리(m) → 로봇 좌표계 (x 전방+, y 좌측+)"""
    th = ang if config.LIDAR_INVERTED else -ang
    th = np.radians(th + config.LIDAR_MOUNT_YAW)
    x = dist * np.cos(th) + config.LIDAR_OFFSET[0]
    y = dist * np.sin(th) + config.LIDAR_OFFSET[1]
    return x, y


class Lidar:
    """백그라운드 스레드로 수신하고 최신 스캔을 보관"""

    def __init__(self, port=None, baud=None, dtr=None):
        import serial

        self.ser = serial.Serial(port or config.LIDAR_PORT,
                                 baud or config.LIDAR_BAUD, timeout=0.05)
        # 어댑터 보드가 DTR로 모터 속도를 제어한다
        self.ser.dtr = config.LIDAR_DTR if dtr is None else dtr
        self.parser = X4ProParser()
        self._lock = threading.Lock()
        self._scan = None
        self._stamp = 0.0
        self._recent = deque(maxlen=max(1, config.LIDAR_MERGE_SCANS))   # (ang, dist, stamp)
        self.scan_count = 0
        self.scan_hz = 0.0
        self._running = True
        self._th = threading.Thread(target=self._loop, daemon=True)
        self._th.start()

    def _loop(self):
        last = None
        while self._running:
            try:
                data = self.ser.read(self.ser.in_waiting or 1)
            except Exception:
                break
            if not data:
                continue
            for scan in self.parser.feed(data):
                now = time.time()
                if last:
                    dt = now - last
                    if dt > 0:
                        self.scan_hz = 0.8 * self.scan_hz + 0.2 / dt
                last = now
                with self._lock:
                    self._scan, self._stamp = scan, now
                    self._recent.append((scan[0], scan[1], now))
                    self.scan_count += 1

    def latest(self):
        """(angles_deg, dist_m, age_sec) 또는 None"""
        with self._lock:
            if self._scan is None:
                return None
            ang, dist = self._scan
            return ang, dist, time.time() - self._stamp

    def scan_points(self):
        """
        가장 최근 스캔 한 바퀴만 로봇 좌표계로 (x, y, 스캔 번호). 데이터가 낡았으면 None
        회전각 측정(nav/yaw.py)용. 겹치지 않은 한 바퀴여야 회전 중에도 번지지 않는다
        """
        with self._lock:
            if self._scan is None or time.time() - self._stamp > config.LIDAR_STALE_SEC:
                return None
            ang, dist = self._scan
            count = self.scan_count
        if dist.size == 0:
            return None
        x, y = _to_robot(ang, dist)
        return x, y, count

    def points(self):
        """
        로봇 좌표계 점들 (x 전방+, y 좌측+). 데이터가 낡았으면 None
        최근 LIDAR_MERGE_SCANS 회 스캔을 겹친다. 의자 다리처럼 가는 물체는 한 바퀴에
        점이 2~3개밖에 안 찍혀서 잡음으로 버려질 수 있는데, 겹치면 점 수가 늘어난다.
        (0.2 m/s 로 달려도 스캔 사이 이동은 3cm 정도라 겹쳐도 위치 오차가 작다)
        """
        now = time.time()
        with self._lock:
            recent = [r for r in self._recent if now - r[2] <= config.LIDAR_STALE_SEC * 2]
        if not recent or now - recent[-1][2] > config.LIDAR_STALE_SEC:
            return None
        ang = np.concatenate([r[0] for r in recent])
        dist = np.concatenate([r[1] for r in recent])
        if dist.size == 0:
            return None
        return _to_robot(ang, dist)

    def close(self):
        self._running = False
        self._th.join(timeout=1.0)
        self.ser.close()
