"""
Raspberry Pi Camera Module 3 래퍼

- 프레임을 계속 받아 최신 프레임과 최근 몇 초치 영상 버퍼를 유지한다
- 화재 확정 시 사진과 직전 영상 클립을 저장한다 (버퍼 덕분에 '감지 이전' 장면도 남는다)

색 순서 주의
  Picamera2 의 "RGB888" 형식은 numpy 배열로 받으면 [B, G, R] 순서다 (Picamera2 매뉴얼).
  OpenCV 와 같은 순서라서 변환 없이 그대로 저장, 인코딩, YOLO 입력에 쓴다.
"""
import threading
import time
from collections import deque

import config


class Camera:
    def __init__(self):
        from picamera2 import Picamera2

        self.cam = Picamera2()
        cfg = self.cam.create_video_configuration(
            main={"size": config.CAM_SIZE, "format": "RGB888"},   # 실제로는 BGR 배열
            controls={"FrameRate": config.CAM_FPS},
        )
        self.cam.configure(cfg)
        self.cam.start()
        time.sleep(1.0)               # 자동 노출 안정화

        self._lock = threading.Lock()
        self._frame = None
        self._stamp = 0.0
        self.frames = 0
        self.fps = 0.0
        # 클립용 버퍼 (메모리 절약을 위해 축소 저장)
        self._clip = deque(maxlen=int(config.CLIP_SECONDS * config.CLIP_FPS))
        self._clip_period = 1.0 / config.CLIP_FPS
        self._last_clip = 0.0

        self._running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        import cv2

        stamps = deque(maxlen=120)
        while self._running:
            try:
                frame = self.cam.capture_array("main")      # BGR
            except Exception:
                time.sleep(0.1)
                continue
            now = time.time()
            # 최근 2초 동안 받은 프레임 수로 fps 계산 (순간값은 들쭉날쭉해서 쓰지 않음)
            stamps.append(now)
            while stamps and now - stamps[0] > 2.0:
                stamps.popleft()
            if len(stamps) > 1:
                self.fps = (len(stamps) - 1) / max(1e-3, stamps[-1] - stamps[0])
            with self._lock:
                self._frame, self._stamp = frame, now
                self.frames += 1
                if now - self._last_clip >= self._clip_period:
                    self._last_clip = now
                    self._clip.append((now, cv2.resize(frame, (640, 360))))

    def latest(self):
        """(frame_bgr, stamp) 또는 None. 복사본이 아니므로 수정하지 말 것"""
        with self._lock:
            if self._frame is None:
                return None
            return self._frame, self._stamp

    def snapshot(self):
        """수정해도 되는 복사본 (frame_bgr, stamp) 또는 None"""
        got = self.latest()
        if got is None:
            return None
        return got[0].copy(), got[1]

    def save_clip(self, path):
        """
        버퍼에 쌓인 최근 영상을 mp4 로 저장하고 (성공 여부, 설명) 을 돌려준다.
        아이폰과 브라우저는 H.264 만 재생하므로 프레임을 ffmpeg 에 바로 넘겨 H.264 로 만든다.
        (OpenCV 로 먼저 저장하고 변환하던 예전 방식은 OpenCV 쪽 코덱이 없으면 조용히 실패했다)
        ffmpeg 가 없거나 실패하면 OpenCV 로 저장한다. 이 파일은 폰에서 재생이 안 될 수 있다.
        """
        import os
        import shutil
        import subprocess

        import cv2

        with self._lock:
            frames = [f for _, f in self._clip]
        if len(frames) < 5:
            return False, f"버퍼에 프레임이 {len(frames)}장뿐"
        h, w = frames[0].shape[:2]
        path = str(path)
        t0 = time.time()

        reason = "ffmpeg 없음"
        if shutil.which("ffmpeg"):
            cmd = ["ffmpeg", "-v", "error", "-y",
                   "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{w}x{h}",
                   "-r", str(config.CLIP_FPS), "-i", "-",
                   "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p",
                   "-movflags", "+faststart", path]
            try:
                r = subprocess.run(cmd, input=b"".join(f.tobytes() for f in frames),
                                   capture_output=True, timeout=60)
                if r.returncode == 0 and os.path.exists(path) and os.path.getsize(path) > 0:
                    return True, f"H.264, {len(frames)}프레임, {time.time() - t0:.1f}초 걸림"
                err = r.stderr.decode(errors="ignore").strip().splitlines()
                reason = "ffmpeg 실패: " + (err[-1] if err else f"종료 코드 {r.returncode}")
            except Exception as e:
                reason = f"ffmpeg 실패: {e}"

        out = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), config.CLIP_FPS, (w, h))
        if not out.isOpened():
            return False, reason + ". OpenCV 로도 저장 못 함"
        for f in frames:
            out.write(f)
        out.release()
        return True, reason + ". 대신 OpenCV(mp4v)로 저장함 (폰에서 재생 안 될 수 있음)"

    def close(self):
        self._running = False
        time.sleep(0.2)
        try:
            self.cam.stop()
        except Exception:
            pass
