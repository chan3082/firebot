"""
STM32 (omnibot 펌웨어) 통신

프레임 형식: "<payload>*<HH>\\n"   HH = payload 바이트 합 & 0xFF
  A,1 / A,0          시동 켜기 / 끄기
  V,<vx>,<vy>,<wz>   속도 명령
  H                  연결 유지
펌웨어 워치독이 500ms라, 제어 루프에서 velocity()를 주기적으로 계속 불러야 한다.
"""
import threading
import time

import config


def frame(payload: str) -> bytes:
    cs = sum(payload.encode()) & 0xFF
    return f"{payload}*{cs:02X}\n".encode()


class STM32:
    def __init__(self, port=None, baud=None):
        import serial

        self.ser = serial.Serial(port or config.STM32_PORT,
                                 baud or config.STM32_BAUD, timeout=0.2)
        time.sleep(0.3)
        self.ser.reset_input_buffer()

        self._lock = threading.Lock()
        self._running = True
        self.status = ""          # 펌웨어가 1초마다 보내는 상태 문자열
        self.status_time = 0.0
        self.errors = 0
        self.armed = False
        threading.Thread(target=self._read_loop, daemon=True).start()

    # ---------- 내부 ----------
    def _write(self, payload):
        with self._lock:
            try:
                self.ser.write(frame(payload))
            except Exception:
                self.errors += 1

    def _read_loop(self):
        while self._running:
            try:
                line = self.ser.readline().decode(errors="ignore").strip()
            except Exception:
                break
            if not line:
                continue
            body = line.split("*")[0]
            if body.startswith("S,"):
                self.status = body[2:]
                self.status_time = time.time()
            elif body.startswith("E,"):
                self.errors += 1

    # ---------- 공개 ----------
    def arm(self, on=True):
        self._write(f"A,{1 if on else 0}")
        self.armed = on

    def velocity(self, vx, vy, wz):
        """정규화 값(-1~1)을 받아 펌웨어 단위로 변환해 전송"""
        vx = max(-1.0, min(1.0, vx)) * config.STM32_MAX_LINEAR
        vy = max(-1.0, min(1.0, vy)) * config.STM32_MAX_LINEAR
        wz = max(-1.0, min(1.0, wz)) * config.STM32_MAX_ANGULAR
        self._write(f"V,{vx:.3f},{vy:.3f},{wz:.3f}")

    def stop(self):
        self._write("V,0.000,0.000,0.000")

    def heartbeat(self):
        self._write("H")

    def link_ok(self, max_age=3.0):
        """펌웨어 상태 메시지가 최근에 왔는지"""
        return time.time() - self.status_time < max_age

    def close(self):
        try:
            self.stop()
            time.sleep(0.1)
            self.arm(False)
            time.sleep(0.1)
        finally:
            self._running = False
            self.ser.close()
