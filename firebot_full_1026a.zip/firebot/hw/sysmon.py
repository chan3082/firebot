"""
RPi 상태 확인 (연결 끊김 원인 찾기용)

- 입력 전압:  vcgencmd pmic_read_adc EXT5V_V   (RPi5 전용. 4.8V 아래로 떨어지면 전원이 약한 것)
- 전압 부족/과열 기록:  vcgencmd get_throttled
- 남은 메모리, CPU 온도, 부하
"""
import os
import re
import subprocess
from pathlib import Path


def _vc(*args):
    try:
        return subprocess.run(["vcgencmd", *args], capture_output=True, text=True, timeout=2).stdout
    except Exception:
        return ""


def read():
    d = {"volt": None, "throttled": None, "mem_mb": None, "temp": None, "load": None}
    m = re.search(r"=([\d.]+)V", _vc("pmic_read_adc", "EXT5V_V"))
    if m:
        d["volt"] = float(m.group(1))
    m = re.search(r"throttled=(0x[0-9a-fA-F]+)", _vc("get_throttled"))
    if m:
        d["throttled"] = int(m.group(1), 16)
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemAvailable:"):
                d["mem_mb"] = int(line.split()[1]) // 1024
                break
    except Exception:
        pass
    try:
        d["temp"] = int(Path("/sys/class/thermal/thermal_zone0/temp").read_text()) / 1000
    except Exception:
        pass
    try:
        d["load"] = os.getloadavg()[0]
    except Exception:
        pass
    return d


def warnings(d):
    """get_throttled 비트를 사람이 읽을 말로"""
    t = d.get("throttled") or 0
    out = []
    if t & 0x1:
        out.append("지금 전압 부족")
    elif t & 0x10000:
        out.append("켠 뒤 전압 부족 있었음")
    if t & 0x8:
        out.append("지금 과열 제한")
    elif t & 0x80000:
        out.append("켠 뒤 과열 제한 있었음")
    return out


def short(d):
    parts = []
    if d.get("volt") is not None:
        parts.append(f"전원 {d['volt']:.2f}V")
    if d.get("mem_mb") is not None:
        parts.append(f"메모리 여유 {d['mem_mb']}MB")
    w = warnings(d)
    if w:
        parts.append("!! " + ", ".join(w))
    return ", ".join(parts)


def line(d):
    """로그 파일용 한 줄"""
    vals = [
        f"{d['volt']:.2f}V" if d.get("volt") is not None else "전압 ?",
        f"throttled={hex(d['throttled'])}" if d.get("throttled") is not None else "throttled=?",
        f"메모리 여유 {d['mem_mb']}MB" if d.get("mem_mb") is not None else "",
        f"{d['temp']:.0f}°C" if d.get("temp") is not None else "",
        f"부하 {d['load']:.1f}" if d.get("load") is not None else "",
    ]
    w = warnings(d)
    if w:
        vals.append("!! " + ", ".join(w))
    return " | ".join(v for v in vals if v)
