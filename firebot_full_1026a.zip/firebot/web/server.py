"""
로봇 웹 앱 서버 (RPi 에서 실행)

  핫스팟 안:  http://<로봇IP>:8000
  외부 주소:  https://<기기이름>.<tailnet>.ts.net   (Tailscale Funnel, README 참고)
              홈 화면 설치와 푸시 알림은 https 주소에서만 된다

공개 (로그인 없이)
  /login                    로그인 화면
  /manifest.webmanifest     홈 화면 설치 정보
  /sw.js                    서비스 워커 (푸시 수신)
  /icons/<이름>              앱 아이콘

로그인 필요
  /                         앱
  /stream.mjpg?w=&fps=&q=   실시간 영상
  /snapshot.jpg             현재 화면 한 장
  /file/<이름>               저장된 사진, 영상
  /api/status               상태
  /api/alerts               감지 기록              POST /api/alerts/delete {"ids": [...]}
  /api/settings             설정 목록              POST /api/settings {키: 값}, /api/settings/reset
  /api/push/key             푸시 공개키            POST /api/push/subscribe, unsubscribe, test
  POST /api/control         {"action": "stop" | "resume" | "snapshot" | "teach_start" | "teach_stop" | "teach_cancel"
                             | "route_start" | "free_start" | "route_clear" | "drive", ("vx", "vy", "wz")}
  /api/route                기억한 길과 지금 위치 (경로 탭 지도)
  POST /logout

외부 라이브러리 없이 파이썬 기본 기능과 cryptography 만 쓴다.
"""
import json
import math
import os
import socket
import subprocess
import threading
import time
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import config
import tuning
from notify.alerts import draw_detections, load_items
from web.auth import COOKIE, Auth

WEB_DIR = Path(__file__).resolve().parent
PUBLIC_FILES = {
    "/login": ("login.html", "text/html; charset=utf-8"),
    "/manifest.webmanifest": ("manifest.webmanifest", "application/manifest+json"),
    "/sw.js": ("sw.js", "text/javascript; charset=utf-8"),
}


def _clean(obj):
    """JSON 에 못 넣는 inf, nan 을 None 으로"""
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, dict):
        return {k: _clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean(v) for v in obj]
    return obj


def _clamp(v, lo, hi, default):
    try:
        return max(lo, min(hi, int(float(v))))
    except (TypeError, ValueError):
        return default


class SysInfo:
    """CPU 온도, 전원 상태 (10초마다 갱신)"""

    def __init__(self):
        self._t = 0.0
        self._d = {}

    def get(self):
        if time.time() - self._t < 10:
            return self._d
        d = {"host": socket.gethostname()}
        try:
            d["cpu_temp"] = round(int(Path("/sys/class/thermal/thermal_zone0/temp").read_text()) / 1000, 1)
        except Exception:
            pass
        try:
            out = subprocess.run(["vcgencmd", "get_throttled"], capture_output=True, text=True,
                                 timeout=2).stdout.strip()
            val = int(out.split("=")[1], 16)
            d["undervolt_now"] = bool(val & 0x1)
            d["undervolt_ever"] = bool(val & 0x10000)
        except Exception:
            pass
        try:
            d["uptime_min"] = int(float(Path("/proc/uptime").read_text().split()[0]) // 60)
        except Exception:
            pass
        self._d, self._t = d, time.time()
        return d


class WebServer:
    def __init__(self, cam=None, watcher=None, alerts=None,
                 status_fn=None, control_fn=None, port=None, push=None, route_fn=None):
        self.cam = cam
        self.watcher = watcher
        self.alerts = alerts
        self.push = push
        self.status_fn = status_fn or (lambda: {})
        self.control_fn = control_fn
        self.route_fn = route_fn or (lambda: {})
        self.port = port or config.WEB_PORT
        self.auth = Auth()
        self.sys = SysInfo()

        self._jpg_lock = threading.Lock()
        self._jpg_cache = {}            # (w, q) -> (stamp, jpg)

        Handler = type("Handler", (_Handler,), {"app": self})
        self.httpd = ThreadingHTTPServer(("0.0.0.0", self.port), Handler)
        self.httpd.daemon_threads = True
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        pub = public_url()
        lan = ", ".join(f"http://{ip}:{self.port}" for ip in local_ips())
        print(f"[web] 폰 앱 주소: {pub or '(외부 주소 없음. bash tools/setup_remote.sh 참고)'}")
        print(f"[web] 핫스팟 안 주소: {lan}")
        if not self.auth.created_now:
            print("[web] 로그인 비밀번호를 모르면: Ctrl+C 로 끄고  python3 tools/set_password.py")

    # ---------------- 데이터 ----------------
    def status(self):
        try:
            robot = self.status_fn() or {}
        except Exception as e:
            robot = {"error": str(e)}
        vision = {"camera": self.cam is not None}
        if self.cam is not None:
            vision["cam_fps"] = round(getattr(self.cam, "fps", 0.0), 1)
        if self.watcher is not None:
            det, hits = self.watcher.best()
            fl = self.watcher.flicker_info()
            vision.update({
                "detector": self.watcher.detector_name,
                "fallback": self.watcher.fallback,
                "label": det.label if det else None,
                "conf": round(det.conf, 2) if det else None,
                "hits": hits,
                "confirm_frames": config.CONFIRM_FRAMES,
                "infer_ms": round(self.watcher.infer_ms),
                "flicker": {"ok": fl["ok"], "motion": round(fl["motion"], 1),
                            "std": round(fl["std"], 1), "n": fl["n"]},
                "flicker_min": {"motion": config.FLICKER_MOTION_MIN, "std": config.FLICKER_STD_MIN},
            })
        items = self.alert_items()
        today = time.strftime("%Y-%m-%d")
        return _clean({
            "time": time.time(),
            "robot": robot,
            "vision": vision,
            "system": self.sys.get(),
            "alerts": {
                "count": len(items),
                "latest": items[0]["id"] if items else None,
                "latest_fire": next((i["id"] for i in items if i.get("type") == "fire"), None),
                "today_fire": sum(1 for i in items if i.get("type") == "fire"
                                  and i.get("time", "").startswith(today)),
            },
            "push_devices": len(self.push.subs) if self.push else 0,
            "avoid_dist": config.AVOID_DIST,
            "slow_dist": config.SLOW_DIST,
            "body": [config.HALF_LENGTH, config.HALF_WIDTH],
        })

    def alert_items(self):
        return self.alerts.list() if self.alerts is not None else load_items()

    def frame_jpeg(self, width=None, quality=None):
        """검출 박스를 그린 현재 프레임 JPEG. 같은 프레임, 같은 크기는 접속자끼리 공유"""
        import cv2
        import numpy as np

        width = _clamp(width, 240, config.STREAM_WIDTH, config.STREAM_WIDTH)
        quality = _clamp(quality, 30, config.STREAM_QUALITY, config.STREAM_QUALITY)
        got = self.cam.latest() if self.cam is not None else None
        if got is None:
            img = np.full((int(width * 9 / 16), width, 3), 28, np.uint8)
            cv2.putText(img, "NO CAMERA", (width // 2 - 95, img.shape[0] // 2 + 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (160, 160, 160), 2, cv2.LINE_AA)
            return cv2.imencode(".jpg", img)[1].tobytes()

        frame, stamp = got
        key = (width, quality)
        with self._jpg_lock:
            hit = self._jpg_cache.get(key)
            if hit and hit[0] == stamp:
                return hit[1]

        h, w = frame.shape[:2]
        scale = width / w
        img = cv2.resize(frame, (width, int(h * scale)), interpolation=cv2.INTER_AREA)
        dets = self.watcher.detections() if self.watcher is not None else []
        if dets:
            from vision.detector import Detection
            draw_detections(img, [Detection(d.label, d.conf, tuple(v * scale for v in d.box))
                                  for d in dets])
        jpg = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, quality])[1].tobytes()
        with self._jpg_lock:
            self._jpg_cache[key] = (stamp, jpg)
        return jpg

    def control(self, action, body=None):
        if action == "snapshot":
            if self.alerts is None:
                return {"ok": False, "msg": "카메라가 없어서 찍을 수 없어요"}
            item = self.alerts.snapshot()
            return {"ok": bool(item), "msg": "사진을 저장했어요" if item else "사진을 찍지 못했어요"}
        if self.control_fn is None:
            return {"ok": False, "msg": "지금 실행 중인 프로그램은 주행을 하지 않아요"}
        return self.control_fn(action, body or {}) or {"ok": True}

    def close(self):
        self.httpd.shutdown()


class _Handler(BaseHTTPRequestHandler):
    app: WebServer = None
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    # ---------------- 공통 ----------------
    @property
    def _path(self):
        return urlparse(self.path).path

    @property
    def _query(self):
        return {k: v[0] for k, v in parse_qs(urlparse(self.path).query).items()}

    def _authed(self):
        c = SimpleCookie(self.headers.get("Cookie", ""))
        return COOKIE in c and self.app.auth.valid(c[COOKIE].value)

    def _body(self, limit=64 * 1024):
        n = int(self.headers.get("Content-Length", 0) or 0)
        return self.rfile.read(min(n, limit)) if n else b""

    def _json_body(self):
        try:
            return json.loads(self._body() or b"{}")
        except Exception:
            return {}

    def _send(self, body, ctype, code=200, extra=None, cache="no-store"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(json.dumps(_clean(obj), ensure_ascii=False).encode(),
                   "application/json; charset=utf-8", code)

    def _redirect(self, to, cookie=None):
        self.send_response(303)
        self.send_header("Location", to)
        self.send_header("Content-Length", "0")
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()

    def _cookie(self, value, max_age):
        return f"{COOKIE}={value}; Path=/; Max-Age={max_age}; HttpOnly; SameSite=Lax"

    # ---------------- GET ----------------
    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        p = self._path
        try:
            if p in PUBLIC_FILES:
                if p == "/login" and self._authed():
                    return self._redirect("/")
                name, ctype = PUBLIC_FILES[p]
                extra = {"Service-Worker-Allowed": "/"} if p == "/sw.js" else None
                return self._send((WEB_DIR / name).read_bytes(), ctype, extra=extra,
                                  cache="no-cache")
            if p.startswith("/icons/"):
                f = WEB_DIR / "icons" / Path(p).name
                if f.is_file():
                    return self._send(f.read_bytes(), "image/png", cache="max-age=86400")
                return self.send_error(404)

            if not self._authed():
                if p in ("/", "/index.html"):
                    return self._redirect("/login")
                return self._json({"error": "login"}, 401)

            if p in ("/", "/index.html"):
                return self._send((WEB_DIR / "index.html").read_bytes(), "text/html; charset=utf-8",
                                  cache="no-cache")
            if p == "/stream.mjpg":
                return self._stream()
            if p == "/snapshot.jpg":
                q = self._query
                return self._send(self.app.frame_jpeg(q.get("w"), q.get("q")), "image/jpeg")
            if p == "/api/status":
                return self._json(self.app.status())
            if p == "/api/alerts":
                return self._json(self.app.alert_items())
            if p == "/api/route":
                return self._json(_clean(self.app.route_fn() or {}))
            if p == "/api/settings":
                return self._json(tuning.describe())
            if p == "/api/push/key":
                push = self.app.push
                return self._json({"key": push.public_key if push else None,
                                   "devices": len(push.subs) if push else 0})
            if p.startswith("/file/"):
                return self._file(p[len("/file/"):])
            self.send_error(404)
        except (BrokenPipeError, ConnectionResetError):
            pass

    # ---------------- POST ----------------
    def do_POST(self):
        p = self._path
        if p == "/login":
            return self._login()
        if p == "/logout":
            return self._redirect("/login", self._cookie("", 0))
        if not self._authed():
            return self._json({"error": "login"}, 401)
        if not self.headers.get("Content-Type", "").startswith("application/json"):
            return self._json({"ok": False, "msg": "JSON 요청만 받아요"}, 415)
        body = self._json_body()
        app = self.app
        try:
            if p == "/api/control":
                return self._json(app.control(body.get("action", ""), body))
            if p == "/api/settings":
                return self._json({"ok": True, "items": tuning.update(body)})
            if p == "/api/settings/reset":
                return self._json({"ok": True, "items": tuning.reset()})
            if p == "/api/alerts/delete":
                if app.alerts is None:
                    return self._json({"ok": False, "msg": "지금은 기록을 지울 수 없어요"})
                n = app.alerts.delete(body.get("ids", []))
                return self._json({"ok": True, "deleted": n})
            if p.startswith("/api/push/"):
                return self._push_api(p, body)
        except Exception as e:
            return self._json({"ok": False, "msg": str(e)}, 500)
        self._json({"ok": False, "msg": "없는 주소"}, 404)

    def _push_api(self, p, body):
        push = self.app.push
        if push is None:
            return self._json({"ok": False, "msg": "푸시 기능이 꺼져 있어요"})
        if p == "/api/push/subscribe":
            push.subscribe(body.get("subscription", {}), origin=body.get("origin", ""),
                           device=self.headers.get("User-Agent", ""))
            return self._json({"ok": True, "devices": len(push.subs)})
        if p == "/api/push/unsubscribe":
            push.unsubscribe(body.get("endpoint", ""))
            return self._json({"ok": True, "devices": len(push.subs)})
        if p == "/api/push/test":
            if not push.subs:
                return self._json({"ok": False, "msg": "알림을 켠 기기가 없어요"})
            res = push.send_all({"title": "테스트 알림",
                                 "body": "이 알림이 보이면 화재 알림도 이 폰으로 와요",
                                 "tag": "test", "url": "/#settings"}, wait=True)
            ok = sum(1 for r in res if 200 <= r["code"] < 300)
            msg = f"{ok}대에 보냈어요" if ok else f"보내지 못했어요 ({res[0]['code']} {res[0]['msg'][:60]})"
            return self._json({"ok": ok > 0, "msg": msg, "results": res})
        return self._json({"ok": False, "msg": "없는 주소"}, 404)

    def _login(self):
        form = parse_qs(self._body(4096).decode(errors="ignore"))
        pw = form.get("password", [""])[0]
        auth = self.app.auth
        if auth.locked_for():
            return self._redirect(f"/login?e=lock&s={auth.locked_for()}")
        if auth.check_password(pw):
            token, age = auth.new_session()
            return self._redirect("/", self._cookie(token, age))
        if auth.locked_for():
            return self._redirect(f"/login?e=lock&s={auth.locked_for()}")
        return self._redirect("/login?e=1")

    # ---------------- 영상, 파일 ----------------
    def _stream(self):
        q = self._query
        fps = _clamp(q.get("fps"), 1, config.STREAM_FPS, config.STREAM_FPS)
        w, quality = q.get("w"), q.get("q")
        self.send_response(200)
        self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        period = 1.0 / fps
        try:
            while True:
                t0 = time.time()
                jpg = self.app.frame_jpeg(w, quality)
                self.wfile.write(b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: "
                                 + str(len(jpg)).encode() + b"\r\n\r\n" + jpg + b"\r\n")
                self.wfile.flush()
                time.sleep(max(0.0, period - (time.time() - t0)))
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        self.close_connection = True

    def _file(self, name):
        name = Path(name).name                       # 경로 조작 방지
        path = config.CAPTURE_DIR / name
        if not path.is_file():
            return self.send_error(404)
        ctype = {".jpg": "image/jpeg", ".png": "image/png", ".mp4": "video/mp4"}.get(
            path.suffix.lower(), "application/octet-stream")
        size = path.stat().st_size
        rng = self.headers.get("Range")
        extra = {"Accept-Ranges": "bytes"}
        if self._query.get("download"):
            extra["Content-Disposition"] = f'attachment; filename="{name}"'
        if rng and rng.startswith("bytes="):          # 영상 탐색용 부분 전송 (아이폰은 꼭 필요)
            a, _, b = rng[6:].partition("-")
            start = int(a) if a else max(0, size - int(b))
            end = int(b) if (a and b) else size - 1
            end = min(end, size - 1)
            with open(path, "rb") as f:
                f.seek(start)
                chunk = f.read(end - start + 1)
            extra["Content-Range"] = f"bytes {start}-{end}/{size}"
            return self._send(chunk, ctype, 206, extra, cache="max-age=3600")
        self._send(path.read_bytes(), ctype, extra=extra, cache="max-age=3600")


def public_url():
    """Tailscale Funnel 로 연 외부 주소 (없으면 빈 문자열)"""
    try:
        out = subprocess.run(["tailscale", "status", "--json"], capture_output=True, text=True,
                             timeout=3).stdout
        name = json.loads(out).get("Self", {}).get("DNSName", "").rstrip(".")
        return f"https://{name}" if name else ""
    except Exception:
        return ""


def local_ips():
    """핫스팟 안에서 접속할 주소 안내용"""
    ips = []
    try:
        out = subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=2).stdout
        ips = [ip for ip in out.split() if "." in ip and not ip.startswith("100.")]
    except Exception:
        pass
    return ips or ["<로봇IP>"]
