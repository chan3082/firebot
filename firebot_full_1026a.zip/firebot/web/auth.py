"""
웹 앱 로그인

- 비밀번호는 data/auth.json 에 PBKDF2 해시로 저장한다 (원문은 저장하지 않음)
- 처음 실행할 때 비밀번호가 없으면 임의로 만들어서 터미널에 크게 보여준다
  바꾸려면:  python3 tools/set_password.py
- 로그인하면 서명된 쿠키를 주고, SESSION_DAYS 동안 유지한다
- 연속으로 틀리면 잠깐 잠근다 (외부 주소가 열려 있으므로)
"""
import hashlib
import hmac
import json
import secrets
import threading
import time

import config

AUTH_FILE = config.DATA_DIR / "auth.json"
COOKIE = "fb_session"
_ITER = 200_000
_ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789"     # 헷갈리는 l, 1, o, 0 제외


def _hash(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), _ITER).hex()


def _load():
    if AUTH_FILE.exists():
        try:
            return json.loads(AUTH_FILE.read_text())
        except Exception:
            pass
    return {}


def _save(data):
    config.DATA_DIR.mkdir(exist_ok=True)
    AUTH_FILE.write_text(json.dumps(data, indent=1))
    try:
        AUTH_FILE.chmod(0o600)
    except Exception:
        pass


def set_password(password):
    data = _load()
    salt = secrets.token_hex(16)
    data["salt"] = salt
    data["hash"] = _hash(password, salt)
    data["secret"] = secrets.token_hex(32)   # 비밀번호를 바꾸면 기존 로그인은 모두 풀린다
    data["changed"] = time.strftime("%Y-%m-%d %H:%M:%S")
    _save(data)


class Auth:
    MAX_FAILS = 5
    LOCK_SEC = 30

    def __init__(self):
        self._lock = threading.Lock()
        self._fails = []
        self._locked_until = 0.0
        self.created_now = False
        data = _load()
        if not data.get("hash"):
            self.created_now = True
            pw = "".join(secrets.choice(_ALPHABET) for _ in range(8))
            set_password(pw)
            line = "=" * 56
            print(f"\n{line}\n  웹 앱 로그인 비밀번호:  {pw}\n"
                  f"  바꾸려면:  python3 tools/set_password.py\n{line}\n")
        self.reload()

    def reload(self):
        data = _load()
        self.salt = data["salt"]
        self.hash = data["hash"]
        self.secret = bytes.fromhex(data["secret"])

    # ---------------- 비밀번호 ----------------
    def locked_for(self):
        return max(0, int(self._locked_until - time.time()))

    def check_password(self, password):
        """맞으면 True. 너무 많이 틀리면 잠금"""
        with self._lock:
            now = time.time()
            if now < self._locked_until:
                return False
            ok = hmac.compare_digest(_hash(password or "", self.salt), self.hash)
            if ok:
                self._fails.clear()
                return True
            self._fails = [t for t in self._fails if now - t < 60] + [now]
            if len(self._fails) >= self.MAX_FAILS:
                self._locked_until = now + self.LOCK_SEC
                self._fails.clear()
            return False

    # ---------------- 세션 쿠키 ----------------
    def _sign(self, payload):
        return hmac.new(self.secret, payload.encode(), hashlib.sha256).hexdigest()

    def new_session(self):
        exp = int(time.time() + config.SESSION_DAYS * 86400)
        payload = f"{exp}.{secrets.token_hex(8)}"
        token = f"{payload}.{self._sign(payload)}"
        return token, config.SESSION_DAYS * 86400

    def valid(self, token):
        if not token or token.count(".") != 2:
            return False
        exp, nonce, sig = token.split(".")
        payload = f"{exp}.{nonce}"
        if not hmac.compare_digest(self._sign(payload), sig):
            return False
        try:
            return int(exp) > time.time()
        except ValueError:
            return False
