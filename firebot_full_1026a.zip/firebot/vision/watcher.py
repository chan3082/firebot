"""
화재 감시 스레드

  검출 스레드   : DETECT_HZ 주기로 YOLO 추론 → 검출 결과, 연속 검출 수 갱신
  일렁임 스레드 : 카메라 새 프레임마다(30fps) 검출 박스 안을 재서 일렁임 분석에 넣음

제어 루프(20Hz)와 추론(수 Hz)과 일렁임(30Hz)은 속도가 달라서 따로 돈다.

검출 스레드는 우선순위를 낮춘다. 추론이 CPU 를 많이 먹어도 원격 접속(VS Code, SSH),
웹 앱, 카메라가 먼저 돌게 해서 접속이 끊기지 않게 하려는 것이다.
모델도 이 스레드 안에서 불러온다. 그래야 추론용 작업 스레드들이 낮은 우선순위를 물려받는다.
"""
import os
import threading
import time

import config
from vision.detector import build_detector
from vision.flicker import FlickerAnalyzer


def iou(a, b):
    ix1, iy1 = max(a[0], b[0]), max(a[1], b[1])
    ix2, iy2 = min(a[2], b[2]), min(a[3], b[3])
    inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / ua if ua > 0 else 0.0


class FireWatcher:
    BOX_TTL = 1.0          # 검출이 끊겨도 이 시간 동안은 박스를 유지 (일렁임 계속 측정)

    def __init__(self, camera):
        self.cam = camera
        self.detector = None
        self.flicker = FlickerAnalyzer()

        self._lock = threading.Lock()
        self.dets = []
        self.hits = 0                 # 연속 검출 횟수
        self.last_det_time = 0.0
        self.track_box = None         # 일렁임을 재는 박스 (잦은 흔들림 방지를 위해 고정)
        self.enabled = True
        self.infer_ms = 0.0
        self.infer_count = 0

        self._running = True
        self._ready = threading.Event()
        threading.Thread(target=self._detect_loop, daemon=True).start()
        # 모델 준비가 끝날 때까지 기다림 (RPi 에서 첫 실행은 수십 초 걸릴 수 있음)
        print("[watcher] 화재 감지 모델 준비 중...")
        self._ready.wait(timeout=180)
        threading.Thread(target=self._flicker_loop, daemon=True).start()

    # ---------------- 외부 ----------------
    @property
    def fallback(self):
        return bool(self.detector and self.detector.is_fallback)

    @property
    def detector_name(self):
        return self.detector.name if self.detector else "준비 중"

    def enable(self, on=True):
        if on and not self.enabled:
            self.reset()
        self.enabled = on

    def reset(self):
        with self._lock:
            self.hits = 0
            self.dets = []
            self.track_box = None
        self.flicker.reset()

    def best(self):
        """(가장 신뢰도 높은 검출 또는 None, 연속 검출 수)"""
        with self._lock:
            return (self.dets[0] if self.dets else None), self.hits

    def detections(self):
        with self._lock:
            return list(self.dets)

    def flicker_info(self):
        return self.flicker.info()

    # ---------------- 내부 ----------------
    def _detect_loop(self):
        try:   # 이 스레드만 우선순위를 낮춤 (리눅스는 스레드마다 nice 값이 따로 있다)
            os.setpriority(os.PRIO_PROCESS, threading.get_native_id(), 10)
        except Exception:
            pass
        try:
            self.detector = build_detector()
        except Exception as e:
            from vision.detector import ColorDetector
            print(f"[watcher] 검출기 준비 실패({e}). 색상 검출기로 대체")
            self.detector = ColorDetector()
        finally:
            self._ready.set()
        period = 1.0 / config.DETECT_HZ
        while self._running:
            t0 = time.time()
            got = self.cam.latest() if self.enabled else None
            if got is None:
                time.sleep(0.1)
                continue
            frame, _ = got
            try:
                dets = self.detector.detect(frame)
            except Exception as e:
                print(f"[watcher] 검출 오류: {e}")
                dets = []
            now = time.time()
            with self._lock:
                self.infer_ms = (now - t0) * 1000
                self.infer_count += 1
                self.dets = dets
                if dets:
                    self.hits += 1
                    self.last_det_time = now
                    # 불이 여러 개 잡히면 신뢰도 1등이 번갈아 바뀌어 측정이 계속 초기화된다.
                    # 그래서 지금 따라가던 박스와 가장 많이 겹치는 검출을 고른다.
                    box = dets[0].box
                    if self.track_box is not None:
                        near = max(dets, key=lambda d: iou(d.box, self.track_box))
                        if iou(near.box, self.track_box) >= 0.1:
                            box = near.box
                    if self.track_box is None or iou(box, self.track_box) < 0.1:
                        # 완전히 다른 위치면 새로 시작
                        self.track_box = box
                        reset = True
                    else:
                        # 비슷한 위치면 부드럽게 따라감 (손떨림 영상에서도 측정이 끊기지 않게)
                        self.track_box = tuple(0.5 * n + 0.5 * o
                                               for n, o in zip(box, self.track_box))
                        reset = False
                else:
                    self.hits = 0
                    reset = False
                    if self.track_box and now - self.last_det_time > self.BOX_TTL:
                        self.track_box = None
                        reset = True
            if reset:
                self.flicker.reset()
            time.sleep(max(config.DETECT_MIN_GAP, period - (time.time() - t0)))

    def _flicker_loop(self):
        last_stamp = 0.0
        while self._running:
            box = self.track_box
            if not self.enabled or box is None:
                time.sleep(0.05)
                continue
            got = self.cam.latest()
            if got is None or got[1] == last_stamp:
                time.sleep(0.005)
                continue
            frame, last_stamp = got
            try:
                self.flicker.add(frame, box, last_stamp)
            except Exception as e:
                print(f"[watcher] 일렁임 오류: {e}")
                time.sleep(0.1)

    def close(self):
        self._running = False
