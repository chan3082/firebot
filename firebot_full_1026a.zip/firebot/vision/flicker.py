"""
불꽃 일렁임(흔들림) 분석

이전 버전은 YOLO 추론 주기(초당 4회)로만 밝기를 재서, 표본화 정리상 2Hz 넘는 흔들림은
원래 볼 수가 없었다(값이 늘 0으로 나온 원인). 이제 검출 박스 안을 카메라 프레임마다(30fps)
따로 재고, 세 가지 값을 본다.

  motion : 박스 안 픽셀이 프레임마다 얼마나 바뀌는지. 화면 전체의 변화(노출 변화, 흔들림)는 뺀다
           불꽃은 모양이 계속 바뀌어서 크고, 가만히 있는 빨간 물체나 빨간 화면은 0에 가깝다
  std    : 박스 평균 밝기가 흔들리는 크기
  ratio  : 밝기 변화 중 config.FLICKER_BAND 대역이 차지하는 비율 (참고용)
           화재 '영상'은 느린 변화가 많아 낮게 나오고, 잡음만 있는 화면은 오히려 높게 나와서
           기본 설정에서는 판정에 쓰지 않는다 (config.FLICKER_RATIO_MIN = 0)

motion 과 std 가 둘 다 기준을 넘으면 '일렁임 있음'.

한계
  - 로봇이 움직이는 중에는 값이 흔들린다. 멈춰서 확인할 때 쓴다
  - 정지 사진을 화면에 띄우면 흔들림이 없어서 일렁임이 안 잡힌다 (그래서 기본은 가산점)
  - 휴대폰 화면을 찍으면 화면 깜빡임 때문에 줄무늬가 생길 수 있다. 화면 밝기를 최대로 두면 줄어든다
"""
import threading
from collections import deque

import numpy as np

import config

ROI_SIZE = (48, 48)
BG_SIZE = (96, 54)


class FlickerAnalyzer:
    def __init__(self):
        self._lock = threading.Lock()
        self.reset()

    def reset(self):
        with getattr(self, "_lock", threading.Lock()):
            self.samples = deque()          # (t, roi_mean, roi_motion, bg_motion)
            self._prev_roi = None
            self._prev_bg = None

    def add(self, frame_bgr, box, t):
        import cv2

        h, w = frame_bgr.shape[:2]
        x1, y1, x2, y2 = box
        x1, y1 = max(0, int(x1)), max(0, int(y1))
        x2, y2 = min(w, int(x2)), min(h, int(y2))
        if x2 - x1 < 4 or y2 - y1 < 4:
            return
        roi = cv2.cvtColor(cv2.resize(frame_bgr[y1:y2, x1:x2], ROI_SIZE,
                                      interpolation=cv2.INTER_AREA),
                           cv2.COLOR_BGR2GRAY).astype(np.float32)
        bg = cv2.cvtColor(cv2.resize(frame_bgr, BG_SIZE, interpolation=cv2.INTER_AREA),
                          cv2.COLOR_BGR2GRAY).astype(np.float32)
        with self._lock:
            rm = float(np.abs(roi - self._prev_roi).mean()) if self._prev_roi is not None else None
            bm = float(np.abs(bg - self._prev_bg).mean()) if self._prev_bg is not None else None
            self._prev_roi, self._prev_bg = roi, bg
            self.samples.append((t, float(roi.mean()), rm, bm))
            while self.samples and self.samples[0][0] < t - config.FLICKER_WINDOW:
                self.samples.popleft()

    def info(self):
        """{'n','fs','motion','std','ratio','ok'}"""
        with self._lock:
            s = list(self.samples)
        out = {"n": len(s), "fs": 0.0, "motion": 0.0, "std": 0.0, "ratio": 0.0, "ok": False}
        if len(s) < 15:
            return out
        t = np.array([x[0] for x in s])
        span = t[-1] - t[0]
        if span < config.FLICKER_WINDOW * 0.6:
            return out
        fs = (len(t) - 1) / span
        out["fs"] = fs

        rm = [x[2] for x in s if x[2] is not None]
        bm = [x[3] for x in s if x[3] is not None]
        if rm and bm:
            out["motion"] = max(0.0, float(np.median(rm) - np.median(bm)))

        # 밝기 변화: 선형 추세를 빼고 흔들림만 본다
        v = np.array([x[1] for x in s])
        v = v - np.polyval(np.polyfit(t - t[0], v, 1), t - t[0])
        out["std"] = float(v.std())

        # 시간 간격이 고르지 않을 수 있으니 균일 간격으로 다시 뽑아서 주파수 분석
        tu = np.linspace(t[0], t[-1], len(t))
        vu = np.interp(tu, t, v) * np.hanning(len(t))
        spec = np.abs(np.fft.rfft(vu)) ** 2
        freq = np.fft.rfftfreq(len(vu), d=(tu[1] - tu[0]))
        total = spec[freq > 0.3].sum()
        lo, hi = config.FLICKER_BAND
        if total > 0:
            out["ratio"] = float(spec[(freq >= lo) & (freq <= min(hi, fs / 2))].sum() / total)

        out["ok"] = (out["motion"] >= config.FLICKER_MOTION_MIN
                     and out["std"] >= config.FLICKER_STD_MIN
                     and (config.FLICKER_RATIO_MIN <= 0 or out["ratio"] >= config.FLICKER_RATIO_MIN))
        return out
