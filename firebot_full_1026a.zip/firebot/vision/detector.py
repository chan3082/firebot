"""
화재 검출

1순위: YOLO (config.YOLO_MODEL)
2순위: 색상 기반 임시 검출기 (YOLO를 불러오지 못했을 때만)

입력 프레임은 BGR (hw/camera.py 참고). ultralytics 도 numpy 입력을 BGR 로 받는다.
임시 검출기는 빨간 물체를 불로 착각하기 쉬워서, 이걸로 돌 때는
config.FALLBACK_REQUIRE_FLICKER 에 따라 일렁임이 있어야만 화재로 확정한다.
"""
import numpy as np

import config


class Detection:
    def __init__(self, label, conf, box):
        self.label = label
        self.conf = conf
        self.box = box            # (x1, y1, x2, y2) 픽셀

    def __repr__(self):
        return f"<{self.label} {self.conf:.2f} {self.box}>"


class YoloDetector:
    """.pt 파일과 NCNN 변환본(_ncnn_model 폴더) 둘 다 받는다"""

    is_fallback = False

    def __init__(self, model_path):
        import numpy as np
        import torch
        from ultralytics import YOLO

        # CPU 코어를 다 쓰면 전력 소모가 한꺼번에 뛰고, 원격 접속과 웹도 CPU 를 못 받는다.
        # 첫 추론부터 일부 코어만 쓰게 제한
        threads = max(1, config.YOLO_THREADS)
        torch.set_num_threads(threads)
        self.ncnn = model_path.is_dir()
        if self.ncnn:
            _cap_ncnn_threads(threads)
        self.model = YOLO(str(model_path), task="detect")   # NCNN 은 task 명시 필요
        self.name = f"YOLO {model_path.name}"
        # 한 번 미리 돌려서 준비 (첫 추론은 오래 걸림). 모델은 여기서 처음 불러온다
        self.model.predict(np.zeros((360, 640, 3), np.uint8), imgsz=config.YOLO_IMGSZ, verbose=False)
        self._limit_ncnn_threads()          # 위 제한이 안 먹었을 때를 대비해 한 번 더
        # predict 전에 names 를 읽으면 ultralytics 가 모델을 한 번 더 불러온다. 그래서 여기서 읽음
        self.names = self.model.names
        want = {c.lower() for c in config.YOLO_CLASSES}
        self.keep = {i for i, n in self.names.items() if n.lower() in want}
        if not self.keep:
            print(f"[detector] 경고: 모델 클래스 {list(self.names.values())} 중 "
                  f"YOLO_CLASSES {config.YOLO_CLASSES} 와 맞는 게 없음")

    def _limit_ncnn_threads(self):
        if not self.ncnn:
            return
        pred = getattr(self.model, "predictor", None)
        backend = getattr(pred, "model", None)
        for obj in (backend, getattr(backend, "backend", None)):
            net = getattr(obj, "net", None)
            if net is not None and hasattr(net, "opt"):
                net.opt.num_threads = max(1, config.YOLO_THREADS)
                return

    def detect(self, frame_bgr):
        res = self.model.predict(frame_bgr, imgsz=config.YOLO_IMGSZ,
                                 conf=config.YOLO_CONF, verbose=False)[0]
        out = []
        for b in res.boxes:
            c = int(b.cls)
            if c not in self.keep:
                continue
            x1, y1, x2, y2 = (int(v) for v in b.xyxy[0])
            out.append(Detection(self.names[c].lower(), float(b.conf), (x1, y1, x2, y2)))
        out.sort(key=lambda d: -d.conf)
        return out


def _cap_ncnn_threads(n):
    """
    ultralytics 는 첫 추론 때 ncnn.Net() 을 만들고, 기본값은 코어 전부(RPi5 는 4개)다.
    Net 을 만드는 순간 스레드 수를 n 으로 정하게 감싸서, 준비용 첫 추론부터 n 개만 쓰게 한다.
    """
    try:
        import ncnn
    except ImportError:
        return
    orig = getattr(ncnn.Net, "_firebot_orig", ncnn.Net)

    def Net(*args, **kwargs):
        net = orig(*args, **kwargs)
        try:
            net.opt.num_threads = n
        except Exception:
            pass
        return net

    Net._firebot_orig = orig
    ncnn.Net = Net


class ColorDetector:
    """불꽃 색 영역(밝고 붉거나 노란 덩어리)을 찾는 임시 검출기"""

    is_fallback = True
    name = "색상 검출기 (임시)"
    MIN_AREA_RATIO = 0.004        # 화면의 0.4% 이상인 덩어리만

    def detect(self, frame_bgr):
        import cv2

        h, w = frame_bgr.shape[:2]
        hsv = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HSV)
        m1 = cv2.inRange(hsv, (0, 90, 170), (35, 255, 255))
        m2 = cv2.inRange(hsv, (160, 90, 170), (180, 255, 255))
        mask = cv2.bitwise_or(m1, m2)
        bright = cv2.inRange(hsv, (0, 0, 245), (180, 60, 255))     # 불꽃 중심의 흰 부분
        mask = cv2.bitwise_or(mask, cv2.bitwise_and(bright, cv2.dilate(mask, None, iterations=6)))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        mask = cv2.dilate(mask, np.ones((5, 5), np.uint8), iterations=2)

        cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        out = []
        for c in cnts:
            area = cv2.contourArea(c)
            if area < h * w * self.MIN_AREA_RATIO:
                continue
            x, y, bw, bh = cv2.boundingRect(c)
            conf = min(0.9, 0.3 + area / float(bw * bh) * 0.5)   # 대략적인 값
            out.append(Detection("fire?", conf, (x, y, x + bw, y + bh)))
        out.sort(key=lambda d: -(d.box[2] - d.box[0]) * (d.box[3] - d.box[1]))
        return out[:3]


def _banner(msg):
    line = "!" * 64
    print(f"\n{line}\n  {msg}\n{line}\n")


def build_detector():
    path = config.YOLO_MODEL
    ncnn = path.with_name(f"{path.stem}_ncnn_model")
    if config.YOLO_PREFER_NCNN and path.suffix == ".pt" and (ncnn / "model.ncnn.param").exists():
        try:
            det = YoloDetector(ncnn)
            print(f"[detector] {det.name} 사용 (NCNN, 코어 {config.YOLO_THREADS}개), "
                  f"클래스 {list(det.names.values())}, imgsz {config.YOLO_IMGSZ}")
            return det
        except Exception as e:
            print(f"[detector] NCNN 모델을 불러오지 못함({e}). PyTorch 모델로 대체")
    if not path.exists():
        rel = lambda p: p.relative_to(config.BASE_DIR) if p.is_relative_to(config.BASE_DIR) else p
        if not (ncnn / "model.ncnn.param").exists():
            _banner(f"화재 감지 모델이 없음 ({rel(ncnn)} 폴더도, {rel(path)} 도 없음)\n"
                    f"  firebot_full zip 을 다시 풀 것. 지금은 색상 검출기로 대체 (빨간 물체 오탐 많음)")
        else:
            _banner(f"NCNN 모델을 못 써서 {rel(path)} 를 찾았지만 없음. 원인은 바로 위 [detector] 줄\n"
                    f"  지금은 색상 검출기로 대체 (빨간 물체 오탐 많음)")
        return ColorDetector()
    try:
        det = YoloDetector(path)
        print(f"[detector] {det.name} 사용 (PyTorch, 코어 {config.YOLO_THREADS}개), "
              f"클래스 {list(det.names.values())}, imgsz {config.YOLO_IMGSZ}")
        return det
    except Exception as e:
        _banner(f"YOLO 로드 실패: {e}\n  색상 검출기로 대체 (빨간 물체 오탐 많음). "
                f"가상환경이 켜져 있는지 확인")
        return ColorDetector()
