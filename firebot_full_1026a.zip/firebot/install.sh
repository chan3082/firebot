#!/bin/bash
# firebot 설치 스크립트 (SD카드를 새로 구웠을 때나 venv 가 없을 때 실행)
#   cd ~/firebot && bash install.sh
# 여러 번 실행해도 안전하다 (이미 된 단계는 건너뜀)
set -e
cd "$(dirname "$0")"

echo "== 1/5 시스템 패키지 =="
sudo apt update
sudo apt install -y python3-venv python3-picamera2 python3-opencv python3-cryptography tmux ffmpeg unzip

echo "== 2/5 가상환경 =="
if [ ! -f venv/bin/activate ]; then
    python3 -m venv --system-site-packages venv
fi
source venv/bin/activate

echo "== 3/5 파이썬 패키지 (ultralytics 는 오래 걸림) =="
pip install pyserial numpy
# PyPI 의 ARM 용 torch 는 NVIDIA GPU 라이브러리(수 GB)까지 같이 깐다. RPi 에는 GPU 가 없으니 CPU 전용판을 먼저 깐다
pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu \
    || echo "!! CPU 전용 torch 설치 실패. 기본 torch 로 진행 (용량만 더 큼)"
pip install ultralytics ncnn

echo "== 4/5 시리얼 포트 권한 =="
sudo usermod -aG dialout "$USER"

echo "== 5/5 RPi 설정 =="
# USB 전류 제한 해제: 전원 어댑터가 RPi5 공식 규격(5V 5A)이 아니면 USB 전체가 0.6A 로 묶여서
# 라이다와 STM32 를 같이 꽂으면 모자랄 수 있다
CFG=/boot/firmware/config.txt
if [ -f "$CFG" ] && ! grep -q "^usb_max_current_enable=1" "$CFG"; then
    printf '\n[all]\nusb_max_current_enable=1\n' | sudo tee -a "$CFG" >/dev/null
    echo "  USB 전류 제한 해제 추가 ($CFG)"
fi
# 와이파이 절전 끄기: 켜져 있으면 원격 접속이 자주 느려지거나 끊긴다
NMCONF=/etc/NetworkManager/conf.d/wifi-powersave-off.conf
if [ -d /etc/NetworkManager/conf.d ] && [ ! -f "$NMCONF" ]; then
    printf '[connection]\nwifi.powersave = 2\n' | sudo tee "$NMCONF" >/dev/null
    echo "  와이파이 절전 끄기 추가 ($NMCONF)"
fi

mkdir -p captures
echo
echo "설치 완료. 설정 적용을 위해 한 번 재부팅하세요:  sudo reboot"
echo "폰 앱(외부 주소, 알림)을 처음 쓰려면 재부팅 후:  bash tools/setup_remote.sh"
