"""
화재 알림 기록과 PC 전송

- 화재 확정 시: 검출 박스를 그린 사진 + 원본 사진 + 직전 영상 클립을 captures/ 에 저장
- 목록은 captures/alerts.json 에 쌓이고, 웹 사이트(web/server.py)가 이걸 읽어서 보여준다
- 영상 변환은 몇 초 걸리므로 별도 스레드에서 처리한다 (주행 제어가 멈추지 않게)
- 알림을 켠 폰으로 푸시를 보낸다 (notify/push.py)
- config.PC_RECEIVER_URL 을 채우면 PC로도 밀어서 보낸다 (pc/receiver.py)
"""
import json
import threading
import time
import urllib.request
from datetime import datetime

import config

INDEX_FILE = config.CAPTURE_DIR / "alerts.json"


def load_items():
    if INDEX_FILE.exists():
        try:
            return json.loads(INDEX_FILE.read_text())
        except Exception:
            return []
    return []


def draw_detections(frame, dets, color=(0, 0, 255)):
    """BGR 프레임에 검출 박스와 라벨을 그린다 (제자리 수정)"""
    import cv2

    for d in dets:
        x1, y1, x2, y2 = (int(v) for v in d.box)
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 3)
        label = f"{d.label} {d.conf:.2f}"
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2)
        cv2.rectangle(frame, (x1, max(0, y1 - th - 10)), (x1 + tw + 8, y1), color, -1)
        cv2.putText(frame, label, (x1 + 4, y1 - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                    (255, 255, 255), 2, cv2.LINE_AA)
    return frame


class AlertManager:
    def __init__(self, camera, watcher=None, push=None):
        self.cam = camera
        self.watcher = watcher
        self.push = push
        config.CAPTURE_DIR.mkdir(exist_ok=True)
        self.items = load_items()
        # 영상 저장 도중 프로그램이 꺼졌던 기록은 '저장 중'에 영원히 머물러 있으니 정리
        stale = [it for it in self.items if it.get("clip_pending")]
        for it in stale:
            it["clip_pending"] = False
        if stale:
            self._write()
        self.last_alert = 0.0
        self._lock = threading.Lock()

    # ---------------- 공개 ----------------
    def in_cooldown(self, now=None):
        return (now or time.time()) - self.last_alert < config.ALERT_COOLDOWN

    def raise_alert(self, info, det=None):
        """화재 확정: 사진(박스 표시) + 원본 + 직전 영상. info 는 판정 근거"""
        self.last_alert = time.time()
        dets = [det] if det is not None else (self.watcher.detections() if self.watcher else [])
        item = self._save("fire", info, dets, with_clip=True)
        if item:
            print(f"[ALERT] {item['time']}  {info}")
            if self.push is not None and self.push.subs:
                conf = f", 신뢰도 {info['conf']:.2f}" if info.get("conf") is not None else ""
                self.push.send_all({
                    "title": "화재 감지",
                    "body": f"{item['time'][11:]} {info.get('reason', '')}{conf}",
                    "tag": item["id"],
                    "url": f"/?alert={item['id']}",
                })
        return item

    def snapshot(self, note="수동 촬영"):
        """웹 사이트의 '사진 찍기' 버튼. 지금 보이는 검출 박스도 같이 그린다"""
        dets = self.watcher.detections() if self.watcher else []
        return self._save("manual", {"reason": note}, dets, with_clip=False)

    def list(self):
        with self._lock:
            return list(self.items)

    def delete(self, ids):
        """기록과 파일(사진, 원본, 영상)을 지운다. 지운 개수 반환"""
        ids = set(ids)
        with self._lock:
            keep, gone = [], []
            for it in self.items:
                (gone if it["id"] in ids and not it.get("clip_pending") else keep).append(it)
            self.items = keep
            self._write()
        for it in gone:
            for key in ("photo", "raw", "clip"):
                name = it.get(key)
                if name:
                    try:
                        (config.CAPTURE_DIR / name).unlink()
                    except FileNotFoundError:
                        pass
        return len(gone)

    # ---------------- 내부 ----------------
    def _save(self, kind, info, dets, with_clip):
        import cv2

        got = self.cam.snapshot()
        if got is None:
            return None
        frame, _ = got
        now = time.time()
        stamp = datetime.fromtimestamp(now).strftime("%Y%m%d_%H%M%S")
        base = f"{kind}_{stamp}"
        raw_name, photo_name = f"{base}_raw.jpg", f"{base}.jpg"
        cv2.imwrite(str(config.CAPTURE_DIR / raw_name), frame)
        cv2.imwrite(str(config.CAPTURE_DIR / photo_name), draw_detections(frame, dets))

        item = {
            "id": base,
            "type": kind,
            "time": datetime.fromtimestamp(now).strftime("%Y-%m-%d %H:%M:%S"),
            "photo": photo_name,
            "raw": raw_name,
            "clip": None,
            "clip_pending": with_clip,
            **info,
        }
        with self._lock:
            self.items.insert(0, item)
            self.items = self.items[:300]
            self._write()

        if with_clip:
            threading.Thread(target=self._finish_clip, args=(item, f"{base}.mp4"),
                             daemon=True).start()
        elif config.PC_RECEIVER_URL:
            threading.Thread(target=self._push, args=(item,), daemon=True).start()
        return item

    def _finish_clip(self, item, clip_name):
        ok = False
        try:
            ok, why = self.cam.save_clip(config.CAPTURE_DIR / clip_name)
            print(f"[alerts] 직전 영상 {'저장' if ok else '저장 실패'}: {clip_name} ({why})")
        except Exception as e:
            print(f"[alerts] 직전 영상 저장 실패: {e}")
        with self._lock:
            item["clip"] = clip_name if ok else None
            item["clip_pending"] = False
            self._write()
        if config.PC_RECEIVER_URL:
            self._push(item)

    def _write(self):
        INDEX_FILE.write_text(json.dumps(self.items, ensure_ascii=False, indent=1))

    def _push(self, item):
        base = config.PC_RECEIVER_URL.rstrip("/")
        try:
            self._post(f"{base}/alert", json.dumps(item).encode(), "application/json")
            for key in ("photo", "clip"):
                name = item.get(key)
                path = config.CAPTURE_DIR / name if name else None
                if path and path.exists():
                    self._post(f"{base}/file?name={name}", path.read_bytes(),
                               "application/octet-stream")
        except Exception as e:
            print(f"[alerts] PC 전송 실패: {e}")

    @staticmethod
    def _post(url, body, ctype):
        req = urllib.request.Request(url, data=body, method="POST",
                                     headers={"Content-Type": ctype})
        urllib.request.urlopen(req, timeout=5).read()
