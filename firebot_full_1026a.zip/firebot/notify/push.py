"""
웹 푸시 알림 (아이폰 홈 화면 앱, 안드로이드, PC 브라우저 공통)

외부 라이브러리(pywebpush)는 RPi 에서 빌드가 깨지는 의존성이 있어서 쓰지 않고,
표준 규격을 cryptography 로 직접 구현했다.
  - RFC 8291  메시지 암호화 (aes128gcm)
  - RFC 8292  VAPID 서명 (ES256 JWT)

저장 파일 (data/)
  vapid_private.pem  서버 서명 키. 지우면 모든 기기가 알림을 다시 켜야 한다
  push_subs.json     알림을 켠 기기 목록
"""
import base64
import json
import os
import struct
import threading
import time
import urllib.error
import urllib.request
from urllib.parse import urlparse

from cryptography.hazmat.primitives import hashes, hmac, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

import config

KEY_FILE = config.DATA_DIR / "vapid_private.pem"
SUBS_FILE = config.DATA_DIR / "push_subs.json"


# ---------------------------------------------------------------- 공통 함수
def b64u(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def b64u_dec(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _hmac(key, data):
    h = hmac.HMAC(key, hashes.SHA256())
    h.update(data)
    return h.finalize()


def _pub_bytes(pub):
    return pub.public_bytes(serialization.Encoding.X962,
                            serialization.PublicFormat.UncompressedPoint)


# ---------------------------------------------------------------- RFC 8291
def encrypt(payload: bytes, ua_public_b64: str, auth_b64: str, salt=None, as_private=None):
    """
    구독 정보(p256dh, auth)로 메시지를 암호화해 요청 본문을 만든다.
    salt, as_private 는 시험용 고정값을 넣을 때만 쓴다.
    """
    ua_public = b64u_dec(ua_public_b64)
    auth = b64u_dec(auth_b64)
    salt = salt or os.urandom(16)
    as_private = as_private or ec.generate_private_key(ec.SECP256R1())
    as_public = _pub_bytes(as_private.public_key())

    ua_key = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), ua_public)
    ecdh = as_private.exchange(ec.ECDH(), ua_key)

    prk_key = _hmac(auth, ecdh)
    ikm = _hmac(prk_key, b"WebPush: info\x00" + ua_public + as_public + b"\x01")
    prk = _hmac(salt, ikm)
    cek = _hmac(prk, b"Content-Encoding: aes128gcm\x00\x01")[:16]
    nonce = _hmac(prk, b"Content-Encoding: nonce\x00\x01")[:12]

    record = payload + b"\x02"                       # 마지막 레코드 표시
    cipher = AESGCM(cek).encrypt(nonce, record, None)
    header = salt + struct.pack("!I", 4096) + bytes([len(as_public)]) + as_public
    return header + cipher


# ---------------------------------------------------------------- RFC 8292
class Vapid:
    def __init__(self):
        config.DATA_DIR.mkdir(exist_ok=True)
        if KEY_FILE.exists():
            self.key = serialization.load_pem_private_key(KEY_FILE.read_bytes(), password=None)
        else:
            self.key = ec.generate_private_key(ec.SECP256R1())
            KEY_FILE.write_bytes(self.key.private_bytes(
                serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                serialization.NoEncryption()))
            try:
                KEY_FILE.chmod(0o600)
            except Exception:
                pass
        self.public_b64 = b64u(_pub_bytes(self.key.public_key()))

    def header(self, endpoint, subject):
        u = urlparse(endpoint)
        claims = {"aud": f"{u.scheme}://{u.netloc}", "exp": int(time.time()) + 12 * 3600,
                  "sub": subject}
        head = b64u(json.dumps({"typ": "JWT", "alg": "ES256"}, separators=(",", ":")).encode())
        body = b64u(json.dumps(claims, separators=(",", ":")).encode())
        signing = f"{head}.{body}".encode()
        der = self.key.sign(signing, ec.ECDSA(hashes.SHA256()))
        r, s = decode_dss_signature(der)
        sig = b64u(r.to_bytes(32, "big") + s.to_bytes(32, "big"))
        return f"vapid t={head}.{body}.{sig}, k={self.public_b64}"


# ---------------------------------------------------------------- 서비스
class PushService:
    def __init__(self):
        self.vapid = Vapid()
        self._lock = threading.Lock()
        self.subs = self._load()
        self.last_result = None

    @property
    def public_key(self):
        return self.vapid.public_b64

    # ---------- 구독 관리 ----------
    def _load(self):
        if SUBS_FILE.exists():
            try:
                return json.loads(SUBS_FILE.read_text())
            except Exception:
                pass
        return []

    def _save(self):
        SUBS_FILE.write_text(json.dumps(self.subs, ensure_ascii=False, indent=1))

    def subscribe(self, sub, origin="", device=""):
        ep = sub.get("endpoint", "")
        keys = sub.get("keys", {})
        if not ep.startswith("https://") or not keys.get("p256dh") or not keys.get("auth"):
            raise ValueError("구독 정보가 올바르지 않음")
        with self._lock:
            self.subs = [s for s in self.subs if s["endpoint"] != ep]
            self.subs.append({"endpoint": ep, "keys": {"p256dh": keys["p256dh"], "auth": keys["auth"]},
                              "origin": origin if origin.startswith("https://") else "",
                              "device": device[:120], "added": time.strftime("%Y-%m-%d %H:%M")})
            self._save()

    def unsubscribe(self, endpoint):
        with self._lock:
            n = len(self.subs)
            self.subs = [s for s in self.subs if s["endpoint"] != endpoint]
            self._save()
            return n != len(self.subs)

    def has(self, endpoint):
        return any(s["endpoint"] == endpoint for s in self.subs)

    # ---------- 발송 ----------
    def _subject(self, sub):
        if config.PUSH_SUBJECT:
            return config.PUSH_SUBJECT
        # Apple 은 localhost 같은 주소를 거부한다. 앱에 접속한 https 주소를 발신자로 쓴다
        return sub.get("origin") or "https://github.com/firebot-robot"

    def send_one(self, sub, data: dict, ttl=3600):
        body = encrypt(json.dumps(data, ensure_ascii=False).encode(),
                       sub["keys"]["p256dh"], sub["keys"]["auth"])
        req = urllib.request.Request(sub["endpoint"], data=body, method="POST", headers={
            "Content-Encoding": "aes128gcm",
            "Content-Type": "application/octet-stream",
            "TTL": str(ttl),
            "Urgency": "high",
            "Authorization": self.vapid.header(sub["endpoint"], self._subject(sub)),
        })
        try:
            with urllib.request.urlopen(req, timeout=10) as r:
                return r.status, ""
        except urllib.error.HTTPError as e:
            return e.code, e.read()[:200].decode(errors="ignore")
        except Exception as e:
            return 0, str(e)

    def send_all(self, data: dict, wait=False):
        """모든 기기에 보냄. 기본은 백그라운드. 만료된 구독은 자동으로 지운다"""
        def run():
            results = []
            for sub in list(self.subs):
                code, msg = self.send_one(sub, data)
                results.append({"device": sub.get("device", ""), "code": code, "msg": msg})
                if code in (404, 410):
                    self.unsubscribe(sub["endpoint"])
                elif code == 403:
                    print(f"[push] 거부됨 (403): {msg}. 발신자 주소(PUSH_SUBJECT)를 확인")
                elif not 200 <= code < 300:
                    print(f"[push] 실패 {code}: {msg}")
            self.last_result = {"time": time.strftime("%H:%M:%S"), "results": results}
            return results

        if wait:
            return run()
        threading.Thread(target=run, daemon=True).start()
        return None
