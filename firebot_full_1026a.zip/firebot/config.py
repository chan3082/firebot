"""
전체 설정. 값 조정은 전부 이 파일에서 한다.
[실측] 표시된 항목은 로봇을 직접 재서 고쳐야 한다.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
CAPTURE_DIR = BASE_DIR / "captures"
DATA_DIR = BASE_DIR / "data"          # 로그인 비밀번호, 알림 키, 웹에서 바꾼 설정이 저장됨

# ---------------- 포트 ----------------
STM32_PORT = "/dev/ttyACM0"
STM32_BAUD = 115200

LIDAR_PORT = "/dev/ttyUSB0"
LIDAR_BAUD = 128000
LIDAR_DTR = True          # 라이다가 느리게 돌면 False로 바꿔본다

# ---------------- STM32 프로토콜 한계값 ----------------
# 펌웨어의 MAX_LINEAR / MAX_ANGULAR 와 같아야 한다
STM32_MAX_LINEAR = 0.5
STM32_MAX_ANGULAR = 1.0
CTRL_HZ = 20              # 펌웨어 워치독이 500ms라 최소 4Hz 이상

# ---------------- 차체 치수 (m) ----------------
HALF_LENGTH = 0.15        # [실측] 중심 → 앞/뒤 끝 (바퀴 포함). 로봇 길이 30cm
HALF_WIDTH = 0.09         # [실측] 중심 → 좌/우 끝 (바퀴 포함). 로봇 폭 18cm
CORRIDOR_MARGIN = 0.05    # 통로 폭 여유

# ---------------- 라이다 장착 ----------------
LIDAR_MOUNT_YAW = 0.0     # 라이다 0°(모터 쪽)가 로봇 기준 향하는 방향. 정면 0, 좌 90, 뒤 180, 우 -90
LIDAR_INVERTED = False    # 뒤집어 달았으면 True
LIDAR_OFFSET = (0.0, 0.0) # 로봇 중심 기준 라이다 위치 (x 전방+, y 좌측+)
LIDAR_STALE_SEC = 0.5     # 이 시간 이상 새 스캔 없으면 정지
LIDAR_MERGE_SCANS = 2     # 최근 N회 스캔을 겹쳐서 판단. 의자 다리처럼 가는 물체의 점 수를 늘린다

# ---------------- 회피 (차체 외곽 기준 여유거리, m) ----------------
# 규칙: 항상 정면을 본 채로 이동한다.
#   정면 막힘            -> 우측 횡이동
#   우측 이동 중 우측도 막힘 -> 좌측 횡이동
#   좌측 이동 중 좌측도 막힘 -> 후진해서 빠져나감
#   정면이 트이면         -> 다시 전진
SLOW_DIST = 0.80          # 이 거리부터 전진 감속
AVOID_DIST = 0.35         # 정면이 이 안으로 들어오면 회피 시작
SIDE_BLOCK = 0.15         # 횡이동 방향 옆이 이 안이면 '막힘'
SIDE_OPEN = 0.35          # 후진 중 옆이 이 이상 (그리고 후진 시작 때보다 ESCAPE_MARGIN 이상) 열리면 틈으로 판단
REAR_STOP = 0.10          # 후진 중 뒤가 이 안이면 정지
TURN_MARGIN = 0.08        # 제자리 회전에 필요한 최소 여유
HYSTERESIS = 0.10         # 복귀 판정 여유 (떨림 방지)
KTH = 3                   # 통로 안 k번째로 가까운 점 사용 (튀는 점 무시)

# ---------------- 속도 (정규화 -1 ~ 1) ----------------
CRUISE_SPEED = 0.35
CRUISE_MIN = 0.15
STRAFE_SPEED = 0.40
BACKUP_SPEED = 0.25
TURN_SPEED = 0.35

# ---------------- 회피 시간 (초) ----------------
OBSTACLE_WAIT = 1.5       # 정면이 막히면 비키기 전에 이만큼 기다림 (사람은 대개 비켜줌). 0이면 바로 회피
CLEAR_CYCLES = 4          # 정면이 연속 N회(20Hz 기준 0.2초) 트여야 전진 복귀
STRAFE_EXTRA = 0.3        # 정면이 트인 뒤 조금 더 비켜서 모서리 여유 확보
STRAFE_TIMEOUT = 8.0      # 한 방향 횡이동 최대 시간. 넘으면 그쪽을 막힘으로 본다
BACKUP_MIN = 0.4          # 최소 후진 시간
BACKUP_MAX = 5.0          # 이만큼 후진해도 옆이 안 열리면 막다른 길로 판단
ESCAPE_MARGIN = 0.30      # 후진 탈출 판정 여유: 옆은 이만큼 넓어져야 틈, 정면은 물러난 벽보다 이만큼 멀어져야 전진
MAX_ESCAPE_TRIES = 2      # LOOP_WINDOW 초 안에 후진이 이 횟수를 넘으면 같은 곳을 맴도는 것으로 보고 돌아 나감
LOOP_WINDOW = 60.0        # 맴돌기 판단 시간 창 (초)
DEADEND_MEMORY = 60.0     # 막다른 길로 판단한 정면 거리를 기억하는 시간. 그 안에는 정면이 확실히 멀어져야 다시 전진
BACKUP_LONG_MAX = 25.0    # 돌 공간도 없는 좁은 막다른 길에서 빠져나올 때까지 후진하는 최대 시간
DEADEND_TURN = True       # 막다른 길에서 180° 돌아나갈지 (False면 제자리 대기)
STUCK_RETRY = 2.0         # 정지 대기 중 재시도 간격

# ---------------- 주행 방식 ----------------
# "mecanum": 가는 쪽을 보고 달리면서 메카넘 동작을 섞는 방식 (nav/navigator.py, 기본)
#            A 작은 장애물은 옆으로 비켜 지나간 뒤 원래 길로, B 가면서 360° 둘러보기, C 모퉁이는 미끄러지며 돌기
# "legacy":  예전 방식. 항상 정면을 본 채 우측 → 좌측 → 후진 (nav/avoidance.py)
NAV_STYLE = "mecanum"
CORRIDOR_SIDE = 1.0       # 양옆 벽이 둘 다 이 안이면 복도로 보고 가운데를 따라감 (m)
MAX_DODGE = 0.8           # A: 옆으로 이 거리 안에서 비켜서 앞이 트이면 '작은 장애물'로 봄 (m)
PASS_CLEAR = 1.0          # A: 비켜선 자리에서 앞이 이만큼 트여야 지나갈 수 있다고 봄 (m)
RETURN_DIST = 1.0         # A: 원래 길로 돌아올 때 이 거리 가는 동안 돌아옴 (각도 = atan(벗어난 거리 / 이 값))
OPEN_DIST = 0.8           # C: 이만큼 트인 방향만 '갈 수 있는 방향'으로 봄 (m)
SLIDE_SPEED = 0.25        # C: 모퉁이에서 미끄러지는 속도
SLIDE_STOP = 0.15         # C: 미끄러지는 방향이 이 안으로 막히면 제자리에서만 돎 (m)
SWEEP_SPEED = 0.25        # B: 둘러볼 때 회전 속도 (TURN_SPEED 와 같은 단위). 화재 검출이 초당 2~4번이라 제자리 회전보다 느리게
SWEEP_LINEAR = 0.12       # B: 둘러보는 동안 가던 방향으로 가는 속도
ALIGN_GAIN = 0.8          # 직진 중 옆 벽과 나란하게 맞추는 세기
HEADING_HOLD = True       # 직진, 비키기, 돌아오기 중에 라이다로 본 벽 방향을 유지 (한쪽 바퀴가 느려 휘는 것 보정)
HOLD_GAIN = 0.02          # 1° 틀어질 때마다 거는 반대 회전 (TURN_SPEED 와 같은 단위)
HOLD_MAX = 0.25           # 보정 회전의 최대값
HOLD_LEARN = 0.003        # 휘는 버릇을 배우는 속도. 배운 만큼 처음부터 미리 반대로 틀어줌 (0 이면 안 배움)
HOLD_SNAP_DEG = 25        # 벽과 이 각도 안으로 틀어져 있으면 벽과 나란하게 맞춤. 넘으면 지금 방향을 유지
LAT_LEARN = 0.15          # 전진할 때 옆으로 밀리는 버릇을 배우는 속도 (복도 가운데, 벽까지 거리로 잼. 0 이면 안 배움)
START_MODE = "free"       # 켜자마자 할 일: "free" 자유 순찰 | "route" 기억한 길 순찰 (출발점에 놓고 켜야 함) | "idle" 앱에서 고를 때까지 대기

# ---------------- 주행 기록 (블랙박스, nav/blackbox.py) ----------------
RECORD_RUNS = True        # main.py 실행 중 라이다 스캔, 명령, 상태를 logs/run_*.npz 로 저장 (이상하게 움직이면 이 파일을 보내기)
RECORD_SEC = 600          # 최근 몇 초를 들고 있을지 (10분이면 파일 10MB 정도)
RECORD_KEEP = 5           # 파일을 최근 몇 개까지 남길지
MOUNT_CHECK = True        # 달리면서 라이다 방향 설정이 맞는지 확인하고, 틀리면 세우고 알림 (nav/mountcheck.py)

# ---------------- 둘러보기 (SCAN) ----------------
SCAN_ENABLED = True       # False면 둘러보기 없이 정면만 감시
SCAN_INTERVAL = 25.0      # 주행 몇 초마다 둘러볼지
SCAN_STEPS = 8            # 360°를 몇 번에 나눌지 (8 → 45°씩)
SCAN_SETTLE = 0.8         # 회전 멈춘 뒤 흔들림 가라앉히는 시간
SCAN_LOOK = 1.0           # 각 방향에서 관찰하는 시간
# 자이로가 없어서 회전량을 시간으로 계산한다. [실측 후 보정]
# TURN_SPEED 로 돌 때 초당 몇 도 도는지. 실제로 재서 고칠 것
TURN_RATE_DEG_S = 45.0

# ---------------- 카메라 ----------------
CAM_SIZE = (1280, 720)    # 촬영 해상도
CAM_FPS = 30              # 일렁임 분석에 쓰인다. 불꽃 흔들림(수 Hz)을 잡으려면 높을수록 좋음
CLIP_SECONDS = 5.0        # 알림 시 저장할 직전 영상 길이
CLIP_FPS = 10
# Picamera2 의 "RGB888" 형식은 실제로 [B, G, R] 순서로 나온다 (OpenCV 와 같은 순서).
# 그래서 코드 전체에서 프레임을 BGR 로 다룬다.

# ---------------- 화재 검출 ----------------
# 가중치 파일. 없거나 불러오지 못하면 색상 기반 임시 검출기로 대체된다.
#   models/fire.pt         YOLOv8s, fire/smoke. 작게 찍힌 화면 속 불에 강함 (기본)
#   models/fire_light.pt   YOLOv8n, fire/other/smoke. 3배 빠름, 대신 멀리 있는 작은 불에 약함
#   models/fire_ncnn_model NCNN 변환본 (RPi에서 가장 빠름, models/README.md 참고)
YOLO_MODEL = BASE_DIR / "models" / "fire.pt"
# 같은 폴더에 fire_ncnn_model 이 있으면 그걸 먼저 쓴다 (RPi 에서 몇 배 빠르고 CPU 를 덜 씀)
YOLO_PREFER_NCNN = True
YOLO_IMGSZ = 640          # 640이 작은 불을 잘 잡음. 느리면 416
# 추론에 쓸 CPU 코어 수. RPi5 는 4코어라 2개만 쓰고 나머지는 카메라, 웹, 원격 접속(VS Code, SSH)에 남긴다.
# 4로 올리면 빨라지지만 원격 접속이 끊길 수 있다
YOLO_THREADS = 2
DETECT_MIN_GAP = 0.15     # 추론 사이 최소로 쉬는 시간 (초). CPU 가 100% 로 붙지 않게
YOLO_CONF = 0.35
YOLO_CLASSES = ("fire", "smoke")   # 이 이름의 검출만 화재 후보로 본다 (대소문자 무시)

DETECT_HZ = 4.0           # 추론 시도 주기 (실제 속도는 모델과 RPi 성능에 따라 더 느릴 수 있음)
CONFIRM_FRAMES = 4        # 확정에 필요한 연속 검출 횟수
CONFIRM_TIMEOUT = 8.0     # 확인 단계 최대 시간
CANDIDATE_HITS = 2        # 순찰 중 이 횟수 연속 검출되면 멈춰서 확인

# ---------------- 일렁임 (불꽃 흔들림) ----------------
# 검출 박스 안을 카메라 프레임마다(30fps) 보고 값을 잰다.
#   motion : 박스 안 픽셀이 프레임 간 얼마나 바뀌는지 (화면 전체 변화분은 뺌)
#   std    : 박스 평균 밝기의 흔들림 크기
#   ratio  : 밝기 변화 중 FLICKER_BAND 대역 비율 (참고용)
# motion 과 std 가 둘 다 기준을 넘으면 '일렁임 있음'.
# 화재 영상으로 검증한 값: 화재 영상 motion 5.6 / std 2.9, 정지 사진 0.2 / 0.01,
#                         빨간 화면 0.02 / 0.01, 천천히 움직이는 빨간 소화기 0.9 / 0.4
FLICKER_WINDOW = 2.0      # 분석 구간 (초)
FLICKER_BAND = (1.5, 10.0)  # Hz
FLICKER_MOTION_MIN = 2.0  # 픽셀 변화량 기준 (0~255)
FLICKER_STD_MIN = 1.0     # 밝기 흔들림 기준 (0~255)
FLICKER_RATIO_MIN = 0.0   # 0이면 사용 안 함. 화재 '영상'은 느린 변화가 많아서 이 값이 낮게 나와 판정에서 뺐다
# 일렁임은 가산점이다. 영상 시연에서는 잡히고 사진 시연에서는 안 잡힌다.
FLICKER_REQUIRED = False
# 단, YOLO를 못 불러와 색상 검출기로 돌 때는 빨간 물체 오탐이 많으므로 일렁임을 필수로 한다
FALLBACK_REQUIRE_FLICKER = True

ALERT_COOLDOWN = 30.0     # 같은 알림 반복 방지 (초)
FIRE_HOLD = True          # 화재 확정 후: True 면 물러나서 멈춘 채 감시 (웹에서 '순찰 다시 시작'을 눌러야 재개)
                          #              False 면 물러난 뒤 180° 돌아서 바로 순찰 계속
FIRE_KEEP_DIST = 1.0      # 화재 확정 후 정면(불 쪽)과 이 거리(m) 이상 떨어지도록 물러남
FIRE_BACKOFF_MAX = 6.0    # 물러나는 최대 시간 (초)

# ---------------- 웹 앱 / 알림 ----------------
WEB_PORT = 8000           # 핫스팟 안에서는 http://<로봇IP>:8000, 외부는 Tailscale 주소 (README 참고)
STREAM_FPS = 10           # 실시간 영상 최대 속도. 앱의 '영상 화질' 설정이 이 안에서 고른다
STREAM_WIDTH = 640        # 실시간 영상 최대 가로 크기
STREAM_QUALITY = 70       # JPEG 품질 최대값
SESSION_DAYS = 30         # 로그인 유지 기간
# 푸시 알림 발신자 표시 (Apple 이 확인함). 비워두면 앱에 접속한 https 주소를 자동으로 씀
PUSH_SUBJECT = ""
# PC로 밀어서 보내고 싶을 때만 설정. 핫스팟에서 PC는 보통 192.168.137.1
PC_RECEIVER_URL = ""      # 예: "http://192.168.137.1:9000"
